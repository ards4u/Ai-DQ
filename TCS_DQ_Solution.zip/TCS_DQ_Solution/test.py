import os
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
import httpx

# Configure the LLM
client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",  # Replace with your actual endpoint
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-oSjfXrMd6fAVjFUG7c89TQ",  # Replace with your actual API key
    http_client=client,
    temperature=0.7  # Adjust for creativity (0-1)
)

# Initialize conversation history with system message
conversation_history = [
    SystemMessage(content="You are a helpful, friendly assistant. Be concise and conversational.")
]

def chat_with_memory(user_message):
    """Send a message and get a response with conversation memory"""
    try:
        # Add user message to history
        conversation_history.append(HumanMessage(content=user_message))
        
        # Get response from LLM
        response = llm.invoke(conversation_history)
        
        # Add AI response to history
        conversation_history.append(AIMessage(content=response.content))
        
        return response.content
    
    except Exception as e:
        return f"Error: {str(e)}"

def display_conversation_stats():
    """Display conversation statistics"""
    user_msgs = sum(1 for msg in conversation_history if isinstance(msg, HumanMessage))
    ai_msgs = sum(1 for msg in conversation_history if isinstance(msg, AIMessage))
    print(f"\n[Stats: {user_msgs} user messages, {ai_msgs} AI responses]")

def clear_history():
    """Clear conversation history except system message"""
    global conversation_history
    conversation_history = [conversation_history[0]]  # Keep only system message
    print("\n✓ Conversation history cleared!\n")

def main():
    """Main chat loop"""
    print("=" * 60)
    print("  CONVERSATIONAL AI BOT")
    print("=" * 60)
    print("\nCommands:")
    print("  'quit' or 'exit' - End conversation")
    print("  'clear' - Clear conversation history")
    print("  'stats' - Show conversation statistics")
    print("\n" + "-" * 60 + "\n")
    
    # Initial greeting
    print("Bot: Hello! I'm your AI assistant. How can I help you today?\n")
    
    while True:
        try:
            # Get user input
            user_input = input("You: ").strip()
            
            # Check for empty input
            if not user_input:
                continue
            
            # Handle commands
            if user_input.lower() in ['quit', 'exit', 'bye', 'goodbye']:
                print("\nBot: Goodbye! Have a great day! 👋\n")
                display_conversation_stats()
                break
            
            elif user_input.lower() == 'clear':
                clear_history()
                continue
            
            elif user_input.lower() == 'stats':
                display_conversation_stats()
                print()
                continue
            
            # Get bot response
            bot_response = chat_with_memory(user_input)
            print(f"\nBot: {bot_response}\n")
        
        except KeyboardInterrupt:
            print("\n\nBot: Conversation interrupted. Goodbye! 👋\n")
            display_conversation_stats()
            break
        
        except Exception as e:
            print(f"\nError: {str(e)}\n")
            print("Please try again or type 'quit' to exit.\n")

if __name__ == "__main__":
    main()