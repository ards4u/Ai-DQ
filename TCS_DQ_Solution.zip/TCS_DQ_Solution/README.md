# AI-Powered Data Quality Dashboard

An intelligent data quality monitoring system built for TCS Hackathon featuring AI-powered insights using LLaMA3 (Ollama) with comprehensive guardrails.

## 🌟 Features

### Core Capabilities
- **Multi-Level DQ Analysis**: Field, Table, and Domain level quality scoring
- **Real-time Monitoring**: Live dashboard with interactive visualizations
- **AI-Powered Insights**: LLM-generated recommendations with human-in-the-loop review
- **Guardrails**: Comprehensive input/output validation and security controls
- **CSV Upload**: Analyze external data files
- **SQLite Integration**: Finance and HR sample data

### Data Quality Metrics
1. **Completeness**: Null/missing value detection
2. **Correctness**: Default and invalid value identification
3. **Uniqueness**: Duplicate record analysis
4. **Consistency**: Format and pattern validation

### Security Features
- Prompt injection detection
- Input sanitization
- Output validation
- SQL injection prevention
- Response quality scoring

## 🏗️ Project Structure

```
dq-dashboard/
├── app.py                      # Main Flask application
├── requirements.txt            # Python dependencies
├── config/
│   └── settings.py            # Configuration settings
├── src/
│   ├── models/
│   │   └── database_models.py # SQLAlchemy models
│   ├── services/
│   │   ├── dq_analyzer.py    # Data quality analyzer
│   │   └── llm_service.py    # LLM integration service
│   ├── guardrails/
│   │   └── llm_guardrails.py # Security guardrails
│   ├── controllers/           # API controllers (future)
│   └── utils/
│       └── db_init.py         # Database initialization
├── templates/
│   └── dashboard.html         # Main UI template
├── static/
│   ├── css/
│   │   └── style.css          # Styling
│   └── js/
│       └── main.js            # Frontend logic
├── database/                  # SQLite database location
├── uploads/                   # CSV upload directory
└── logs/                      # Application logs
```

## 🚀 Setup Instructions

### Prerequisites
- Python 3.8+
- Ollama with LLaMA3 model
- pip (Python package manager)

### Step 1: Install Ollama and LLaMA3

```bash
# Install Ollama (macOS/Linux)
curl -fsSL https://ollama.com/install.sh | sh

# For Windows, download from: https://ollama.com/download

# Pull LLaMA3 model
ollama pull llama3

# Verify Ollama is running
ollama list
```

### Step 2: Clone and Setup Project

```bash
# Navigate to project directory
cd dq-dashboard

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Step 3: Initialize Database

```bash
# Run database initialization script
python src/utils/db_init.py
```

This will create:
- SQLite database with all tables
- Sample HR data (100 employees, 50 payroll records)
- Sample Finance data (80 invoices, 60 expenses)
- Default DQ rules
- Intentional data quality issues for testing

### Step 4: Start the Application

```bash
# Ensure Ollama is running in the background
ollama serve

# In another terminal, start Flask app
python app.py
```

The application will be available at: **http://localhost:5000**

## 📊 Usage Guide

### 1. Dashboard Overview
- View overall statistics for all data domains
- Monitor total records across HR and Finance
- Quick access to domain-specific analysis

### 2. Analyze Database Tables
- Click on table buttons (Employees, Payroll, Invoices, Expenses)
- View comprehensive DQ scores at field and table level
- Identify specific data quality issues

### 3. Analyze CSV Files
- Navigate to "Analysis" page
- Upload CSV file
- Enable "Generate AI Insights" for LLM recommendations
- View detailed analysis results

### 4. AI Insights
- Automatically generated after analysis
- View root cause analysis
- Review recommendations
- Approve/reject suggestions (Human-in-the-loop)

### 5. Admin Panel
- Initialize/reset database
- Check LLM connection status
- View guardrails configuration

## 🔒 Guardrails Implementation

### Input Guardrails
- **Length Validation**: Max 2000 characters for prompts
- **Pattern Blocking**: SQL injection, XSS, command injection
- **Context Validation**: Ensures relevance to DQ analysis
- **Prompt Injection Detection**: Identifies manipulation attempts

### Output Guardrails
- **Content Filtering**: Removes harmful patterns
- **Quality Validation**: Ensures meaningful insights
- **Length Control**: Max 5000 characters
- **Confidence Scoring**: Rates response quality

### Example Blocked Patterns
```python
- DROP TABLE
- DELETE FROM
- <script>
- eval()
- __import__
- ignore previous instructions
```

## 🎯 Key Endpoints

### API Endpoints
```
GET  /api/domains              # Get all domains
GET  /api/stats/overall        # Get overall statistics
POST /api/analyze/table/{name} # Analyze database table
POST /api/analyze/csv          # Analyze uploaded CSV
POST /api/analyze/field        # Get AI insights for field
GET  /api/llm/test             # Test LLM connection
POST /admin/init-db            # Initialize database
```

## 🧪 Testing

### Test Data Quality Issues
The sample data includes intentional issues:
- **Null Values**: ~15% of records
- **Default Values**: Phone numbers like 9999999999
- **Invalid Emails**: test@test.com
- **Duplicates**: ~5% duplicate records
- **Negative Values**: Invalid amounts in expenses
- **Missing Data**: Empty names and descriptions

### Test LLM Integration
1. Analyze any table with "Generate Insights" enabled
2. Check AI Insights page for recommendations
3. Verify guardrails by trying malicious prompts (they should be blocked)

## 🔄 Changing LLM Model

To use a different Ollama model:

1. Pull the model:
```bash
ollama pull <model-name>
```

2. Update `config/settings.py`:
```python
OLLAMA_MODEL = "your-model-name"
```

3. Restart the application

## 📈 Performance Tips

- **Ollama**: Ensure sufficient RAM (8GB+ recommended)
- **Database**: SQLite is suitable for demo; use PostgreSQL for production
- **Batch Processing**: For large CSV files, consider chunking
- **Caching**: Enable response caching for repeated analyses

## 🎨 UI Features

- **Modern Design**: Gradient backgrounds, smooth animations
- **Responsive**: Works on desktop and mobile
- **Interactive Charts**: Real-time score visualization
- **Dark Header**: Professional appearance
- **Color-coded Scores**: Instant quality assessment

## 🛠️ Troubleshooting

### Ollama Connection Issues
```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Restart Ollama service
ollama serve
```

### Database Issues
```bash
# Reset database
rm database/dq_database.db
python src/utils/db_init.py
```

### Port Conflicts
Edit `app.py` to change port:
```python
app.run(debug=True, port=5001)
```

## 📝 Sample Data Schema

### Employees Table
- employee_id, first_name, last_name, email, phone
- department, designation, salary, joining_date

### Payroll Table
- employee_id, month, year, basic_salary
- allowances, deductions, net_salary, payment_date

### Invoices Table
- invoice_number, client_name, invoice_date, due_date
- amount, tax, total_amount, status

### Expenses Table
- expense_id, employee_id, category, description
- amount, expense_date, status

## 🏆 Hackathon Highlights

1. **Complete Solution**: End-to-end DQ monitoring with AI
2. **Production-Ready**: Proper structure, error handling, logging
3. **Security First**: Comprehensive guardrails implementation
4. **User-Friendly**: Intuitive UI with human-in-the-loop
5. **Extensible**: Easy to add new domains, rules, and metrics
6. **Well-Documented**: Clear code comments and documentation

## 📧 Support

For issues or questions:
1. Check troubleshooting section
2. Review Ollama documentation
3. Verify all prerequisites are met

## 🎓 Learning Resources

- [Ollama Documentation](https://github.com/ollama/ollama)
- [LLaMA3 Model Card](https://ollama.com/library/llama3)
- [Flask Documentation](https://flask.palletsprojects.com/)
- [SQLAlchemy Guide](https://docs.sqlalchemy.org/)

## 📄 License

This project is created for TCS Hackathon purposes.

---

**Built with ❤️ for TCS Hackathon 2024**
