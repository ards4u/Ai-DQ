#!/bin/bash
# Quick start script for Data Quality Dashboard

echo "🎯 Starting Data Quality Dashboard..."
echo ""

# Check if database exists
if [ ! -f "database/dq_database.db" ]; then
    echo "⚠️  Database not found. Running setup..."
    python3 setup.py
    echo ""
fi

# Start the application
echo "🚀 Starting Flask application..."
echo "📍 Access the dashboard at: http://localhost:5000"
echo ""
python3 app.py
