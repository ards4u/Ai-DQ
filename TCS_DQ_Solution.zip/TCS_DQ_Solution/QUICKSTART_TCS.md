# Quick Start Guide - DQ Dashboard with TCS GenAI Lab

## 🚀 3-Step Setup

### Step 1: Get Your TCS GenAI Lab API Key

Before starting, obtain your API key from TCS GenAI Lab:
- **Endpoint**: https://genailab.tcs.in
- **Model**: DeepSeek-V3 (azure.ai/genailab-maas-DeepSeek-V3-0324)
- **Contact**: Your TCS administrator or GenAI Lab team

### Step 2: Run Setup Script

```bash
# Clone/Download the project
cd dq-dashboard

# Linux/macOS
chmod +x setup.sh
./setup.sh

# Windows
setup.bat
```

The script will:
- ✅ Check Python installation
- ✅ Create virtual environment
- ✅ Install dependencies
- ✅ Initialize database
- ✅ Create .env file

### Step 3: Configure API Key

```bash
# Edit .env file (created by setup script)
nano .env

# Add your API key:
TCS_GENAI_API_KEY=your_actual_api_key_here
```

**Save and close the file.**

### Step 4: Launch Application

```bash
# Activate virtual environment
source venv/bin/activate  # Linux/macOS
# OR
venv\Scripts\activate  # Windows

# Start the application
python app.py

# Open browser: http://localhost:5000
```

## ✅ Verify Setup

1. **Check Dashboard**: You should see statistics for 100 employees, 80 invoices, etc.
2. **Check LLM Status**: Top right corner should show "Connected" (green)
3. **Test Analysis**: Click "Employees" button to analyze sample data

## 🎯 First Demo (5 minutes)

### Scenario 1: Database Analysis
```
1. Click "Employees" button under HR domain
2. Wait 3-5 seconds for analysis
3. View DQ scores: Completeness, Correctness, etc.
4. Scroll to see field-level details
5. Check detected issues (nulls, defaults, duplicates)
```

### Scenario 2: AI Insights
```
1. After analyzing Employees table
2. Notice "Generate AI Insights" was enabled
3. Navigate to "AI Insights" tab
4. Read DeepSeek-V3's recommendations
5. Review root cause analysis
6. Approve or reject suggestions
```

### Scenario 3: CSV Upload
```
1. Go to "Analysis" page
2. Click "Choose File"
3. Select sample_data.csv (included)
4. Enable "Generate AI Insights"
5. Click "Analyze"
6. View comprehensive results
```

## 🔧 Configuration Options

### Basic Configuration (.env file)
```bash
# Required
TCS_GENAI_API_KEY=your_key_here

# Optional (defaults are set)
TCS_GENAI_BASE_URL=https://genailab.tcs.in
TCS_GENAI_MODEL=azure.ai/genailab-maas-DeepSeek-V3-0324
DEBUG_MODE=True
SECRET_KEY=your_secret_key
```

### Advanced Configuration (config/settings.py)
```python
# Guardrails settings
GUARDRAILS_CONFIG = {
    'max_prompt_length': 2000,
    'max_response_length': 5000,
    'temperature': 0.3,
    'top_p': 0.9
}

# DQ thresholds
DQ_THRESHOLDS = {
    'excellent': 95,
    'good': 80,
    'fair': 60,
    'poor': 0
}
```

## 🐛 Troubleshooting

### Issue: "Cannot connect to TCS GenAI Lab"

**Solution 1**: Check API key
```bash
# View your .env file
cat .env | grep TCS_GENAI_API_KEY

# Verify it's not empty or "XXXXXX"
```

**Solution 2**: Verify network connectivity
```bash
# Test connection to GenAI Lab
curl -I https://genailab.tcs.in

# Should return HTTP 200 or similar
```

**Solution 3**: Check for typos
- API key should be exact (case-sensitive)
- No extra spaces or quotes
- Model name exactly as shown

### Issue: "Module not found"

**Solution**:
```bash
# Activate virtual environment
source venv/bin/activate

# Reinstall dependencies
pip install -r requirements.txt
```

### Issue: "Database locked"

**Solution**:
```bash
# Close all connections and reset
rm database/dq_database.db
python src/utils/db_init.py
```

### Issue: "Port 5000 already in use"

**Solution**: Edit app.py
```python
# Change port number
if __name__ == '__main__':
    app.run(debug=DEBUG_MODE, host='0.0.0.0', port=5001)
```

## 📊 Understanding DQ Scores

### Quality Grades
- **Excellent** (95-100%): Data is highly reliable
- **Good** (80-94%): Minor issues, mostly usable
- **Fair** (60-79%): Significant issues, needs attention
- **Poor** (<60%): Critical issues, requires immediate action

### Metrics Explained
1. **Completeness**: How much data is present (not null/empty)
2. **Correctness**: Valid values (no defaults like 9999999999)
3. **Uniqueness**: No duplicates
4. **Consistency**: Consistent formats and patterns

## 🎨 UI Navigation

### Main Pages
1. **Dashboard**: Overview with quick stats
2. **Analysis**: Upload CSV or view detailed analysis
3. **AI Insights**: LLM recommendations and reviews
4. **Admin**: Database management and settings

### Color Coding
- 🟢 **Green**: Excellent quality (95%+)
- 🔵 **Blue**: Good quality (80-94%)
- 🟡 **Yellow**: Fair quality (60-79%)
- 🔴 **Red**: Poor quality (<60%)

## 🔒 Security Notes

### API Key Security
- ✅ Store in .env file (not in code)
- ✅ Add .env to .gitignore
- ✅ Never commit to version control
- ✅ Rotate keys regularly

### Guardrails Active
- ✅ Prompt injection detection
- ✅ SQL injection prevention
- ✅ XSS attack blocking
- ✅ Input/output validation

## 📈 Sample Data

The application includes 290+ sample records:

**HR Domain**:
- 100 Employees (with 15% intentional issues)
- 50 Payroll records

**Finance Domain**:
- 80 Invoices
- 60 Expenses

**Test File**:
- sample_data.csv (12 records for testing)

All data includes intentional DQ issues for demonstration!

## 🎓 Next Steps

1. **Explore**: Try analyzing all tables
2. **Customize**: Add your own data sources
3. **Extend**: Create custom DQ rules
4. **Integrate**: Connect to real databases
5. **Deploy**: Set up for production use

## 💡 Tips

- Enable "Generate AI Insights" for best results
- Review AI recommendations before implementing
- Use human-in-the-loop for critical decisions
- Monitor guardrails logs for security events
- Keep API key secure and rotate regularly

## 📞 Getting Help

1. Check README_TCS_GENAI.md for detailed docs
2. Review ARCHITECTURE.md for technical details
3. See PRESENTATION.md for demo scenarios
4. Contact TCS GenAI Lab team for API issues

## ⚡ Quick Commands

```bash
# Setup
./setup.sh  # or setup.bat

# Configure
nano .env

# Run
source venv/bin/activate
python app.py

# Reset Database
python src/utils/db_init.py

# Test Connection
curl http://localhost:5000/api/llm/test
```

---

## ✅ Setup Complete!

You're ready to:
- ✅ Analyze data quality
- ✅ Get AI-powered insights
- ✅ Review recommendations
- ✅ Generate reports
- ✅ Monitor data health

**Time to first demo: < 5 minutes** 🚀

---

**Powered by TCS GenAI Lab's DeepSeek-V3 Model**
**Built for TCS Hackathon 2024**
