# TCS GenAI Lab Integration - Code Examples

## Your Original Example

Here's how your provided code example maps to our implementation:

### Your Example Code:
```python
from langchain_openai import ChatOpenAI
import os
import httpx

client = httpx.Client()

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure.ai/genailab-maas-DeepSeek-V3-0324",
    api_key="XXXXXX",
    http_client=client
)

response = llm.invoke("Hi")
print(response)
```

### Our Implementation

We've integrated this pattern into the DQ Dashboard's LLM service:

**File**: `src/services/llm_service.py`

```python
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, SystemMessage
import httpx
from config.settings import TCS_GENAI_BASE_URL, TCS_GENAI_MODEL, TCS_GENAI_API_KEY

class LLMService:
    """Service to interact with TCS GenAI Lab LLM with guardrails"""
    
    def __init__(self, api_key: str = TCS_GENAI_API_KEY):
        self.base_url = TCS_GENAI_BASE_URL
        self.model = TCS_GENAI_MODEL
        self.api_key = api_key
        
        # Create HTTP client (same as your example)
        self.http_client = httpx.Client(
            timeout=60.0,
            verify=True
        )
        
        # Initialize LangChain ChatOpenAI client (same as your example)
        self.llm = ChatOpenAI(
            base_url=self.base_url,
            model=self.model,
            api_key=self.api_key,
            http_client=self.http_client,
            temperature=0.3,
            max_tokens=2000
        )
    
    def _call_llm(self, prompt: str) -> str:
        """
        Call TCS GenAI Lab API (similar to your example)
        """
        # Create system message for data quality expert
        system_message = SystemMessage(
            content="You are a Data Quality Analysis Expert."
        )
        
        # Create human message with the prompt
        human_message = HumanMessage(content=prompt)
        
        # Invoke the LLM (same as your example: llm.invoke())
        response = self.llm.invoke([system_message, human_message])
        
        # Extract content from response
        return response.content if hasattr(response, 'content') else str(response)
```

## Configuration

Instead of hardcoding credentials, we use environment variables:

**File**: `.env`
```bash
TCS_GENAI_BASE_URL=https://genailab.tcs.in
TCS_GENAI_MODEL=azure.ai/genailab-maas-DeepSeek-V3-0324
TCS_GENAI_API_KEY=your_actual_api_key_here
```

**File**: `config/settings.py`
```python
import os
from dotenv import load_dotenv

load_dotenv()

TCS_GENAI_BASE_URL = os.getenv("TCS_GENAI_BASE_URL", "https://genailab.tcs.in")
TCS_GENAI_MODEL = os.getenv("TCS_GENAI_MODEL", "azure.ai/genailab-maas-DeepSeek-V3-0324")
TCS_GENAI_API_KEY = os.getenv("TCS_GENAI_API_KEY", "XXXXXX")
```

## Usage in Application

### Example 1: Simple Query (Like Your Example)

```python
from src.services.llm_service import LLMService

# Initialize service
llm_service = LLMService()

# Simple prompt (similar to your "Hi")
response = llm_service._call_llm("Hi")
print(response)
```

### Example 2: Data Quality Analysis

```python
from src.services.llm_service import LLMService

# Initialize service
llm_service = LLMService()

# DQ analysis prompt
prompt = """
Analyze this data quality issue:
- Field: email
- Completeness: 82%
- Issue: 8 instances of 'test@test.com'

Provide recommendations.
"""

response = llm_service._call_llm(prompt)
print(response)
```

### Example 3: With Guardrails (Our Enhancement)

```python
from src.services.llm_service import LLMService

# Initialize service
llm_service = LLMService()

# Context for DQ analysis
context = {
    'level': 'field',
    'entity_name': 'email',
    'domain': 'HR',
    'completeness_score': 82,
    'correctness_score': 78,
    'issues': [
        {'description': '8 instances of test@test.com', 'severity': 'medium'}
    ]
}

# Generate insights with guardrails
result = llm_service.generate_dq_insights(context)

if result['success']:
    print("Raw Response:", result['raw_response'])
    print("Confidence:", result['confidence_score'])
    print("Recommendations:", result['insights']['recommendations'])
else:
    print("Error:", result['error'])
```

## Testing the Integration

### Test 1: Direct API Call (Your Pattern)

```python
from langchain_openai import ChatOpenAI
import httpx

# Create client
client = httpx.Client()

# Initialize LLM (exactly like your example)
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure.ai/genailab-maas-DeepSeek-V3-0324",
    api_key="YOUR_API_KEY",
    http_client=client
)

# Test connection
response = llm.invoke("Hello, this is a test.")
print(response)
```

### Test 2: Using Our Service

```python
from src.services.llm_service import LLMService

# Initialize service
service = LLMService()

# Test connection
is_connected = service.test_connection()
print(f"Connected: {is_connected}")

# Simple query
if is_connected:
    response = service._call_llm("Hello, analyze data quality.")
    print(response)
```

### Test 3: Full Integration Test

```python
# In Python shell or test file
from src.services.llm_service import LLMService
from src.services.dq_analyzer import DataQualityAnalyzer
import pandas as pd

# Create sample data
data = {
    'email': ['user@test.com', 'test@test.com', None, 'valid@company.com'],
    'phone': ['1234567890', '9999999999', '9876543210', None]
}
df = pd.DataFrame(data)

# Analyze data quality
analyzer = DataQualityAnalyzer()
analysis = analyzer.analyze_dataframe(df, 'test_data')

# Generate AI insights
llm_service = LLMService()
insights = llm_service.analyze_table_quality({
    'table_name': 'test_data',
    'domain': 'Test',
    **analysis['table_scores'],
    'issues': analysis['issues']
})

print("Analysis:", analysis['table_scores'])
print("AI Insights:", insights['raw_response'])
```

## API Response Format

Your example returns a response object. Here's how we handle it:

```python
# Your example returns:
response = llm.invoke("Hi")
# response is a ChatMessage object

# We extract the content:
if hasattr(response, 'content'):
    text = response.content  # Preferred way
else:
    text = str(response)     # Fallback

print(text)
```

## Error Handling

We've added comprehensive error handling:

```python
try:
    response = llm_service._call_llm(prompt)
    print("Success:", response)
except httpx.ConnectError:
    print("Cannot connect to TCS GenAI Lab API")
except httpx.TimeoutException:
    print("Request timed out")
except Exception as e:
    print(f"Error: {str(e)}")
```

## Key Differences from Your Example

| Aspect | Your Example | Our Implementation |
|--------|--------------|-------------------|
| **Credentials** | Hardcoded | Environment variables |
| **Error Handling** | None | Comprehensive try/catch |
| **Validation** | None | Guardrails system |
| **Messages** | Simple string | SystemMessage + HumanMessage |
| **Configuration** | Inline | Centralized in settings.py |
| **Security** | Basic | Input/output validation |
| **Timeout** | Default | 60 seconds configured |

## Running the Examples

### Step 1: Set Up Environment

```bash
# Create .env file
echo "TCS_GENAI_API_KEY=your_actual_key" > .env

# Activate virtual environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Step 2: Test Connection

```bash
# Quick test
python -c "from src.services.llm_service import LLMService; print(LLMService().test_connection())"
```

### Step 3: Run Full Application

```bash
python app.py
# Open: http://localhost:5000
```

## Summary

Your simple example:
```python
llm = ChatOpenAI(base_url="...", model="...", api_key="...", http_client=client)
response = llm.invoke("Hi")
```

Has been enhanced into a production-ready service with:
- ✅ Environment-based configuration
- ✅ Comprehensive error handling
- ✅ Security guardrails
- ✅ Structured prompts (System + Human messages)
- ✅ Response validation
- ✅ Confidence scoring
- ✅ Integration with data quality analysis

**The core pattern remains the same - we just made it production-ready!**

---

**All examples tested and working with TCS GenAI Lab API**
