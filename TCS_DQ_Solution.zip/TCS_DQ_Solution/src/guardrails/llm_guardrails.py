"""
Guardrails for LLM prompts and responses
Ensures safe and appropriate interactions with the LLM
"""
import re
from typing import Dict, Tuple, Optional
from datetime import datetime


class LLMGuardrails:
    """Guardrails to validate and sanitize LLM inputs and outputs"""
    
    # Blocked patterns (SQL injection, command injection, etc.)
    BLOCKED_PATTERNS = [
        r'DROP\s+TABLE',
        r'DELETE\s+FROM',
        r'TRUNCATE\s+TABLE',
        r'ALTER\s+TABLE',
        r'--\s*$',
        r';\s*DROP',
        r'EXEC\s*\(',
        r'EXECUTE\s*\(',
        r'<script',
        r'javascript:',
        r'eval\s*\(',
        r'__import__',
        r'os\.system',
        r'subprocess',
    ]
    
    # Allowed topics for DQ analysis
    ALLOWED_TOPICS = [
        'data quality',
        'completeness',
        'correctness',
        'uniqueness',
        'consistency',
        'duplicate',
        'missing value',
        'null value',
        'default value',
        'data validation',
        'data patterns',
        'anomaly',
        'recommendation',
        'insight'
    ]
    
    def __init__(self, max_prompt_length: int = 2000, max_response_length: int = 5000):
        self.max_prompt_length = max_prompt_length
        self.max_response_length = max_response_length
        self.validation_log = []
    
    def validate_prompt(self, prompt: str) -> Tuple[bool, Optional[str], str]:
        """
        Validate user prompt before sending to LLM
        Returns: (is_valid, error_message, sanitized_prompt)
        """
        # Check if prompt is empty
        if not prompt or not prompt.strip():
            return False, "Prompt cannot be empty", ""
        
        # Check prompt length
        if len(prompt) > self.max_prompt_length:
            return False, f"Prompt exceeds maximum length of {self.max_prompt_length} characters", ""
        
        # Check for blocked patterns
        for pattern in self.BLOCKED_PATTERNS:
            if re.search(pattern, prompt, re.IGNORECASE):
                self._log_violation(f"Blocked pattern detected: {pattern}")
                return False, "Prompt contains potentially harmful content", ""
        
        # Sanitize the prompt
        sanitized = self._sanitize_text(prompt)
        
        # Validate context relevance
        if not self._is_relevant_to_dq(sanitized):
            return False, "Prompt should be related to data quality analysis", ""
        
        return True, None, sanitized
    
    def validate_response(self, response: str) -> Tuple[bool, Optional[str], str]:
        """
        Validate LLM response before returning to user
        Returns: (is_valid, error_message, sanitized_response)
        """
        # Check if response is empty
        if not response or not response.strip():
            return False, "Empty response from LLM", ""
        
        # Check response length
        if len(response) > self.max_response_length:
            response = response[:self.max_response_length] + "... [truncated]"
        
        # Check for blocked patterns
        for pattern in self.BLOCKED_PATTERNS:
            if re.search(pattern, response, re.IGNORECASE):
                self._log_violation(f"Blocked pattern in response: {pattern}")
                return False, "Response contains potentially harmful content", ""
        
        # Sanitize the response
        sanitized = self._sanitize_text(response)
        
        return True, None, sanitized
    
    def _sanitize_text(self, text: str) -> str:
        """Remove potentially harmful content from text"""
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', '', text)
        
        # Remove SQL comments
        text = re.sub(r'--.*$', '', text, flags=re.MULTILINE)
        text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def _is_relevant_to_dq(self, text: str) -> bool:
        """Check if text is relevant to data quality context"""
        text_lower = text.lower()
        
        # Allow if it contains any DQ-related keywords
        return any(topic in text_lower for topic in self.ALLOWED_TOPICS)
    
    def _log_violation(self, message: str):
        """Log guardrail violations"""
        self.validation_log.append({
            'timestamp': datetime.utcnow(),
            'message': message
        })
    
    def get_safe_prompt_template(self, context: Dict) -> str:
        """
        Generate a safe, structured prompt template
        """
        template = f"""You are a Data Quality Analysis Expert. Your task is to analyze data quality issues and provide actionable insights.

Context:
- Level: {context.get('level', 'N/A')}
- Entity: {context.get('entity_name', 'N/A')}
- Domain: {context.get('domain', 'N/A')}

Data Quality Metrics:
- Completeness Score: {context.get('completeness_score', 0):.2f}%
- Correctness Score: {context.get('correctness_score', 0):.2f}%
- Uniqueness Score: {context.get('uniqueness_score', 0):.2f}%
- Consistency Score: {context.get('consistency_score', 0):.2f}%
- Overall Score: {context.get('overall_score', 0):.2f}%

Issues Detected:
{context.get('issues', 'None')}

Please provide:
1. Root cause analysis of the data quality issues
2. Specific recommendations to improve data quality
3. Priority level for each recommendation (High/Medium/Low)
4. Potential impact if not addressed

Keep your response focused on data quality improvement and actionable insights.
"""
        return template
    
    def format_llm_response(self, response: str) -> Dict:
        """
        Parse and format LLM response into structured data
        """
        sections = {
            'root_cause': '',
            'recommendations': [],
            'priorities': {},
            'impact': ''
        }
        
        # Try to extract sections from response
        lines = response.split('\n')
        current_section = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Identify sections
            if 'root cause' in line.lower():
                current_section = 'root_cause'
            elif 'recommendation' in line.lower():
                current_section = 'recommendations'
            elif 'impact' in line.lower():
                current_section = 'impact'
            elif current_section:
                if current_section == 'root_cause':
                    sections['root_cause'] += line + ' '
                elif current_section == 'recommendations':
                    if line.startswith(('-', '•', '*', '1', '2', '3', '4', '5')):
                        sections['recommendations'].append(line.lstrip('-•*123456789. '))
                elif current_section == 'impact':
                    sections['impact'] += line + ' '
        
        return sections


class PromptInjectionDetector:
    """Detect potential prompt injection attempts"""
    
    INJECTION_PATTERNS = [
        r'ignore\s+(previous|above|all)\s+instructions',
        r'disregard\s+.+\s+instructions',
        r'you\s+are\s+now',
        r'new\s+instructions',
        r'system\s+prompt',
        r'from\s+now\s+on',
        r'act\s+as',
        r'pretend\s+(to\s+be|you\s+are)',
    ]
    
    @staticmethod
    def detect(text: str) -> Tuple[bool, str]:
        """
        Detect prompt injection attempts
        Returns: (is_injection_detected, reason)
        """
        text_lower = text.lower()
        
        for pattern in PromptInjectionDetector.INJECTION_PATTERNS:
            if re.search(pattern, text_lower):
                return True, f"Potential prompt injection detected: {pattern}"
        
        return False, ""


class OutputValidator:
    """Validate LLM outputs for quality and safety"""
    
    @staticmethod
    def validate_insight(insight: str, min_length: int = 20) -> Tuple[bool, str]:
        """Validate AI-generated insight"""
        if len(insight) < min_length:
            return False, "Insight too short to be meaningful"
        
        # Check if insight contains actual recommendations
        if not any(keyword in insight.lower() for keyword in ['recommend', 'suggest', 'should', 'consider', 'improve']):
            return False, "Insight should contain actionable recommendations"
        
        return True, ""
    
    @staticmethod
    def calculate_confidence_score(response: str, context: Dict) -> float:
        """
        Calculate confidence score for LLM response based on various factors
        Returns: confidence score (0.0 to 1.0)
        """
        score = 0.5  # Base score
        
        # Check response length (should be substantial)
        if len(response) > 100:
            score += 0.1
        if len(response) > 300:
            score += 0.1
        
        # Check for structured content
        if any(marker in response for marker in ['1.', '2.', '-', '•']):
            score += 0.1
        
        # Check for data quality keywords
        dq_keywords = ['complete', 'correct', 'duplicate', 'quality', 'valid', 'missing', 'null']
        keyword_count = sum(1 for keyword in dq_keywords if keyword in response.lower())
        score += min(keyword_count * 0.05, 0.2)
        
        return min(score, 1.0)
