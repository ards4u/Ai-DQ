"""
Guardrails for LLM interactions - Input and Output validation
"""
import re
from typing import Tuple, List, Dict
from config.settings import GUARDRAILS_CONFIG


class PromptGuardrails:
    """Validates and sanitizes user prompts before sending to LLM"""
    
    def __init__(self):
        self.max_length = GUARDRAILS_CONFIG['max_prompt_length']
        self.blocked_keywords = GUARDRAILS_CONFIG['blocked_keywords']
        
    def validate_prompt(self, prompt: str) -> Tuple[bool, str, str]:
        """
        Validate user prompt
        Returns: (is_valid, cleaned_prompt, error_message)
        """
        if not prompt or not prompt.strip():
            return False, "", "Empty prompt provided"
        
        # Check length
        if len(prompt) > self.max_length:
            return False, "", f"Prompt too long. Maximum {self.max_length} characters allowed"
        
        # Check for SQL injection attempts
        for keyword in self.blocked_keywords:
            if keyword.lower() in prompt.lower():
                return False, "", f"Potentially harmful keyword detected: {keyword}"
        
        # Check for prompt injection attempts
        injection_patterns = [
            r'ignore\s+previous\s+instructions',
            r'ignore\s+all\s+instructions',
            r'disregard\s+.*\s+instructions',
            r'you\s+are\s+now',
            r'forget\s+everything',
            r'system:\s*',
            r'<\|im_start\|>',
            r'<\|im_end\|>'
        ]
        
        for pattern in injection_patterns:
            if re.search(pattern, prompt, re.IGNORECASE):
                return False, "", "Potential prompt injection detected"
        
        # Sanitize prompt
        cleaned_prompt = self._sanitize_prompt(prompt)
        
        return True, cleaned_prompt, ""
    
    def _sanitize_prompt(self, prompt: str) -> str:
        """Remove potentially harmful content"""
        # Remove excessive whitespace
        cleaned = ' '.join(prompt.split())
        
        # Remove special characters that might be used for injection
        cleaned = re.sub(r'[<>{}]', '', cleaned)
        
        return cleaned.strip()


class ResponseGuardrails:
    """Validates and filters LLM responses"""
    
    def __init__(self):
        self.max_length = GUARDRAILS_CONFIG['max_response_length']
        self.enable_filter = GUARDRAILS_CONFIG['enable_content_filter']
        
    def validate_response(self, response: str) -> Tuple[bool, str, str]:
        """
        Validate LLM response
        Returns: (is_valid, filtered_response, warning_message)
        """
        if not response or not response.strip():
            return False, "", "Empty response from LLM"
        
        # Check length
        if len(response) > self.max_length:
            response = response[:self.max_length] + "... [truncated]"
        
        # Filter harmful content
        if self.enable_filter:
            filtered_response, has_issues = self._filter_content(response)
            if has_issues:
                return True, filtered_response, "Response was filtered for safety"
        else:
            filtered_response = response
        
        return True, filtered_response, ""
    
    def _filter_content(self, response: str) -> Tuple[str, bool]:
        """Filter potentially harmful content from response"""
        has_issues = False
        filtered = response
        
        # Check for data exposure (credit card, SSN patterns)
        cc_pattern = r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b'
        ssn_pattern = r'\b\d{3}-\d{2}-\d{4}\b'
        
        if re.search(cc_pattern, filtered) or re.search(ssn_pattern, filtered):
            filtered = re.sub(cc_pattern, '[REDACTED-CARD]', filtered)
            filtered = re.sub(ssn_pattern, '[REDACTED-SSN]', filtered)
            has_issues = True
        
        # Check for SQL/code injection in response
        sql_patterns = [
            r'DROP\s+TABLE',
            r'DELETE\s+FROM',
            r'TRUNCATE\s+TABLE',
            r'UPDATE\s+.*\s+SET'
        ]
        
        for pattern in sql_patterns:
            if re.search(pattern, filtered, re.IGNORECASE):
                has_issues = True
        
        return filtered, has_issues


class DQRulesGuardrails:
    """Validates data quality rules to prevent malicious rules"""
    
    @staticmethod
    def validate_rule(rule_dict: Dict) -> Tuple[bool, str]:
        """
        Validate a DQ rule
        Returns: (is_valid, error_message)
        """
        required_fields = ['rule_name', 'field_name', 'rule_type', 'rule_logic']
        
        # Check required fields
        for field in required_fields:
            if field not in rule_dict:
                return False, f"Missing required field: {field}"
        
        # Validate rule type
        valid_types = ['completeness', 'correctness', 'uniqueness', 'consistency', 'validity']
        if rule_dict['rule_type'] not in valid_types:
            return False, f"Invalid rule type. Must be one of: {', '.join(valid_types)}"
        
        # Check rule logic for dangerous patterns
        rule_logic = rule_dict.get('rule_logic', '')
        dangerous_patterns = ['exec', 'eval', 'compile', '__import__', 'open(', 'file(']
        
        for pattern in dangerous_patterns:
            if pattern in rule_logic.lower():
                return False, f"Potentially dangerous operation in rule logic: {pattern}"
        
        return True, ""


# Initialize global guardrails
prompt_guardrails = PromptGuardrails()
response_guardrails = ResponseGuardrails()
rules_guardrails = DQRulesGuardrails()
