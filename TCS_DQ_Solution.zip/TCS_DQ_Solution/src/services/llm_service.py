"""
LLM Service for interacting with TCS GenAI Lab API
"""
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
import httpx
from typing import Dict, Optional, List

# TCS GenAI Lab Configuration
TCS_GENAI_BASE_URL = "https://genailab.tcs.in"
TCS_GENAI_MODEL = "azure_ai/genailab-maas-DeepSeek-V3-0324"  # Fixed: azure_ai not azure.ai
TCS_GENAI_API_KEY = "sk-oSjfXrMd6fAVjFUG7c89TQ"

# Guardrails configuration
GUARDRAILS_CONFIG = {
    'max_prompt_length': 2000,
    'max_response_length': 5000,
    'temperature': 0.7,
    'top_p': 0.9
}

# Import guardrails
try:
    from src.guardrails.llm_guardrails import LLMGuardrails, PromptInjectionDetector, OutputValidator
except ImportError:
    from guardrails.llm_guardrails import LLMGuardrails, PromptInjectionDetector, OutputValidator


class LLMService:
    """Service to interact with TCS GenAI Lab LLM with guardrails"""
    
    def __init__(self, api_key: str = None):
        # Use provided api_key, or fall back to module-level constant
        self.api_key = api_key if api_key else TCS_GENAI_API_KEY
        self.base_url = TCS_GENAI_BASE_URL
        self.model = TCS_GENAI_MODEL
        
        # Create HTTP client with SSL verification disabled (matching working code)
        self.http_client = httpx.Client(
            timeout=60.0,
            verify=False  # CRITICAL: Disabled SSL verification like working code
        )
        
        # Initialize LangChain ChatOpenAI client (matching working code exactly)
        self.llm = ChatOpenAI(
            base_url=self.base_url,
            model=self.model,
            api_key=self.api_key,
            http_client=self.http_client,
            temperature=GUARDRAILS_CONFIG['temperature'],  # 0.7 like working code
            max_tokens=2000
        )
        
        # Initialize guardrails
        self.guardrails = LLMGuardrails(
            max_prompt_length=GUARDRAILS_CONFIG['max_prompt_length'],
            max_response_length=GUARDRAILS_CONFIG['max_response_length']
        )
        
        print(f"✓ LLM Service initialized: DeepSeek-V3 (TCS GenAI Lab)")
    
    def _simple_call_llm(self, messages: List) -> str:
        """
        Simple LLM call matching the working code pattern
        """
        try:
            response = self.llm.invoke(messages)
            return response.content
        except Exception as e:
            print(f"Error calling LLM: {e}")
            return None
    
    def generate_dq_insights(self, context: Dict) -> Dict:
        """
        Generate data quality insights using LLM with guardrails
        """
        try:
            # Create safe prompt
            prompt = self.guardrails.get_safe_prompt_template(context)
            
            # Validate prompt
            is_valid, error, sanitized_prompt = self.guardrails.validate_prompt(prompt)
            if not is_valid:
                return {
                    'success': False,
                    'error': error,
                    'insights': None
                }
            
            # Check for prompt injection
            is_injection, injection_reason = PromptInjectionDetector.detect(sanitized_prompt)
            if is_injection:
                return {
                    'success': False,
                    'error': f'Security violation: {injection_reason}',
                    'insights': None
                }
            
            # Call TCS GenAI Lab API
            response = self._call_llm(sanitized_prompt)
            
            if not response:
                return {
                    'success': False,
                    'error': 'Failed to get response from LLM',
                    'insights': None
                }
            
            # Validate response
            is_valid, error, sanitized_response = self.guardrails.validate_response(response)
            if not is_valid:
                return {
                    'success': False,
                    'error': error,
                    'insights': None
                }
            
            # Validate insight quality
            is_quality, quality_msg = OutputValidator.validate_insight(sanitized_response)
            
            # Calculate confidence score
            confidence = OutputValidator.calculate_confidence_score(sanitized_response, context)
            
            # Format response
            formatted_insights = self.guardrails.format_llm_response(sanitized_response)
            
            return {
                'success': True,
                'error': None,
                'raw_response': sanitized_response,
                'insights': formatted_insights,
                'confidence_score': confidence,
                'quality_check': {
                    'passed': is_quality,
                    'message': quality_msg if not is_quality else 'Quality check passed'
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Error generating insights: {str(e)}',
                'insights': None
            }
    
    def _call_llm(self, prompt: str) -> Optional[str]:
        """
        Call TCS GenAI Lab API to generate response
        """
        try:
            # Create system message for data quality expert
            system_message = SystemMessage(
                content="You are a Data Quality Analysis Expert specialized in identifying data issues and providing actionable recommendations."
            )
            
            # Create human message with the prompt
            human_message = HumanMessage(content=prompt)
            
            # Invoke the LLM
            response = self.llm.invoke([system_message, human_message])
            
            # Extract content from response
            if hasattr(response, 'content'):
                return response.content
            else:
                return str(response)
                
        except httpx.ConnectError:
            print("Cannot connect to TCS GenAI Lab API. Please check your network connection.")
            return None
        except httpx.TimeoutException:
            print("Request to TCS GenAI Lab API timed out.")
            return None
        except Exception as e:
            print(f"Error calling TCS GenAI Lab API: {str(e)}")
            return None
    
    def analyze_field_quality(self, field_stats: Dict) -> Dict:
        """
        Analyze field-level data quality and generate insights
        """
        context = {
            'level': 'field',
            'entity_name': field_stats.get('field_name', 'Unknown'),
            'domain': field_stats.get('domain', 'Unknown'),
            'completeness_score': field_stats.get('completeness_score', 0),
            'correctness_score': field_stats.get('correctness_score', 0),
            'uniqueness_score': field_stats.get('uniqueness_score', 0),
            'consistency_score': field_stats.get('consistency_score', 0),
            'overall_score': field_stats.get('overall_score', 0),
            'issues': self._format_issues(field_stats.get('issues', []))
        }
        
        return self.generate_dq_insights(context)
    
    def analyze_table_quality(self, table_stats: Dict) -> Dict:
        """
        Analyze table-level data quality and generate insights
        """
        context = {
            'level': 'table',
            'entity_name': table_stats.get('table_name', 'Unknown'),
            'domain': table_stats.get('domain', 'Unknown'),
            'completeness_score': table_stats.get('completeness_score', 0),
            'correctness_score': table_stats.get('correctness_score', 0),
            'uniqueness_score': table_stats.get('uniqueness_score', 0),
            'consistency_score': table_stats.get('consistency_score', 0),
            'overall_score': table_stats.get('overall_score', 0),
            'issues': self._format_issues(table_stats.get('issues', []))
        }
        
        return self.generate_dq_insights(context)
    
    def analyze_domain_quality(self, domain_stats: Dict) -> Dict:
        """
        Analyze domain-level data quality and generate insights
        """
        context = {
            'level': 'domain',
            'entity_name': domain_stats.get('domain_name', 'Unknown'),
            'domain': domain_stats.get('domain_name', 'Unknown'),
            'completeness_score': domain_stats.get('completeness_score', 0),
            'correctness_score': domain_stats.get('correctness_score', 0),
            'uniqueness_score': domain_stats.get('uniqueness_score', 0),
            'consistency_score': domain_stats.get('consistency_score', 0),
            'overall_score': domain_stats.get('overall_score', 0),
            'issues': self._format_issues(domain_stats.get('issues', []))
        }
        
        return self.generate_dq_insights(context)
    
    def _format_issues(self, issues: List[Dict]) -> str:
        """Format issues list into readable text"""
        if not issues:
            return "No major issues detected"
        
        formatted = []
        for i, issue in enumerate(issues, 1):
            formatted.append(f"{i}. {issue.get('description', 'Unknown issue')} "
                           f"(Severity: {issue.get('severity', 'Unknown')})")
        
        return '\n'.join(formatted)
    
    def test_connection(self) -> Dict:
        """Test connection to TCS GenAI Lab API"""
        try:
            # Simple test query
            test_message = HumanMessage(content="Test")
            response = self.llm.invoke([test_message])
            return {
                'success': True,
                'model': 'DeepSeek-V3',
                'message': 'Connected successfully'
            }
        except Exception as e:
            print(f"Connection test failed: {str(e)}")
            return {
                'success': False,
                'model': 'DeepSeek-V3',
                'error': str(e),
                'message': 'Connection failed'
            }
    
    def generate_grade_remarks(self, analysis_data: Dict) -> Dict:
        """
        Generate AI remarks explaining the quality grade
        """
        try:
            table_name = analysis_data.get('table_name', 'data')
            scores = analysis_data.get('table_scores', {})
            issues = analysis_data.get('issues', [])
            
            prompt = f"""Analyze this data quality report and provide a brief explanation (2-3 sentences) of why it received this grade.

Table: {table_name}
Overall Score: {scores.get('overall_score', 0):.1f}%
Grade: {scores.get('quality_grade', 'N/A')}

Scores:
- Completeness: {scores.get('completeness_score', 0):.1f}%
- Correctness: {scores.get('correctness_score', 0):.1f}%
- Uniqueness: {scores.get('uniqueness_score', 0):.1f}%
- Consistency: {scores.get('consistency_score', 0):.1f}%

Issues Found: {len(issues)}

Provide a concise explanation covering:
1. Why this grade was assigned
2. Main strengths (1 sentence)
3. Key improvement areas (1 sentence)

Keep it professional and actionable."""

            messages = [
                SystemMessage(content="You are a data quality expert providing concise analysis remarks."),
                HumanMessage(content=prompt)
            ]
            
            response = self.llm.invoke(messages)
            
            return {
                'success': True,
                'remarks': response.content,
                'model': 'DeepSeek-V3'
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'remarks': 'AI remarks generation unavailable. Analysis completed without AI insights.'
            }
    
    def suggest_dq_rules(self) -> Dict:
        """
        Generate AI suggestions for new DQ rules
        """
        try:
            prompt = """As a data quality expert, suggest 3 new data quality rules that would be valuable for enterprise data management.

For each rule, provide:
1. Rule Name (concise, descriptive)
2. Description (what it checks, why it's important)
3. Rule Type (completeness/correctness/uniqueness/consistency/date_validation)
4. Suggested Weight (0.10 to 0.25)

Focus on practical, commonly needed rules that aren't basic null/duplicate checks.

Format as JSON array:
[
  {
    "name": "Rule Name",
    "description": "Detailed description",
    "rule_type": "type",
    "weight": 0.15,
    "rationale": "Why this rule is important"
  }
]"""

            messages = [
                SystemMessage(content="You are a data quality expert suggesting practical DQ rules."),
                HumanMessage(content=prompt)
            ]
            
            response = self.llm.invoke(messages)
            
            # Try to parse JSON response
            import json
            import re
            
            # Extract JSON from response
            content = response.content
            json_match = re.search(r'\[.*\]', content, re.DOTALL)
            if json_match:
                suggestions = json.loads(json_match.group())
            else:
                # Fallback: create structured suggestions from text
                suggestions = [
                    {
                        "name": "Email Domain Validation",
                        "description": "Validates email domains against list of valid/active domains",
                        "rule_type": "correctness",
                        "weight": 0.15,
                        "rationale": "Prevents use of disposable or invalid email domains"
                    },
                    {
                        "name": "Phone Format Standardization",
                        "description": "Ensures consistent phone number format across records",
                        "rule_type": "consistency",
                        "weight": 0.12,
                        "rationale": "Improves data usability and integration"
                    },
                    {
                        "name": "Salary Range Validation",
                        "description": "Checks salary values against expected ranges for designations",
                        "rule_type": "correctness",
                        "weight": 0.18,
                        "rationale": "Detects data entry errors and anomalies"
                    }
                ]
            
            return {
                'success': True,
                'suggestions': suggestions,
                'model': 'DeepSeek-V3'
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'suggestions': []
            }

