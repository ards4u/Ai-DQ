"""
Data Quality Score Calculator
"""
import pandas as pd
from sqlalchemy import create_engine, text
from config.settings import DATABASE_URL, SCORE_THRESHOLDS
from src.models.database import get_session, FieldScore, TableScore, DomainScore, DataField, DataTable, Domain
from datetime import datetime


class DQScoreCalculator:
    """Calculate data quality scores at field, table, and domain levels"""
    
    def __init__(self):
        self.session = get_session()
        self.engine = create_engine(DATABASE_URL)
        
    def calculate_all_scores(self):
        """Calculate scores for all levels"""
        print("📊 Calculating Data Quality Scores...")
        
        # Calculate field-level scores
        field_scores = self.calculate_field_scores()
        print(f"  ✓ Calculated scores for {len(field_scores)} fields")
        
        # Calculate table-level scores
        table_scores = self.calculate_table_scores()
        print(f"  ✓ Calculated scores for {len(table_scores)} tables")
        
        # Calculate domain-level scores
        domain_scores = self.calculate_domain_scores()
        print(f"  ✓ Calculated scores for {len(domain_scores)} domains")
        
        return {
            'field_scores': field_scores,
            'table_scores': table_scores,
            'domain_scores': domain_scores
        }
    
    def calculate_field_scores(self):
        """Calculate field-level DQ scores"""
        fields = self.session.query(DataField).all()
        field_scores = []
        
        for field in fields:
            table = field.table
            
            try:
                # Get data from the table
                query = f"SELECT `{field.name}` FROM `{table.name}`"
                df = pd.read_sql(query, self.engine)
                
                total_records = len(df)
                if total_records == 0:
                    continue
                
                # Calculate completeness score
                null_count = df[field.name].isnull().sum()
                completeness_score = ((total_records - null_count) / total_records) * 100
                
                # Calculate correctness score
                invalid_count = self._count_invalid_values(df[field.name], field.name)
                correctness_score = ((total_records - invalid_count) / total_records) * 100
                
                # Calculate uniqueness score
                duplicate_count = total_records - df[field.name].nunique()
                uniqueness_score = (df[field.name].nunique() / total_records) * 100 if total_records > 0 else 0
                
                # Calculate overall score
                overall_score = (completeness_score + correctness_score + uniqueness_score) / 3
                
                # Save score
                score = FieldScore(
                    field_id=field.id,
                    completeness_score=round(completeness_score, 2),
                    correctness_score=round(correctness_score, 2),
                    uniqueness_score=round(uniqueness_score, 2),
                    overall_score=round(overall_score, 2),
                    total_records=total_records,
                    null_count=int(null_count),
                    duplicate_count=int(duplicate_count),
                    invalid_count=int(invalid_count),
                    calculated_at=datetime.utcnow()
                )
                self.session.add(score)
                field_scores.append(score)
                
            except Exception as e:
                print(f"  ⚠ Error calculating score for {table.name}.{field.name}: {str(e)}")
        
        self.session.commit()
        return field_scores
    
    def calculate_table_scores(self):
        """Calculate table-level DQ scores by aggregating field scores"""
        tables = self.session.query(DataTable).all()
        table_scores = []
        
        for table in tables:
            field_scores = self.session.query(FieldScore).join(DataField).filter(
                DataField.table_id == table.id
            ).all()
            
            if not field_scores:
                continue
            
            # Aggregate field scores
            avg_completeness = sum(fs.completeness_score for fs in field_scores) / len(field_scores)
            avg_correctness = sum(fs.correctness_score for fs in field_scores) / len(field_scores)
            avg_uniqueness = sum(fs.uniqueness_score for fs in field_scores) / len(field_scores)
            avg_overall = (avg_completeness + avg_correctness + avg_uniqueness) / 3
            
            score = TableScore(
                table_id=table.id,
                completeness_score=round(avg_completeness, 2),
                correctness_score=round(avg_correctness, 2),
                uniqueness_score=round(avg_uniqueness, 2),
                overall_score=round(avg_overall, 2),
                calculated_at=datetime.utcnow()
            )
            self.session.add(score)
            table_scores.append(score)
        
        self.session.commit()
        return table_scores
    
    def calculate_domain_scores(self):
        """Calculate domain-level DQ scores by aggregating table scores"""
        domains = self.session.query(Domain).all()
        domain_scores = []
        
        for domain in domains:
            table_scores = self.session.query(TableScore).join(DataTable).filter(
                DataTable.domain_id == domain.id
            ).all()
            
            if not table_scores:
                continue
            
            # Aggregate table scores
            avg_completeness = sum(ts.completeness_score for ts in table_scores) / len(table_scores)
            avg_correctness = sum(ts.correctness_score for ts in table_scores) / len(table_scores)
            avg_uniqueness = sum(ts.uniqueness_score for ts in table_scores) / len(table_scores)
            avg_overall = (avg_completeness + avg_correctness + avg_uniqueness) / 3
            
            score = DomainScore(
                domain_id=domain.id,
                completeness_score=round(avg_completeness, 2),
                correctness_score=round(avg_correctness, 2),
                uniqueness_score=round(avg_uniqueness, 2),
                overall_score=round(avg_overall, 2),
                calculated_at=datetime.utcnow()
            )
            self.session.add(score)
            domain_scores.append(score)
        
        self.session.commit()
        return domain_scores
    
    def _count_invalid_values(self, series, field_name):
        """Count invalid values based on field-specific rules"""
        invalid_count = 0
        
        # Phone number validation
        if 'phone' in field_name.lower():
            invalid_count = series.apply(lambda x: 
                str(x) in ['9999999999', '0000000000', '1111111111'] if pd.notna(x) else False
            ).sum()
        
        # Email validation
        elif 'email' in field_name.lower():
            invalid_count = series.apply(lambda x: 
                '@' not in str(x) if pd.notna(x) else False
            ).sum()
        
        # Amount validation (should be positive)
        elif 'amount' in field_name.lower() or 'salary' in field_name.lower():
            invalid_count = series.apply(lambda x: 
                float(x) <= 0 if pd.notna(x) else False
            ).sum()
        
        return invalid_count
    
    def get_score_category(self, score):
        """Get score category based on thresholds"""
        if score >= SCORE_THRESHOLDS['excellent']:
            return 'excellent', '#10b981'  # green
        elif score >= SCORE_THRESHOLDS['good']:
            return 'good', '#3b82f6'  # blue
        elif score >= SCORE_THRESHOLDS['fair']:
            return 'fair', '#f59e0b'  # yellow
        else:
            return 'poor', '#ef4444'  # red
    
    def get_field_comparison(self, field_name, table_name):
        """Compare duplicate fields across tables"""
        fields = self.session.query(DataField).filter(DataField.name == field_name).all()
        
        if len(fields) <= 1:
            return None
        
        comparisons = []
        for field in fields:
            score = self.session.query(FieldScore).filter(
                FieldScore.field_id == field.id
            ).order_by(FieldScore.calculated_at.desc()).first()
            
            if score:
                comparisons.append({
                    'table': field.table.name,
                    'domain': field.table.domain.name,
                    'overall_score': score.overall_score,
                    'completeness': score.completeness_score,
                    'correctness': score.correctness_score,
                    'uniqueness': score.uniqueness_score
                })
        
        # Sort by overall score
        comparisons.sort(key=lambda x: x['overall_score'], reverse=True)
        return comparisons


def calculate_dq_scores():
    """Main function to calculate all DQ scores"""
    calculator = DQScoreCalculator()
    return calculator.calculate_all_scores()
