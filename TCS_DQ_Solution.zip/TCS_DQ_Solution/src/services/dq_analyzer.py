"""
Data Quality Analyzer Service
Calculates DQ scores at field, table, and domain levels
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from datetime import datetime
import re


class DataQualityAnalyzer:
    """Analyze data quality at various levels"""
    
    # Default values to check for correctness issues
    DEFAULT_VALUES = {
        'phone': ['9999999999', '0000000000', '1111111111', '1234567890'],
        'email': ['test@test.com', 'example@example.com', 'noreply@noreply.com'],
        'name': ['test', 'dummy', 'unknown', 'n/a', 'na'],
        'date': ['1900-01-01', '9999-12-31', '0000-00-00'],
        'amount': [0, 0.0, -1, 999999999]
    }
    
    def __init__(self, dq_rules: List[Dict] = None):
        self.dq_rules = dq_rules or []
        self.field_scores = {}
    
    def analyze_dataframe(self, df: pd.DataFrame, table_name: str = "data") -> Dict:
        """
        Comprehensive data quality analysis of a DataFrame
        """
        if df is None or df.empty:
            return self._empty_result()
        
        total_rows = len(df)
        field_analyses = []
        
        # Analyze each field
        for column in df.columns:
            field_analysis = self.analyze_field(df, column, total_rows)
            field_analyses.append(field_analysis)
        
        # Calculate table-level scores
        table_scores = self._aggregate_field_scores(field_analyses)
        
        # Find duplicates at table level - only check key fields
        duplicate_info = self._find_key_duplicates(df, table_name)
        
        result = {
            'table_name': table_name,
            'total_records': int(total_rows),  # Convert to Python int
            'total_fields': int(len(df.columns)),  # Convert to Python int
            'field_analyses': field_analyses,
            'table_scores': table_scores,
            'duplicates': duplicate_info,
            'issues': self._identify_table_issues(field_analyses, table_scores, duplicate_info)
        }
        
        # Ensure all values are JSON serializable
        return self._make_json_serializable(result)
    
    def _find_key_duplicates(self, df: pd.DataFrame, table_name: str) -> Dict:
        """
        Find duplicates only in key fields: IDs, emails, phone numbers
        """
        key_fields = {
            'ids': [col for col in df.columns if col.lower() in ['id', 'employee_id', 'invoice_id', 'expense_id', 'invoice_number', 'expense_id']],
            'emails': [col for col in df.columns if 'email' in col.lower()],
            'phones': [col for col in df.columns if 'phone' in col.lower() or 'mobile' in col.lower()]
        }
        
        duplicates = {
            'total_duplicate_records': 0,
            'duplicate_percentage': 0.0,
            'key_field_duplicates': []
        }
        
        total_rows = len(df)
        
        for field_type, columns in key_fields.items():
            for col in columns:
                if col in df.columns:
                    # Find duplicates in this key field
                    dup_mask = df[col].duplicated(keep=False)
                    dup_count = dup_mask.sum()
                    
                    if dup_count > 0:
                        # Get duplicate values and their occurrences
                        dup_values = df[dup_mask][col].value_counts().head(20)
                        
                        dup_details = []
                        for value, count in dup_values.items():
                            dup_rows = df[df[col] == value]
                            row_numbers = [int(idx) + 1 for idx in dup_rows.index.tolist()]
                            
                            dup_details.append({
                                'value': str(value),
                                'occurrences': int(count),
                                'row_numbers': row_numbers[:10]  # First 10 occurrences
                            })
                        
                        duplicates['key_field_duplicates'].append({
                            'field': col,
                            'field_type': field_type,
                            'duplicate_count': int(dup_count),
                            'unique_duplicate_values': int(len(dup_values)),
                            'details': dup_details
                        })
                        
                        duplicates['total_duplicate_records'] += dup_count
        
        if total_rows > 0:
            duplicates['duplicate_percentage'] = float((duplicates['total_duplicate_records'] / total_rows) * 100)
        
        return duplicates
    
    def analyze_field(self, df: pd.DataFrame, column: str, total_rows: int) -> Dict:
        """
        Analyze data quality for a single field with detailed problem tracking
        """
        series = df[column]
        
        # Completeness check with problem records
        completeness_score, completeness_problems = self._calculate_completeness_with_details(df, column, total_rows)
        
        # Correctness check with problem records
        correctness_score, correctness_issues = self._calculate_correctness_with_details(df, column)
        
        # Uniqueness check
        uniqueness_score = self._calculate_uniqueness(series, total_rows)
        
        # Consistency check
        consistency_score = self._calculate_consistency(series)
        
        # Overall score (weighted average)
        overall_score = (
            completeness_score * 0.3 +
            correctness_score * 0.3 +
            uniqueness_score * 0.2 +
            consistency_score * 0.2
        )
        
        return {
            'field_name': column,
            'data_type': str(series.dtype),
            'completeness_score': float(completeness_score),
            'correctness_score': float(correctness_score),
            'uniqueness_score': float(uniqueness_score),
            'consistency_score': float(consistency_score),
            'overall_score': float(overall_score),
            'quality_grade': self._get_quality_grade(overall_score),
            'score_calculation': {
                'formula': 'Completeness(30%) + Correctness(30%) + Uniqueness(20%) + Consistency(20%)',
                'breakdown': {
                    'completeness': f'{completeness_score:.1f} × 0.30 = {completeness_score * 0.3:.1f}',
                    'correctness': f'{correctness_score:.1f} × 0.30 = {correctness_score * 0.3:.1f}',
                    'uniqueness': f'{uniqueness_score:.1f} × 0.20 = {uniqueness_score * 0.2:.1f}',
                    'consistency': f'{consistency_score:.1f} × 0.20 = {consistency_score * 0.2:.1f}'
                }
            },
            'statistics': {
                'null_count': int(series.isnull().sum()),
                'null_percentage': float(series.isnull().sum() / total_rows * 100),
                'unique_count': int(series.nunique()),
                'unique_percentage': float(series.nunique() / total_rows * 100)
            },
            'issues': correctness_issues,
            'problem_records': completeness_problems
        }
    
    def _calculate_completeness(self, series: pd.Series, total_rows: int) -> float:
        """
        Calculate completeness score (percentage of non-null values)
        """
        if total_rows == 0:
            return 100.0
        
        non_null_count = series.notna().sum()
        completeness = (non_null_count / total_rows) * 100
        
        # Also check for empty strings in string columns
        if series.dtype == 'object':
            non_empty_count = series.apply(lambda x: bool(str(x).strip()) if pd.notna(x) else False).sum()
            completeness = (non_empty_count / total_rows) * 100
        
        return float(completeness)
    
    def _calculate_completeness_with_details(self, df: pd.DataFrame, column: str, total_rows: int) -> Tuple[float, List[Dict]]:
        """
        Calculate completeness score with problem record details
        """
        series = df[column]
        problem_records = []
        
        if total_rows == 0:
            return 100.0, []
        
        # Find null/empty records
        if series.dtype == 'object':
            mask = series.isna() | (series.astype(str).str.strip() == '')
        else:
            mask = series.isna()
        
        problem_indices = df[mask].index.tolist()
        
        # Get identifying columns (id, keys, emails, phone)
        id_cols = [col for col in df.columns if col.lower() in ['id', 'employee_id', 'invoice_id', 'expense_id', 'invoice_number', 'employee_id']]
        key_cols = [col for col in df.columns if col.lower() in ['email', 'phone', 'mobile', 'employee_id']]
        
        for idx in problem_indices[:100]:  # Limit to first 100 problems
            record_info = {
                'row_number': int(idx) + 1,
                'field': column,
                'value': None,
                'identifiers': {}
            }
            
            # Add identifying information
            for id_col in id_cols:
                if id_col in df.columns:
                    record_info['identifiers'][id_col] = str(df.loc[idx, id_col]) if pd.notna(df.loc[idx, id_col]) else 'N/A'
            
            for key_col in key_cols:
                if key_col in df.columns and key_col != column:
                    record_info['identifiers'][key_col] = str(df.loc[idx, key_col]) if pd.notna(df.loc[idx, key_col]) else 'N/A'
            
            problem_records.append(record_info)
        
        non_null_count = series.notna().sum()
        completeness = (non_null_count / total_rows) * 100
        
        if series.dtype == 'object':
            non_empty_count = series.apply(lambda x: bool(str(x).strip()) if pd.notna(x) else False).sum()
            completeness = (non_empty_count / total_rows) * 100
        
        return float(completeness), problem_records
    
    def _calculate_correctness(self, series: pd.Series, column_name: str) -> Tuple[float, List[Dict]]:
        """
        Calculate correctness score (checking for default/invalid values)
        """
        issues = []
        total_count = len(series)
        invalid_count = 0
        
        if total_count == 0:
            return 100.0, issues
        
        # Check based on column name patterns
        column_lower = column_name.lower()
        
        # Phone number checks
        if 'phone' in column_lower or 'mobile' in column_lower:
            for default_val in self.DEFAULT_VALUES['phone']:
                invalid = (series.astype(str) == default_val).sum()
                if invalid > 0:
                    invalid_count += invalid
                    issues.append({
                        'type': 'default_value',
                        'description': f'Found {invalid} instances of default phone number: {default_val}',
                        'severity': 'medium',
                        'count': int(invalid)
                    })
        
        # Email checks
        elif 'email' in column_lower:
            for default_val in self.DEFAULT_VALUES['email']:
                invalid = (series.astype(str).str.lower() == default_val).sum()
                if invalid > 0:
                    invalid_count += invalid
                    issues.append({
                        'type': 'default_value',
                        'description': f'Found {invalid} instances of default email: {default_val}',
                        'severity': 'medium',
                        'count': int(invalid)
                    })
            
            # Check email format
            valid_emails = series.dropna().astype(str).apply(self._is_valid_email)
            invalid_format = (~valid_emails).sum()
            if invalid_format > 0:
                invalid_count += invalid_format
                issues.append({
                    'type': 'invalid_format',
                    'description': f'Found {invalid_format} emails with invalid format',
                    'severity': 'high',
                    'count': int(invalid_format)
                })
        
        # Name checks
        elif 'name' in column_lower:
            for default_val in self.DEFAULT_VALUES['name']:
                invalid = (series.astype(str).str.lower().str.strip() == default_val).sum()
                if invalid > 0:
                    invalid_count += invalid
                    issues.append({
                        'type': 'default_value',
                        'description': f'Found {invalid} instances of placeholder name: {default_val}',
                        'severity': 'low',
                        'count': int(invalid)
                    })
        
        # Numeric checks - only for amount/salary fields
        elif pd.api.types.is_numeric_dtype(series) and any(kw in column_lower for kw in ['amount', 'salary', 'price', 'cost']):
            if series.notna().sum() > 0:
                # Check for negative values only in fields where they shouldn't be
                negative_count = (series < 0).sum()
                if negative_count > 0:
                    invalid_count += negative_count
                    issues.append({
                        'type': 'invalid_value',
                        'description': f'Found {negative_count} negative values in {column_name}',
                        'severity': 'high',
                        'count': int(negative_count)
                    })
                
                # Check for zeros in critical fields
                zero_count = (series == 0).sum()
                if zero_count > total_count * 0.3:
                    issues.append({
                        'type': 'suspicious_pattern',
                        'description': f'High percentage ({zero_count/total_count*100:.1f}%) of zero values',
                        'severity': 'medium',
                        'count': int(zero_count)
                    })
        
        correctness = ((total_count - invalid_count) / total_count) * 100
        return float(correctness), issues
    
    def _calculate_correctness_with_details(self, df: pd.DataFrame, column: str) -> Tuple[float, List[Dict]]:
        """
        Calculate correctness with detailed problem records
        """
        series = df[column]
        issues = []
        total_count = len(series)
        invalid_count = 0
        
        if total_count == 0:
            return 100.0, issues
        
        column_lower = column.lower()
        
        # Get identifying columns
        id_cols = [col for col in df.columns if col.lower() in ['id', 'employee_id', 'invoice_id', 'expense_id', 'invoice_number']]
        
        # Phone number checks with details
        if 'phone' in column_lower or 'mobile' in column_lower:
            for default_val in self.DEFAULT_VALUES['phone']:
                mask = series.astype(str) == default_val
                invalid_records = df[mask]
                invalid_count += len(invalid_records)
                
                if len(invalid_records) > 0:
                    problem_details = []
                    for idx, row in invalid_records.head(50).iterrows():
                        detail = {
                            'row_number': int(idx) + 1,
                            'value': default_val,
                            'identifiers': {id_col: str(row[id_col]) for id_col in id_cols if id_col in df.columns}
                        }
                        problem_details.append(detail)
                    
                    issues.append({
                        'type': 'default_value',
                        'description': f'Found {len(invalid_records)} instances of default phone: {default_val}',
                        'severity': 'medium',
                        'count': int(len(invalid_records)),
                        'problem_records': problem_details
                    })
        
        # Email checks with details
        elif 'email' in column_lower:
            for default_val in self.DEFAULT_VALUES['email']:
                mask = series.astype(str).str.lower() == default_val
                invalid_records = df[mask]
                invalid_count += len(invalid_records)
                
                if len(invalid_records) > 0:
                    problem_details = []
                    for idx, row in invalid_records.head(50).iterrows():
                        detail = {
                            'row_number': int(idx) + 1,
                            'value': str(row[column]),
                            'identifiers': {id_col: str(row[id_col]) for id_col in id_cols if id_col in df.columns}
                        }
                        problem_details.append(detail)
                    
                    issues.append({
                        'type': 'default_value',
                        'description': f'Found {len(invalid_records)} instances of default email: {default_val}',
                        'severity': 'medium',
                        'count': int(len(invalid_records)),
                        'problem_records': problem_details
                    })
        
        # Negative values with details - only for amount/salary fields
        elif pd.api.types.is_numeric_dtype(series) and any(kw in column_lower for kw in ['amount', 'salary', 'price', 'cost']):
            mask = series < 0
            invalid_records = df[mask]
            
            if len(invalid_records) > 0:
                invalid_count += len(invalid_records)
                problem_details = []
                for idx, row in invalid_records.head(50).iterrows():
                    detail = {
                        'row_number': int(idx) + 1,
                        'value': float(row[column]),
                        'identifiers': {id_col: str(row[id_col]) for id_col in id_cols if id_col in df.columns}
                    }
                    problem_details.append(detail)
                
                issues.append({
                    'type': 'invalid_value',
                    'description': f'Found {len(invalid_records)} negative values in {column}',
                    'severity': 'high',
                    'count': int(len(invalid_records)),
                    'problem_records': problem_details
                })
        
        correctness = ((total_count - invalid_count) / total_count) * 100
        return float(correctness), issues
    
    def _calculate_uniqueness(self, series: pd.Series, total_rows: int) -> float:
        """
        Calculate uniqueness score (inverse of duplicate percentage)
        """
        if total_rows == 0:
            return 100.0
        
        unique_count = series.nunique()
        uniqueness = (unique_count / total_rows) * 100
        
        return float(min(uniqueness, 100.0))
    
    def _calculate_consistency(self, series: pd.Series) -> float:
        """
        Calculate consistency score (data format and pattern consistency)
        """
        if len(series) == 0:
            return 100.0
        
        consistency_score = 100.0
        
        # For string columns, check format consistency
        if series.dtype == 'object':
            non_null_series = series.dropna()
            if len(non_null_series) > 0:
                # Check length variation
                lengths = non_null_series.astype(str).apply(len)
                length_std = lengths.std()
                length_mean = lengths.mean()
                
                # High variation in length might indicate inconsistency
                if length_mean > 0:
                    cv = (length_std / length_mean) * 100  # Coefficient of variation
                    if cv > 50:
                        consistency_score -= 20
                
                # Check case consistency
                lower_count = non_null_series.astype(str).str.islower().sum()
                upper_count = non_null_series.astype(str).str.isupper().sum()
                mixed_percentage = (1 - (lower_count + upper_count) / len(non_null_series)) * 100
                
                if mixed_percentage > 50:
                    consistency_score -= 10
        
        return float(max(consistency_score, 0.0))
    
    def _is_valid_email(self, email: str) -> bool:
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, str(email)))
    
    def _aggregate_field_scores(self, field_analyses: List[Dict]) -> Dict:
        """
        Aggregate field-level scores to table-level
        """
        if not field_analyses:
            return self._empty_scores()
        
        completeness_scores = [f['completeness_score'] for f in field_analyses]
        correctness_scores = [f['correctness_score'] for f in field_analyses]
        uniqueness_scores = [f['uniqueness_score'] for f in field_analyses]
        consistency_scores = [f['consistency_score'] for f in field_analyses]
        overall_scores = [f['overall_score'] for f in field_analyses]
        
        return {
            'completeness_score': float(np.mean(completeness_scores)),
            'correctness_score': float(np.mean(correctness_scores)),
            'uniqueness_score': float(np.mean(uniqueness_scores)),
            'consistency_score': float(np.mean(consistency_scores)),
            'overall_score': float(np.mean(overall_scores)),
            'quality_grade': self._get_quality_grade(np.mean(overall_scores))
        }
    
    def _identify_table_issues(self, field_analyses: List[Dict], table_scores: Dict, duplicate_info: Dict) -> List[Dict]:
        """
        Identify major issues at table level
        """
        issues = []
        
        # Aggregate field-level issues
        for field in field_analyses:
            if field['issues']:
                for issue in field['issues']:
                    issues.append({
                        'field': field['field_name'],
                        **issue
                    })
        
        # Add duplicate issues with details
        if duplicate_info['key_field_duplicates']:
            for dup in duplicate_info['key_field_duplicates']:
                issues.append({
                    'type': 'key_field_duplicate',
                    'field': dup['field'],
                    'description': f"Found {dup['duplicate_count']} duplicate values in key field '{dup['field']}' ({dup['unique_duplicate_values']} unique values duplicated)",
                    'severity': 'high',
                    'count': dup['duplicate_count'],
                    'details': dup['details'][:5]  # First 5 duplicate values
                })
        
        # Add table-level issues
        if table_scores['completeness_score'] < 80:
            issues.append({
                'type': 'table_completeness',
                'description': f"Overall completeness is low ({table_scores['completeness_score']:.1f}%)",
                'severity': 'high'
            })
        
        if table_scores['correctness_score'] < 80:
            issues.append({
                'type': 'table_correctness',
                'description': f"Overall correctness is low ({table_scores['correctness_score']:.1f}%)",
                'severity': 'high'
            })
        
        return issues
    
    def _get_quality_grade(self, score: float) -> str:
        """Convert numeric score to quality grade"""
        if score >= 95:
            return 'Excellent'
        elif score >= 80:
            return 'Good'
        elif score >= 60:
            return 'Fair'
        else:
            return 'Poor'
    
    def _empty_result(self) -> Dict:
        """Return empty result structure"""
        return {
            'table_name': 'empty',
            'total_records': 0,
            'total_fields': 0,
            'field_analyses': [],
            'table_scores': self._empty_scores(),
            'duplicates': {'count': 0, 'percentage': 0.0},
            'issues': []
        }
    
    def _empty_scores(self) -> Dict:
        """Return empty scores structure"""
        return {
            'completeness_score': 0.0,
            'correctness_score': 0.0,
            'uniqueness_score': 0.0,
            'consistency_score': 0.0,
            'overall_score': 0.0,
            'quality_grade': 'N/A'
        }
    
    def analyze_domain(self, table_analyses: List[Dict]) -> Dict:
        """
        Aggregate table-level scores to domain-level
        """
        if not table_analyses:
            return self._empty_scores()
        
        all_scores = [t['table_scores'] for t in table_analyses]
        
        return {
            'completeness_score': float(np.mean([s['completeness_score'] for s in all_scores])),
            'correctness_score': float(np.mean([s['correctness_score'] for s in all_scores])),
            'uniqueness_score': float(np.mean([s['uniqueness_score'] for s in all_scores])),
            'consistency_score': float(np.mean([s['consistency_score'] for s in all_scores])),
            'overall_score': float(np.mean([s['overall_score'] for s in all_scores])),
            'quality_grade': self._get_quality_grade(np.mean([s['overall_score'] for s in all_scores]))
        }
    
    def _make_json_serializable(self, obj):
        """
        Recursively convert numpy types to Python native types for JSON serialization
        """
        if isinstance(obj, dict):
            return {key: self._make_json_serializable(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._make_json_serializable(item) for item in obj]
        elif isinstance(obj, (np.integer, np.int64, np.int32)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64, np.float32)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif pd.isna(obj):
            return None
        else:
            return obj
