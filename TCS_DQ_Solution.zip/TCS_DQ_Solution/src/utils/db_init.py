"""
Database initialization and sample data generation
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from src.models.database_models import (
    Base, Domain, SubDomain, DataTable, DataField, DQRule,
    Employee, Payroll, Invoice, Expense
)
from config.settings import DATABASE_URL, DEFAULT_DQ_RULES
from datetime import datetime, timedelta
import random


class DatabaseInitializer:
    """Initialize database and generate sample data"""
    
    def __init__(self, db_url: str = DATABASE_URL):
        self.engine = create_engine(db_url)
        self.Session = sessionmaker(bind=self.engine)
    
    def initialize_database(self):
        """Create all tables"""
        print("Creating database tables...")
        Base.metadata.create_all(self.engine)
        print("✓ Database tables created successfully")
    
    def generate_sample_data(self):
        """Generate sample data for HR and Finance domains"""
        session = self.Session()
        
        try:
            # Clear existing data
            print("\nClearing existing data...")
            session.query(Employee).delete()
            session.query(Payroll).delete()
            session.query(Invoice).delete()
            session.query(Expense).delete()
            session.query(DQRule).delete()
            session.query(Domain).delete()
            session.commit()
            
            # Create DQ Rules
            print("\nCreating DQ rules...")
            for rule_data in DEFAULT_DQ_RULES:
                rule = DQRule(**rule_data)
                session.add(rule)
            session.commit()
            print(f"✓ Created {len(DEFAULT_DQ_RULES)} DQ rules")
            
            # Create Domains
            print("\nCreating domains and sub-domains...")
            
            # HR Domain
            hr_domain = Domain(
                name="Human Resources",
                description="Employee and HR related data"
            )
            session.add(hr_domain)
            
            # Finance Domain
            finance_domain = Domain(
                name="Finance",
                description="Financial transactions and accounting data"
            )
            session.add(finance_domain)
            session.commit()
            
            # Create Sub-domains
            hr_subdomain = SubDomain(
                name="Employee Management",
                domain_id=hr_domain.id,
                description="Employee records and information"
            )
            session.add(hr_subdomain)
            
            payroll_subdomain = SubDomain(
                name="Payroll",
                domain_id=hr_domain.id,
                description="Salary and payroll processing"
            )
            session.add(payroll_subdomain)
            
            invoice_subdomain = SubDomain(
                name="Invoicing",
                domain_id=finance_domain.id,
                description="Client invoices and billing"
            )
            session.add(invoice_subdomain)
            
            expense_subdomain = SubDomain(
                name="Expenses",
                domain_id=finance_domain.id,
                description="Employee expenses and reimbursements"
            )
            session.add(expense_subdomain)
            session.commit()
            print("✓ Created domains and sub-domains")
            
            # Generate Employee data
            print("\nGenerating employee data...")
            employees = self._generate_employees(100)
            session.bulk_save_objects(employees)
            session.commit()
            print(f"✓ Generated {len(employees)} employee records")
            
            # Generate Payroll data
            print("Generating payroll data...")
            payrolls = self._generate_payroll(50)
            session.bulk_save_objects(payrolls)
            session.commit()
            print(f"✓ Generated {len(payrolls)} payroll records")
            
            # Generate Invoice data
            print("Generating invoice data...")
            invoices = self._generate_invoices(80)
            session.bulk_save_objects(invoices)
            session.commit()
            print(f"✓ Generated {len(invoices)} invoice records")
            
            # Generate Expense data
            print("Generating expense data...")
            expenses = self._generate_expenses(60)
            session.bulk_save_objects(expenses)
            session.commit()
            print(f"✓ Generated {len(expenses)} expense records")
            
            print("\n✅ Sample data generation completed successfully!")
            
        except Exception as e:
            print(f"\n❌ Error generating sample data: {str(e)}")
            session.rollback()
        finally:
            session.close()
    
    def _generate_employees(self, count: int):
        """Generate employee records with intentional DQ issues"""
        departments = ['Engineering', 'Sales', 'Marketing', 'HR', 'Finance', 'Operations']
        designations = ['Manager', 'Senior Developer', 'Developer', 'Analyst', 'Executive', 'Lead']
        
        first_names = ['John', 'Jane', 'Michael', 'Sarah', 'David', 'Emily', 'Robert', 'Lisa', 
                       'William', 'Jennifer', 'Test', 'Dummy', '']  # Include problematic names
        last_names = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 
                     'Davis', 'Unknown', 'NA', '']  # Include problematic last names
        
        employees = []
        
        for i in range(count):
            # Intentionally introduce DQ issues
            introduce_null = random.random() < 0.15  # 15% null values
            introduce_default = random.random() < 0.1  # 10% default values
            introduce_duplicate = random.random() < 0.05 and i > 10  # 5% duplicates
            
            if introduce_duplicate:
                # Create duplicate
                first_name = employees[i-10].first_name
                last_name = employees[i-10].last_name
                email = employees[i-10].email
            else:
                first_name = random.choice(first_names) if not introduce_null else None
                last_name = random.choice(last_names) if not introduce_null else None
                
                if first_name and last_name:
                    email = f"{first_name.lower()}.{last_name.lower()}@company.com"
                elif introduce_default:
                    email = "test@test.com"
                else:
                    email = None
            
            # Phone number with issues
            if introduce_default:
                phone = "9999999999"
            elif introduce_null:
                phone = None
            else:
                phone = f"{random.randint(70,99)}{random.randint(10000000,99999999)}"
            
            emp = Employee(
                employee_id=f"EMP{str(i+1).zfill(4)}",
                first_name=first_name,
                last_name=last_name,
                email=email,
                phone=phone,
                department=random.choice(departments) if not introduce_null else None,
                designation=random.choice(designations),
                salary=random.uniform(30000, 150000) if not introduce_null else None,
                joining_date=datetime.now() - timedelta(days=random.randint(30, 1500))
            )
            employees.append(emp)
        
        return employees
    
    def _generate_payroll(self, count: int):
        """Generate payroll records with DQ issues"""
        months = ['January', 'February', 'March', 'April', 'May', 'June', 
                 'July', 'August', 'September', 'October', 'November', 'December']
        
        payrolls = []
        
        for i in range(count):
            introduce_issue = random.random() < 0.2  # 20% with issues
            
            basic_salary = random.uniform(25000, 120000) if not introduce_issue else None
            allowances = random.uniform(5000, 20000) if not introduce_issue else 0
            deductions = random.uniform(2000, 15000)
            
            if basic_salary:
                net_salary = basic_salary + allowances - deductions
            else:
                net_salary = 0
            
            payroll = Payroll(
                employee_id=f"EMP{str(random.randint(1,100)).zfill(4)}",
                month=random.choice(months),
                year=random.choice([2023, 2024]),
                basic_salary=basic_salary,
                allowances=allowances,
                deductions=deductions,
                net_salary=net_salary,
                payment_date=datetime.now() - timedelta(days=random.randint(1, 365))
            )
            payrolls.append(payroll)
        
        return payrolls
    
    def _generate_invoices(self, count: int):
        """Generate invoice records with DQ issues"""
        clients = ['ABC Corp', 'XYZ Ltd', 'Tech Solutions', 'Global Inc', 'Test Client', 
                  'Dummy Corp', '']
        statuses = ['paid', 'pending', 'overdue']
        
        invoices = []
        
        for i in range(count):
            introduce_issue = random.random() < 0.15  # 15% with issues
            
            invoice_date = datetime.now() - timedelta(days=random.randint(1, 180))
            due_date = invoice_date + timedelta(days=30)
            
            amount = random.uniform(5000, 100000) if not introduce_issue else 0
            tax = amount * 0.18 if amount > 0 else 0
            total_amount = amount + tax
            
            invoice = Invoice(
                invoice_number=f"INV{str(i+1).zfill(5)}",
                client_name=random.choice(clients),
                invoice_date=invoice_date if not introduce_issue else None,
                due_date=due_date,
                amount=amount,
                tax=tax,
                total_amount=total_amount,
                status=random.choice(statuses)
            )
            invoices.append(invoice)
        
        return invoices
    
    def _generate_expenses(self, count: int):
        """Generate expense records with DQ issues"""
        categories = ['Travel', 'Food', 'Office Supplies', 'Software', 'Training', 
                     'Entertainment', '', 'Unknown']
        statuses = ['approved', 'pending', 'rejected']
        
        expenses = []
        
        for i in range(count):
            introduce_issue = random.random() < 0.2  # 20% with issues
            
            amount = random.uniform(100, 10000) if not introduce_issue else -1  # Negative amount issue
            
            expense = Expense(
                expense_id=f"EXP{str(i+1).zfill(5)}",
                employee_id=f"EMP{str(random.randint(1,100)).zfill(4)}",
                category=random.choice(categories),
                description=f"Expense for {random.choice(categories)}" if not introduce_issue else None,
                amount=amount,
                expense_date=datetime.now() - timedelta(days=random.randint(1, 90)),
                status=random.choice(statuses)
            )
            expenses.append(expense)
        
        return expenses


def initialize_app_database():
    """Main function to initialize database"""
    initializer = DatabaseInitializer()
    
    print("=" * 60)
    print("DQ Dashboard - Database Initialization")
    print("=" * 60)
    
    initializer.initialize_database()
    initializer.generate_sample_data()
    
    print("\n" + "=" * 60)
    print("Database initialization completed!")
    print("=" * 60)


if __name__ == "__main__":
    initialize_app_database()
