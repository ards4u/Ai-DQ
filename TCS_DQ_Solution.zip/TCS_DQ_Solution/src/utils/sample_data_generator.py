"""
Sample Data Generator for Finance and HR Domains
"""
import random
import pandas as pd
from datetime import datetime, timedelta
from faker import Faker
from src.models.database import get_session, Domain, DataTable, DataField, DQRule
from sqlalchemy import text

fake = Faker()


class SampleDataGenerator:
    """Generate sample data for Finance and HR domains"""
    
    def __init__(self):
        self.session = get_session()
        
    def generate_all_data(self):
        """Generate all sample data"""
        print("🚀 Starting sample data generation...")
        
        # Create domains
        finance_domain = self._create_domain("Finance", "Financial data including invoices, transactions, customers")
        hr_domain = self._create_domain("HR", "Human Resources data including employees, attendance, payroll")
        
        # Generate Finance data
        print("\n💰 Generating Finance domain data...")
        self._generate_finance_data(finance_domain)
        
        # Generate HR data
        print("\n👥 Generating HR domain data...")
        self._generate_hr_data(hr_domain)
        
        # Generate DQ rules
        print("\n📋 Generating DQ rules...")
        self._generate_dq_rules()
        
        print("\n✅ Sample data generation completed!")
        
    def _create_domain(self, name, description):
        """Create domain if not exists"""
        domain = self.session.query(Domain).filter_by(name=name).first()
        if not domain:
            domain = Domain(name=name, description=description)
            self.session.add(domain)
            self.session.commit()
            print(f"✓ Created domain: {name}")
        return domain
    
    def _generate_finance_data(self, domain):
        """Generate Finance domain data"""
        # Create Customers table
        customers_df = self._generate_customers(300)
        self._save_to_database(customers_df, 'customers', domain)
        
        # Create Invoices table
        invoices_df = self._generate_invoices(500, customers_df)
        self._save_to_database(invoices_df, 'invoices', domain)
        
        # Create Transactions table
        transactions_df = self._generate_transactions(1000, invoices_df)
        self._save_to_database(transactions_df, 'transactions', domain)
        
    def _generate_hr_data(self, domain):
        """Generate HR domain data"""
        # Create Employees table
        employees_df = self._generate_employees(250)
        self._save_to_database(employees_df, 'employees', domain)
        
        # Create Attendance table
        attendance_df = self._generate_attendance(800, employees_df)
        self._save_to_database(attendance_df, 'attendance', domain)
        
        # Create Payroll table
        payroll_df = self._generate_payroll(250, employees_df)
        self._save_to_database(payroll_df, 'payroll', domain)
    
    def _generate_customers(self, count):
        """Generate customer data with intentional quality issues"""
        data = []
        for i in range(count):
            # Introduce quality issues
            email = fake.email() if random.random() > 0.05 else None  # 5% missing emails
            phone = fake.phone_number() if random.random() > 0.08 else None  # 8% missing phones
            
            # Add default/incorrect phone numbers
            if phone and random.random() < 0.03:
                phone = "9999999999"  # Default incorrect number
            
            data.append({
                'customer_id': f"CUST{i+1:05d}",
                'customer_name': fake.name() if random.random() > 0.02 else None,  # 2% missing names
                'email': email,
                'phone': phone,
                'address': fake.address() if random.random() > 0.1 else None,  # 10% missing
                'city': fake.city(),
                'country': fake.country(),
                'registration_date': fake.date_between(start_date='-2y', end_date='today'),
                'customer_type': random.choice(['Individual', 'Corporate', 'Government', None]),
                'credit_limit': round(random.uniform(10000, 500000), 2) if random.random() > 0.05 else None
            })
        
        # Introduce duplicates (5%)
        duplicates = random.sample(data, int(count * 0.05))
        data.extend(duplicates)
        
        return pd.DataFrame(data)
    
    def _generate_invoices(self, count, customers_df):
        """Generate invoice data"""
        data = []
        for i in range(count):
            invoice_date = fake.date_between(start_date='-1y', end_date='today')
            due_date = invoice_date + timedelta(days=random.randint(15, 60))
            
            # Introduce quality issues
            amount = round(random.uniform(100, 50000), 2) if random.random() > 0.03 else None  # 3% missing
            
            data.append({
                'invoice_id': f"INV{i+1:06d}",
                'customer_id': random.choice(customers_df['customer_id'].dropna().tolist()) if random.random() > 0.02 else None,
                'invoice_date': invoice_date,
                'due_date': due_date,
                'amount': amount,
                'tax_amount': round(amount * 0.18, 2) if amount else None,
                'total_amount': round(amount * 1.18, 2) if amount else None,
                'status': random.choice(['Paid', 'Pending', 'Overdue', 'Cancelled', None]),
                'payment_method': random.choice(['Credit Card', 'Bank Transfer', 'Cash', 'Cheque', None]),
                'currency': 'INR'
            })
        
        return pd.DataFrame(data)
    
    def _generate_transactions(self, count, invoices_df):
        """Generate transaction data"""
        data = []
        for i in range(count):
            transaction_date = fake.date_between(start_date='-1y', end_date='today')
            amount = round(random.uniform(50, 100000), 2) if random.random() > 0.04 else None
            
            data.append({
                'transaction_id': f"TXN{i+1:07d}",
                'invoice_id': random.choice(invoices_df['invoice_id'].dropna().tolist()) if random.random() > 0.05 else None,
                'transaction_date': transaction_date,
                'amount': amount,
                'transaction_type': random.choice(['Payment', 'Refund', 'Adjustment', None]),
                'payment_gateway': random.choice(['Razorpay', 'PayU', 'Paytm', 'Bank Transfer', None]),
                'reference_number': fake.uuid4() if random.random() > 0.06 else None,
                'status': random.choice(['Success', 'Failed', 'Pending', None])
            })
        
        return pd.DataFrame(data)
    
    def _generate_employees(self, count):
        """Generate employee data"""
        data = []
        for i in range(count):
            hire_date = fake.date_between(start_date='-10y', end_date='today')
            
            # Introduce quality issues
            email = f"{fake.user_name()}@tcs.com" if random.random() > 0.04 else None
            phone = fake.phone_number() if random.random() > 0.06 else None
            
            # Add default/incorrect values
            if phone and random.random() < 0.04:
                phone = "9999999999"
            
            data.append({
                'employee_id': f"EMP{i+1:05d}",
                'first_name': fake.first_name() if random.random() > 0.01 else None,
                'last_name': fake.last_name() if random.random() > 0.01 else None,
                'email': email,
                'phone': phone,
                'date_of_birth': fake.date_of_birth(minimum_age=22, maximum_age=60),
                'hire_date': hire_date,
                'department': random.choice(['Engineering', 'Sales', 'Marketing', 'HR', 'Finance', 'Operations', None]),
                'designation': random.choice(['Manager', 'Senior Engineer', 'Engineer', 'Analyst', 'Lead', None]),
                'salary': round(random.uniform(300000, 2500000), 2) if random.random() > 0.05 else None,
                'status': random.choice(['Active', 'Inactive', 'On Leave', None])
            })
        
        # Add duplicates
        duplicates = random.sample(data, int(count * 0.03))
        data.extend(duplicates)
        
        return pd.DataFrame(data)
    
    def _generate_attendance(self, count, employees_df):
        """Generate attendance data"""
        data = []
        for i in range(count):
            date = fake.date_between(start_date='-3m', end_date='today')
            
            data.append({
                'attendance_id': f"ATT{i+1:06d}",
                'employee_id': random.choice(employees_df['employee_id'].dropna().tolist()) if random.random() > 0.03 else None,
                'date': date,
                'check_in': fake.time() if random.random() > 0.1 else None,
                'check_out': fake.time() if random.random() > 0.12 else None,
                'hours_worked': round(random.uniform(6, 10), 2) if random.random() > 0.08 else None,
                'status': random.choice(['Present', 'Absent', 'Half Day', 'Leave', None]),
                'location': random.choice(['Office', 'Remote', 'Client Site', None])
            })
        
        return pd.DataFrame(data)
    
    def _generate_payroll(self, count, employees_df):
        """Generate payroll data"""
        data = []
        for i in range(count):
            month = fake.date_between(start_date='-1y', end_date='today').replace(day=1)
            basic_salary = round(random.uniform(25000, 200000), 2)
            
            data.append({
                'payroll_id': f"PAY{i+1:05d}",
                'employee_id': random.choice(employees_df['employee_id'].dropna().tolist()) if random.random() > 0.02 else None,
                'month': month,
                'basic_salary': basic_salary if random.random() > 0.03 else None,
                'allowances': round(basic_salary * 0.3, 2) if random.random() > 0.05 else None,
                'deductions': round(basic_salary * 0.1, 2) if random.random() > 0.05 else None,
                'net_salary': round(basic_salary * 1.2, 2) if random.random() > 0.04 else None,
                'payment_date': month + timedelta(days=random.randint(1, 10)),
                'payment_status': random.choice(['Paid', 'Pending', 'Processing', None])
            })
        
        return pd.DataFrame(data)
    
    def _save_to_database(self, df, table_name, domain):
        """Save DataFrame to database"""
        # Create table metadata
        table = DataTable(
            name=table_name,
            domain_id=domain.id,
            description=f"{table_name.title()} data",
            record_count=len(df)
        )
        self.session.add(table)
        self.session.commit()
        
        # Create field metadata
        for col in df.columns:
            field = DataField(
                name=col,
                table_id=table.id,
                data_type=str(df[col].dtype),
                is_nullable=df[col].isnull().any()
            )
            self.session.add(field)
        
        self.session.commit()
        
        # Save actual data
        from sqlalchemy import create_engine
        from config.settings import DATABASE_URL
        engine = create_engine(DATABASE_URL)
        df.to_sql(table_name, engine, if_exists='replace', index=False)
        
        print(f"  ✓ Generated {len(df)} records for {table_name}")
    
    def _generate_dq_rules(self):
        """Generate sample DQ rules"""
        rules = [
            # Completeness rules
            {
                'rule_name': 'Customer Email Completeness',
                'field_name': 'email',
                'table_name': 'customers',
                'domain_name': 'Finance',
                'rule_type': 'completeness',
                'rule_logic': 'COUNT(CASE WHEN email IS NOT NULL THEN 1 END) / COUNT(*) * 100',
                'threshold': 95.0
            },
            {
                'rule_name': 'Employee Phone Completeness',
                'field_name': 'phone',
                'table_name': 'employees',
                'domain_name': 'HR',
                'rule_type': 'completeness',
                'rule_logic': 'COUNT(CASE WHEN phone IS NOT NULL THEN 1 END) / COUNT(*) * 100',
                'threshold': 92.0
            },
            # Correctness rules
            {
                'rule_name': 'Phone Number Correctness',
                'field_name': 'phone',
                'table_name': 'customers',
                'domain_name': 'Finance',
                'rule_type': 'correctness',
                'rule_logic': "COUNT(CASE WHEN phone NOT IN ('9999999999', '0000000000') THEN 1 END) / COUNT(phone) * 100",
                'threshold': 97.0
            },
            {
                'rule_name': 'Invoice Amount Validity',
                'field_name': 'amount',
                'table_name': 'invoices',
                'domain_name': 'Finance',
                'rule_type': 'correctness',
                'rule_logic': 'COUNT(CASE WHEN amount > 0 THEN 1 END) / COUNT(amount) * 100',
                'threshold': 99.0
            },
            # Uniqueness rules
            {
                'rule_name': 'Customer ID Uniqueness',
                'field_name': 'customer_id',
                'table_name': 'customers',
                'domain_name': 'Finance',
                'rule_type': 'uniqueness',
                'rule_logic': 'COUNT(DISTINCT customer_id) / COUNT(customer_id) * 100',
                'threshold': 100.0
            },
            {
                'rule_name': 'Employee Email Uniqueness',
                'field_name': 'email',
                'table_name': 'employees',
                'domain_name': 'HR',
                'rule_type': 'uniqueness',
                'rule_logic': 'COUNT(DISTINCT email) / COUNT(email) * 100',
                'threshold': 100.0
            }
        ]
        
        for rule_data in rules:
            rule = DQRule(**rule_data)
            self.session.add(rule)
        
        self.session.commit()
        print(f"  ✓ Generated {len(rules)} DQ rules")


def generate_sample_data():
    """Main function to generate sample data"""
    generator = SampleDataGenerator()
    generator.generate_all_data()


if __name__ == "__main__":
    # Install faker if not present
    import subprocess
    subprocess.run(['pip', 'install', 'faker', '--break-system-packages'], capture_output=True)
    
    generate_sample_data()
