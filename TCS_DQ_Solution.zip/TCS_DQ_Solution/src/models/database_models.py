"""
Database models for DQ Dashboard
"""
from sqlalchemy import Column, Integer, String, Float, DateTime, Text, ForeignKey, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()


class Domain(Base):
    """Domain level table (e.g., Finance, HR)"""
    __tablename__ = 'domains'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    sub_domains = relationship("SubDomain", back_populates="domain", cascade="all, delete-orphan")
    dq_scores = relationship("DQScore", back_populates="domain", cascade="all, delete-orphan")


class SubDomain(Base):
    """Sub-domain level table (e.g., Payroll, Expenses)"""
    __tablename__ = 'sub_domains'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    domain_id = Column(Integer, ForeignKey('domains.id'), nullable=False)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    domain = relationship("Domain", back_populates="sub_domains")
    tables = relationship("DataTable", back_populates="sub_domain", cascade="all, delete-orphan")


class DataTable(Base):
    """Table/File level"""
    __tablename__ = 'data_tables'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    sub_domain_id = Column(Integer, ForeignKey('sub_domains.id'), nullable=False)
    description = Column(Text)
    record_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    sub_domain = relationship("SubDomain", back_populates="tables")
    fields = relationship("DataField", back_populates="table", cascade="all, delete-orphan")


class DataField(Base):
    """Field level metadata"""
    __tablename__ = 'data_fields'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    table_id = Column(Integer, ForeignKey('data_tables.id'), nullable=False)
    data_type = Column(String(50))
    is_nullable = Column(Boolean, default=True)
    is_primary_key = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    table = relationship("DataTable", back_populates="fields")


class DQRule(Base):
    """Data Quality Rules"""
    __tablename__ = 'dq_rules'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)
    rule_type = Column(String(50))  # completeness, correctness, uniqueness, consistency
    weight = Column(Float, default=1.0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class DQScore(Base):
    """Data Quality Scores at various levels"""
    __tablename__ = 'dq_scores'
    
    id = Column(Integer, primary_key=True)
    level = Column(String(20))  # field, table, sub_domain, domain
    entity_id = Column(Integer)  # ID of the entity being scored
    entity_name = Column(String(200))
    
    completeness_score = Column(Float, default=0.0)
    correctness_score = Column(Float, default=0.0)
    uniqueness_score = Column(Float, default=0.0)
    consistency_score = Column(Float, default=0.0)
    overall_score = Column(Float, default=0.0)
    
    domain_id = Column(Integer, ForeignKey('domains.id'), nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    domain = relationship("Domain", back_populates="dq_scores")


class DQInsight(Base):
    """AI-generated insights and recommendations"""
    __tablename__ = 'dq_insights'
    
    id = Column(Integer, primary_key=True)
    entity_type = Column(String(50))  # field, table, domain
    entity_id = Column(Integer)
    entity_name = Column(String(200))
    
    issue_type = Column(String(100))
    severity = Column(String(20))  # high, medium, low
    insight = Column(Text)
    recommendation = Column(Text)
    
    is_reviewed = Column(Boolean, default=False)
    is_approved = Column(Boolean, default=False)
    reviewed_by = Column(String(100))
    reviewed_at = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)


# Finance Domain Tables
class Employee(Base):
    """HR - Employee data"""
    __tablename__ = 'employees'
    
    id = Column(Integer, primary_key=True)
    employee_id = Column(String(20), unique=True, nullable=False)
    first_name = Column(String(100))
    last_name = Column(String(100))
    email = Column(String(150))
    phone = Column(String(20))
    department = Column(String(100))
    designation = Column(String(100))
    salary = Column(Float)
    joining_date = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)


class Payroll(Base):
    """HR - Payroll data"""
    __tablename__ = 'payroll'
    
    id = Column(Integer, primary_key=True)
    employee_id = Column(String(20), nullable=False)
    month = Column(String(20))
    year = Column(Integer)
    basic_salary = Column(Float)
    allowances = Column(Float)
    deductions = Column(Float)
    net_salary = Column(Float)
    payment_date = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)


class Invoice(Base):
    """Finance - Invoice data"""
    __tablename__ = 'invoices'
    
    id = Column(Integer, primary_key=True)
    invoice_number = Column(String(50), unique=True, nullable=False)
    client_name = Column(String(200))
    invoice_date = Column(DateTime)
    due_date = Column(DateTime)
    amount = Column(Float)
    tax = Column(Float)
    total_amount = Column(Float)
    status = Column(String(50))  # paid, pending, overdue
    created_at = Column(DateTime, default=datetime.utcnow)


class Expense(Base):
    """Finance - Expense data"""
    __tablename__ = 'expenses'
    
    id = Column(Integer, primary_key=True)
    expense_id = Column(String(50), unique=True, nullable=False)
    employee_id = Column(String(20))
    category = Column(String(100))
    description = Column(Text)
    amount = Column(Float)
    expense_date = Column(DateTime)
    status = Column(String(50))  # approved, pending, rejected
    created_at = Column(DateTime, default=datetime.utcnow)
