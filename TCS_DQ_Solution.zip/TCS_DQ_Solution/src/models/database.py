"""
Database models for Data Quality Dashboard
"""
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, ForeignKey, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import datetime
from config.settings import DATABASE_URL

Base = declarative_base()


class Domain(Base):
    """Domain level table"""
    __tablename__ = 'domains'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    tables = relationship('DataTable', back_populates='domain', cascade='all, delete-orphan')
    scores = relationship('DomainScore', back_populates='domain', cascade='all, delete-orphan')


class DataTable(Base):
    """File/Table level"""
    __tablename__ = 'data_tables'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    domain_id = Column(Integer, ForeignKey('domains.id'), nullable=False)
    description = Column(Text)
    record_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    domain = relationship('Domain', back_populates='tables')
    fields = relationship('DataField', back_populates='table', cascade='all, delete-orphan')
    scores = relationship('TableScore', back_populates='table', cascade='all, delete-orphan')


class DataField(Base):
    """Field level"""
    __tablename__ = 'data_fields'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    table_id = Column(Integer, ForeignKey('data_tables.id'), nullable=False)
    data_type = Column(String(50))
    is_nullable = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    table = relationship('DataTable', back_populates='fields')
    scores = relationship('FieldScore', back_populates='field', cascade='all, delete-orphan')


class DQRule(Base):
    """Data Quality Rules"""
    __tablename__ = 'dq_rules'
    
    id = Column(Integer, primary_key=True)
    rule_name = Column(String(200), nullable=False)
    field_name = Column(String(100))
    table_name = Column(String(100))
    domain_name = Column(String(100))
    rule_type = Column(String(50), nullable=False)  # completeness, correctness, uniqueness, etc.
    rule_logic = Column(Text, nullable=False)
    threshold = Column(Float, default=0.0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(String(100), default='system')


class FieldScore(Base):
    """Field level DQ scores"""
    __tablename__ = 'field_scores'
    
    id = Column(Integer, primary_key=True)
    field_id = Column(Integer, ForeignKey('data_fields.id'), nullable=False)
    completeness_score = Column(Float, default=0.0)
    correctness_score = Column(Float, default=0.0)
    uniqueness_score = Column(Float, default=0.0)
    overall_score = Column(Float, default=0.0)
    total_records = Column(Integer, default=0)
    null_count = Column(Integer, default=0)
    duplicate_count = Column(Integer, default=0)
    invalid_count = Column(Integer, default=0)
    calculated_at = Column(DateTime, default=datetime.utcnow)
    
    field = relationship('DataField', back_populates='scores')


class TableScore(Base):
    """Table level DQ scores"""
    __tablename__ = 'table_scores'
    
    id = Column(Integer, primary_key=True)
    table_id = Column(Integer, ForeignKey('data_tables.id'), nullable=False)
    completeness_score = Column(Float, default=0.0)
    correctness_score = Column(Float, default=0.0)
    uniqueness_score = Column(Float, default=0.0)
    overall_score = Column(Float, default=0.0)
    calculated_at = Column(DateTime, default=datetime.utcnow)
    
    table = relationship('DataTable', back_populates='scores')


class DomainScore(Base):
    """Domain level DQ scores"""
    __tablename__ = 'domain_scores'
    
    id = Column(Integer, primary_key=True)
    domain_id = Column(Integer, ForeignKey('domains.id'), nullable=False)
    completeness_score = Column(Float, default=0.0)
    correctness_score = Column(Float, default=0.0)
    uniqueness_score = Column(Float, default=0.0)
    overall_score = Column(Float, default=0.0)
    calculated_at = Column(DateTime, default=datetime.utcnow)
    
    domain = relationship('Domain', back_populates='scores')


class AIInsight(Base):
    """AI-generated insights and recommendations"""
    __tablename__ = 'ai_insights'
    
    id = Column(Integer, primary_key=True)
    entity_type = Column(String(50), nullable=False)  # field, table, domain
    entity_id = Column(Integer, nullable=False)
    entity_name = Column(String(200))
    insight_type = Column(String(50))  # pattern, recommendation, anomaly
    insight_text = Column(Text, nullable=False)
    confidence_score = Column(Float, default=0.0)
    status = Column(String(50), default='pending')  # pending, approved, rejected
    reviewed_by = Column(String(100))
    reviewed_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)


# Database initialization
def init_database():
    """Initialize database and create all tables"""
    engine = create_engine(DATABASE_URL)
    Base.metadata.create_all(engine)
    return engine


def get_session():
    """Get database session"""
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    return Session()
