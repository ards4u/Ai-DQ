# Technical Documentation - Data Quality Dashboard

## Architecture Overview

### System Architecture
```
┌─────────────────────────────────────────────────────────┐
│                    Web Browser (UI)                     │
│              Modern, Responsive Dashboard               │
└────────────────────┬────────────────────────────────────┘
                     │ HTTP/REST
┌────────────────────▼────────────────────────────────────┐
│                  Flask Application                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │   Routes &   │  │   Business   │  │     Data     │ │
│  │  Controllers │─▶│    Logic     │─▶│   Access     │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└────────────────────┬────────────────────────────────────┘
                     │
         ┌───────────┼───────────┐
         │           │           │
         ▼           ▼           ▼
┌─────────────┐ ┌─────────┐ ┌──────────────┐
│   SQLite    │ │ Ollama  │ │ File System  │
│   Database  │ │   LLM   │ │   Storage    │
└─────────────┘ └─────────┘ └──────────────┘
```

### Component Breakdown

#### 1. Frontend Layer
- **HTML Templates**: Jinja2 templates with Bootstrap-inspired custom CSS
- **CSS Framework**: Custom gradient-based design system
- **JavaScript**: Vanilla JS with Plotly for visualizations
- **Responsive Design**: Mobile-first approach

#### 2. Backend Layer
- **Web Framework**: Flask 3.0
- **ORM**: SQLAlchemy 2.0
- **Database**: SQLite (easily replaceable)
- **LLM Integration**: Ollama API client

#### 3. Data Layer
- **Database Models**: Domain, Table, Field, Score entities
- **Score Calculation**: Pandas-based analysis
- **Sample Data**: Faker library for realistic data

#### 4. Security Layer
- **Prompt Guardrails**: Input validation and sanitization
- **Response Guardrails**: Output filtering and PII redaction
- **Rule Validation**: Safe execution of DQ rules

## Data Model

### Entity Relationship Diagram
```
┌─────────────┐       ┌─────────────┐       ┌─────────────┐
│   Domain    │──1:N─▶│  DataTable  │──1:N─▶│  DataField  │
│             │       │             │       │             │
│ - id        │       │ - id        │       │ - id        │
│ - name      │       │ - name      │       │ - name      │
│ - desc      │       │ - domain_id │       │ - table_id  │
└──────┬──────┘       └──────┬──────┘       └──────┬──────┘
       │                     │                     │
       │ 1:N                 │ 1:N                 │ 1:N
       ▼                     ▼                     ▼
┌─────────────┐       ┌─────────────┐       ┌─────────────┐
│DomainScore  │       │ TableScore  │       │ FieldScore  │
│             │       │             │       │             │
│ - domain_id │       │ - table_id  │       │ - field_id  │
│ - overall   │       │ - overall   │       │ - overall   │
│ - complete  │       │ - complete  │       │ - complete  │
│ - correct   │       │ - correct   │       │ - correct   │
│ - unique    │       │ - unique    │       │ - unique    │
└─────────────┘       └─────────────┘       └─────────────┘

┌─────────────┐       ┌─────────────┐
│   DQRule    │       │ AIInsight   │
│             │       │             │
│ - id        │       │ - id        │
│ - rule_name │       │ - entity    │
│ - field     │       │ - type      │
│ - type      │       │ - text      │
│ - logic     │       │ - status    │
└─────────────┘       └─────────────┘
```

## Score Calculation Algorithm

### Field-Level Scores

```python
# Completeness Score
completeness = (total_records - null_count) / total_records * 100

# Correctness Score
# Detects default values (9999999999), invalid formats
correctness = (total_records - invalid_count) / total_records * 100

# Uniqueness Score
uniqueness = unique_values / total_records * 100

# Overall Score
overall = (completeness + correctness + uniqueness) / 3
```

### Table-Level Scores
- Aggregate all field scores for the table
- Calculate weighted average
- Consider field importance (future enhancement)

### Domain-Level Scores
- Aggregate all table scores in the domain
- Calculate weighted average by record count
- Provide holistic domain view

## Security Implementation

### 1. Prompt Guardrails

**Input Validation**:
```python
- Max length: 2000 characters
- Blocked keywords: DROP, DELETE, TRUNCATE, ALTER, EXEC
- Injection patterns: "ignore previous", "system:", etc.
- Special character removal: <, >, {, }
```

**Validation Flow**:
```
User Input → Length Check → Keyword Check → 
Pattern Check → Sanitization → Clean Prompt
```

### 2. Response Guardrails

**Output Validation**:
```python
- Max length: 5000 characters
- PII detection: Credit cards, SSN
- SQL pattern detection
- Content filtering
```

**Validation Flow**:
```
LLM Response → Length Check → PII Detection → 
Content Filter → Redaction → Safe Output
```

### 3. Rule Guardrails

**Rule Validation**:
```python
- Required fields check
- Dangerous operation prevention
- Type validation
- Execution sandboxing
```

## API Endpoints

### Frontend Routes
```
GET  /                  - Dashboard home
GET  /domains           - List all domains
GET  /domain/<id>       - Domain details
GET  /table/<id>        - Table details
GET  /field/<id>        - Field details
GET  /rules             - DQ rules list
GET  /admin             - Admin panel
```

### API Routes
```
POST /generate_sample_data  - Generate demo data
POST /recalculate_scores    - Recalculate all scores
POST /upload_file           - Upload CSV
POST /generate_insights     - Generate AI insights
POST /review_insight        - Approve/reject insight
```

## LLM Integration

### Prompt Engineering

**DQ Insight Prompt Structure**:
```
Context: Entity type, name, scores, metrics
Task: Analyze quality metrics
Output Format: Structured insights, recommendations, patterns
```

**Pattern Analysis Prompt**:
```
Input: Multiple field scores
Task: Identify common issues, correlations
Output: Comprehensive analysis
```

**Rule Suggestion Prompt**:
```
Input: Table structure, field types
Task: Suggest appropriate DQ rules
Output: Structured rule definitions
```

### Response Parsing
- Section-based parsing (INSIGHTS:, RECOMMENDATIONS:, PATTERNS:)
- Bullet point extraction
- Structured rule parsing

## Performance Considerations

### Optimization Strategies
1. **Database Indexing**: Primary keys, foreign keys
2. **Query Optimization**: Batch operations, join optimization
3. **Caching**: Session-based caching (future)
4. **Lazy Loading**: Load data on demand
5. **Pagination**: For large datasets (future)

### Scalability Path
```
Current: SQLite + Single Server
  ↓
Phase 1: PostgreSQL + Caching
  ↓
Phase 2: Load Balancer + Multiple Servers
  ↓
Phase 3: Microservices + Message Queue
```

## Testing Strategy

### Unit Tests (Future Implementation)
```python
- test_dq_calculator.py      # Score calculation
- test_guardrails.py          # Security features
- test_llm_service.py         # LLM integration
- test_sample_generator.py    # Data generation
```

### Integration Tests
```python
- test_api_endpoints.py       # API testing
- test_database_operations.py # DB operations
- test_file_upload.py         # File handling
```

### Manual Testing Checklist
- [ ] Sample data generation
- [ ] Score calculation accuracy
- [ ] CSV upload and analysis
- [ ] AI insight generation
- [ ] Insight review workflow
- [ ] Navigation flow
- [ ] Responsive design
- [ ] Error handling

## Deployment Guide

### Development Setup
```bash
1. Install dependencies
2. Configure settings
3. Initialize database
4. Generate sample data
5. Start Flask development server
```

### Production Deployment
```bash
1. Use production WSGI server (Gunicorn)
2. Configure PostgreSQL database
3. Set up Nginx reverse proxy
4. Enable HTTPS with SSL certificate
5. Configure environment variables
6. Set up monitoring (Prometheus, Grafana)
7. Implement backup strategy
```

## Configuration Management

### Environment Variables
```bash
DATABASE_URL=postgresql://user:pass@host/db
OLLAMA_BASE_URL=http://localhost:11434
SECRET_KEY=your-secret-key
DEBUG=False
MAX_FILE_SIZE=16777216
```

### Configuration Hierarchy
```
Default Config (settings.py)
  ↓
Environment Variables
  ↓
Command Line Arguments
```

## Monitoring & Logging

### Metrics to Track
- Request latency
- Error rates
- Database query performance
- LLM response times
- Score calculation duration
- File upload success rate

### Logging Levels
```
DEBUG: Detailed diagnostic info
INFO: General informational messages
WARNING: Warning messages
ERROR: Error messages
CRITICAL: Critical errors
```

## Future Enhancements

### Phase 1 (Production Ready)
- User authentication & authorization
- Role-based access control
- Production database (PostgreSQL)
- Comprehensive logging
- API rate limiting
- Data encryption

### Phase 2 (Advanced Features)
- Real-time monitoring
- Scheduled quality checks
- Email/Slack notifications
- Custom rule creation UI
- Data lineage tracking
- Historical trend analysis

### Phase 3 (Enterprise Features)
- Multi-tenancy support
- Advanced analytics & ML
- Integration with data catalogs
- Automated remediation
- Compliance reporting
- API for third-party integration

## Troubleshooting Guide

### Common Issues

**Database locked error**:
- Solution: Close other connections, use WAL mode

**Ollama connection error**:
- Solution: Ensure Ollama is running, check URL

**File upload fails**:
- Solution: Check file size, format, permissions

**Scores not calculating**:
- Solution: Verify data exists, check logs

**AI insights not generating**:
- Solution: Check Ollama status, review guardrails

## Code Standards

### Python Style Guide
- PEP 8 compliance
- Type hints for functions
- Docstrings for all classes/functions
- Maximum line length: 100 characters

### Naming Conventions
```
Classes: PascalCase
Functions: snake_case
Constants: UPPER_SNAKE_CASE
Private methods: _leading_underscore
```

### Git Workflow
```
main branch: Production-ready code
develop branch: Integration branch
feature/* branches: New features
bugfix/* branches: Bug fixes
```

## Support & Maintenance

### Documentation Updates
- Keep README.md current
- Update API documentation
- Document configuration changes
- Maintain changelog

### Version Control
- Semantic versioning (MAJOR.MINOR.PATCH)
- Tag releases
- Maintain release notes

---

**Last Updated**: 2024
**Version**: 1.0.0
**Maintained by**: TCS Hackathon Team
