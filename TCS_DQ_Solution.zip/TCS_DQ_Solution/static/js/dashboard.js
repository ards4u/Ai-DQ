// Data Quality Dashboard - Interactive JavaScript

// Utility functions
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} fade-in`;
    alertDiv.innerHTML = `
        <span>
            ${type === 'success' ? '✓' : type === 'danger' ? '✗' : 'ℹ'}
        </span>
        <span>${message}</span>
    `;
    
    const container = document.querySelector('.container');
    container.insertBefore(alertDiv, container.firstChild);
    
    setTimeout(() => {
        alertDiv.style.opacity = '0';
        setTimeout(() => alertDiv.remove(), 300);
    }, 5000);
}

function showSpinner(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '<div class="spinner"></div><p>Loading...</p>';
    }
}

function hideSpinner(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '';
    }
}

// Score color mapping
function getScoreColor(score) {
    if (score >= 95) return '#10b981';
    if (score >= 80) return '#3b82f6';
    if (score >= 60) return '#f59e0b';
    return '#ef4444';
}

function getScoreLabel(score) {
    if (score >= 95) return 'Excellent';
    if (score >= 80) return 'Good';
    if (score >= 60) return 'Fair';
    return 'Poor';
}

// File upload handling
function initFileUpload() {
    const uploadArea = document.querySelector('.upload-area');
    const fileInput = document.getElementById('fileInput');
    
    if (!uploadArea || !fileInput) return;
    
    uploadArea.addEventListener('click', () => fileInput.click());
    
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            fileInput.files = files;
            handleFileUpload(files[0]);
        }
    });
    
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileUpload(e.target.files[0]);
        }
    });
}

function handleFileUpload(file) {
    const formData = new FormData();
    formData.append('file', file);
    
    showSpinner('uploadResult');
    
    fetch('/upload_file', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        hideSpinner('uploadResult');
        if (data.success) {
            showAlert('File uploaded and analyzed successfully!', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showAlert(data.error || 'Upload failed', 'danger');
        }
    })
    .catch(error => {
        hideSpinner('uploadResult');
        showAlert('Error uploading file: ' + error.message, 'danger');
    });
}

// Generate insights for entity
function generateInsights(entityType, entityId, entityName) {
    showSpinner('insightResult');
    
    fetch('/generate_insights', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            entity_type: entityType,
            entity_id: entityId,
            entity_name: entityName
        })
    })
    .then(response => response.json())
    .then(data => {
        hideSpinner('insightResult');
        if (data.success) {
            displayInsights(data);
            showAlert('Insights generated successfully!', 'success');
        } else {
            showAlert(data.error || 'Failed to generate insights', 'danger');
        }
    })
    .catch(error => {
        hideSpinner('insightResult');
        showAlert('Error generating insights: ' + error.message, 'danger');
    });
}

function displayInsights(data) {
    const container = document.getElementById('insightResult');
    if (!container) return;
    
    let html = '<div class="fade-in">';
    
    if (data.insights && data.insights.length > 0) {
        html += '<h3 style="margin-bottom: 1rem;">💡 Key Insights</h3>';
        data.insights.forEach(insight => {
            html += `
                <div class="insight-card">
                    <div class="insight-header">
                        <span>🔍</span>
                        <span>Insight</span>
                    </div>
                    <div class="insight-text">${insight}</div>
                </div>
            `;
        });
    }
    
    if (data.recommendations && data.recommendations.length > 0) {
        html += '<h3 style="margin: 2rem 0 1rem;">📋 Recommendations</h3>';
        data.recommendations.forEach(rec => {
            html += `
                <div class="insight-card" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1)); border-left-color: #10b981;">
                    <div class="insight-header" style="color: #059669;">
                        <span>✓</span>
                        <span>Recommendation</span>
                    </div>
                    <div class="insight-text">${rec}</div>
                </div>
            `;
        });
    }
    
    if (data.patterns && data.patterns.length > 0) {
        html += '<h3 style="margin: 2rem 0 1rem;">📊 Patterns Detected</h3>';
        data.patterns.forEach(pattern => {
            html += `
                <div class="insight-card" style="background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(217, 119, 6, 0.1)); border-left-color: #f59e0b;">
                    <div class="insight-header" style="color: #d97706;">
                        <span>📈</span>
                        <span>Pattern</span>
                    </div>
                    <div class="insight-text">${pattern}</div>
                </div>
            `;
        });
    }
    
    html += '</div>';
    container.innerHTML = html;
}

// Recalculate scores
function recalculateScores() {
    if (!confirm('This will recalculate all data quality scores. Continue?')) {
        return;
    }
    
    showSpinner('calculationResult');
    
    fetch('/recalculate_scores', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        hideSpinner('calculationResult');
        if (data.success) {
            showAlert('Scores recalculated successfully!', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showAlert(data.error || 'Calculation failed', 'danger');
        }
    })
    .catch(error => {
        hideSpinner('calculationResult');
        showAlert('Error: ' + error.message, 'danger');
    });
}

// Review insight
function reviewInsight(insightId, action) {
    fetch('/review_insight', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            insight_id: insightId,
            action: action
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert(`Insight ${action}ed successfully!`, 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.error || 'Action failed', 'danger');
        }
    })
    .catch(error => {
        showAlert('Error: ' + error.message, 'danger');
    });
}

// Create chart
function createScoreChart(elementId, scores, labels) {
    const data = [{
        type: 'bar',
        x: labels,
        y: scores,
        marker: {
            color: scores.map(score => getScoreColor(score))
        }
    }];
    
    const layout = {
        title: 'Data Quality Scores',
        xaxis: { title: 'Metrics' },
        yaxis: { title: 'Score (%)', range: [0, 100] },
        margin: { t: 40, b: 80, l: 60, r: 20 }
    };
    
    Plotly.newPlot(elementId, data, layout, {responsive: true});
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initFileUpload();
    
    // Animate cards on scroll
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    });
    
    document.querySelectorAll('.card').forEach(card => {
        observer.observe(card);
    });
});

// Export functions for use in templates
window.DQDashboard = {
    showAlert,
    showSpinner,
    hideSpinner,
    generateInsights,
    recalculateScores,
    reviewInsight,
    createScoreChart,
    getScoreColor,
    getScoreLabel
};
