# AI-Powered Data Quality Dashboard

An intelligent data quality monitoring system built for TCS Hackathon featuring AI-powered insights using **TCS GenAI Lab's DeepSeek-V3** model with comprehensive guardrails.

## 🌟 Features

### Core Capabilities
- **Multi-Level DQ Analysis**: Field, Table, and Domain level quality scoring
- **Real-time Monitoring**: Live dashboard with interactive visualizations
- **AI-Powered Insights**: LLM-generated recommendations using TCS GenAI Lab
- **Guardrails**: Comprehensive input/output validation and security controls
- **CSV Upload**: Analyze external data files
- **SQLite Integration**: Finance and HR sample data

### Data Quality Metrics
1. **Completeness**: Null/missing value detection
2. **Correctness**: Default and invalid value identification
3. **Uniqueness**: Duplicate record analysis
4. **Consistency**: Format and pattern validation

### Security Features
- Prompt injection detection
- Input sanitization
- Output validation
- SQL injection prevention
- Response quality scoring

## 🚀 Setup Instructions

### Prerequisites
- Python 3.8+
- TCS GenAI Lab API key
- pip (Python package manager)

### Step 1: Get TCS GenAI Lab API Key

You need a valid API key from TCS GenAI Lab:
- Base URL: `https://genailab.tcs.in`
- Model: `azure.ai/genailab-maas-DeepSeek-V3-0324`
- Contact your TCS administrator for API key

### Step 2: Clone and Setup Project

```bash
# Navigate to project directory
cd dq-dashboard

# Run automated setup
# Linux/macOS:
chmod +x setup.sh
./setup.sh

# Windows:
setup.bat
```

The setup script will:
- Check Python version
- Create virtual environment
- Install dependencies
- Create necessary directories
- Initialize database
- Create .env file from template

### Step 3: Configure API Key

Edit the `.env` file and add your TCS GenAI Lab API key:

```bash
# Open .env file
nano .env  # or use your preferred editor

# Add your API key
TCS_GENAI_API_KEY=your_actual_api_key_here
```

### Step 4: Start the Application

```bash
# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Run the application
python app.py
```

The application will be available at: **http://localhost:5000**

## 📊 Usage Guide

### 1. Dashboard Overview
- View overall statistics for all data domains
- Monitor total records across HR and Finance
- Quick access to domain-specific analysis

### 2. Analyze Database Tables
- Click on table buttons (Employees, Payroll, Invoices, Expenses)
- View comprehensive DQ scores at field and table level
- Identify specific data quality issues

### 3. Analyze CSV Files
- Navigate to "Analysis" page
- Upload CSV file
- Enable "Generate AI Insights" for LLM recommendations
- View detailed analysis results

### 4. AI Insights
- Automatically generated after analysis using DeepSeek-V3
- View root cause analysis
- Review recommendations
- Approve/reject suggestions (Human-in-the-loop)

### 5. Admin Panel
- Initialize/reset database
- Check LLM connection status
- View guardrails configuration

## 🔒 Guardrails Implementation

### Input Guardrails
- **Length Validation**: Max 2000 characters for prompts
- **Pattern Blocking**: SQL injection, XSS, command injection
- **Context Validation**: Ensures relevance to DQ analysis
- **Prompt Injection Detection**: Identifies manipulation attempts

### Output Guardrails
- **Content Filtering**: Removes harmful patterns
- **Quality Validation**: Ensures meaningful insights
- **Length Control**: Max 5000 characters
- **Confidence Scoring**: Rates response quality

### Example Blocked Patterns
```python
- DROP TABLE
- DELETE FROM
- <script>
- eval()
- __import__
- ignore previous instructions
```

## 🎯 Key Endpoints

### API Endpoints
```
GET  /api/domains              # Get all domains
GET  /api/stats/overall        # Get overall statistics
POST /api/analyze/table/{name} # Analyze database table
POST /api/analyze/csv          # Analyze uploaded CSV
POST /api/analyze/field        # Get AI insights for field
GET  /api/llm/test             # Test LLM connection
POST /admin/init-db            # Initialize database
```

## 🧪 Testing

### Test Data Quality Issues
The sample data includes intentional issues:
- **Null Values**: ~15% of records
- **Default Values**: Phone numbers like 9999999999
- **Invalid Emails**: test@test.com
- **Duplicates**: ~5% duplicate records
- **Negative Values**: Invalid amounts in expenses
- **Missing Data**: Empty names and descriptions

### Test LLM Integration
1. Analyze any table with "Generate Insights" enabled
2. Check AI Insights page for recommendations
3. Verify guardrails by trying malicious prompts (they should be blocked)

## 🔄 Configuration

### Environment Variables (.env)

```bash
# TCS GenAI Lab API Configuration (Required)
TCS_GENAI_API_KEY=your_api_key_here

# Optional: Override defaults
TCS_GENAI_BASE_URL=https://genailab.tcs.in
TCS_GENAI_MODEL=azure.ai/genailab-maas-DeepSeek-V3-0324

# Application Settings
SECRET_KEY=your_secret_key_here
DEBUG_MODE=True
```

### Changing LLM Configuration

To use a different model or endpoint, update `config/settings.py` or set environment variables:

```python
# In .env file
TCS_GENAI_MODEL=your_different_model_name
TCS_GENAI_BASE_URL=https://your-endpoint.com
```

## 🎨 UI Features

- **Modern Design**: Gradient backgrounds, smooth animations
- **Responsive**: Works on desktop and mobile
- **Interactive Charts**: Real-time score visualization
- **Dark Header**: Professional appearance
- **Color-coded Scores**: Instant quality assessment

## 🛠️ Troubleshooting

### API Connection Issues
```bash
# Check if API key is set correctly
echo $TCS_GENAI_API_KEY

# Verify .env file
cat .env | grep TCS_GENAI_API_KEY
```

### Database Issues
```bash
# Reset database
rm database/dq_database.db
python src/utils/db_init.py
```

### Port Conflicts
Edit `app.py` to change port:
```python
app.run(debug=True, port=5001)
```

### Module Not Found
```bash
# Activate virtual environment and reinstall
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```

## 📝 Sample Data Schema

### Employees Table
- employee_id, first_name, last_name, email, phone
- department, designation, salary, joining_date

### Payroll Table
- employee_id, month, year, basic_salary
- allowances, deductions, net_salary, payment_date

### Invoices Table
- invoice_number, client_name, invoice_date, due_date
- amount, tax, total_amount, status

### Expenses Table
- expense_id, employee_id, category, description
- amount, expense_date, status

## 🏆 Hackathon Highlights

1. **TCS GenAI Lab Integration**: Uses internal TCS AI infrastructure
2. **Production-Ready**: Proper structure, error handling, logging
3. **Security First**: Comprehensive guardrails implementation
4. **User-Friendly**: Intuitive UI with human-in-the-loop
5. **Extensible**: Easy to add new domains, rules, and metrics
6. **Well-Documented**: Clear code comments and documentation

## 📈 Performance Tips

- Ensure stable network connection for API calls
- Keep API key secure (never commit to git)
- Use environment variables for configuration
- Monitor API rate limits

## 🎓 Learning Resources

- [TCS GenAI Lab Documentation](https://genailab.tcs.in/docs)
- [LangChain Documentation](https://python.langchain.com/)
- [Flask Documentation](https://flask.palletsprojects.com/)
- [SQLAlchemy Guide](https://docs.sqlalchemy.org/)

## 📄 Project Structure

```
dq-dashboard/
├── app.py                      # Main Flask application
├── requirements.txt            # Python dependencies
├── .env.example               # Environment variables template
├── .env                       # Your configuration (create from .env.example)
├── config/
│   └── settings.py            # Configuration settings
├── src/
│   ├── models/
│   │   └── database_models.py # SQLAlchemy models
│   ├── services/
│   │   ├── dq_analyzer.py    # Data quality analyzer
│   │   └── llm_service.py    # TCS GenAI Lab integration
│   ├── guardrails/
│   │   └── llm_guardrails.py # Security guardrails
│   └── utils/
│       └── db_init.py         # Database initialization
├── templates/
│   └── dashboard.html         # Main UI template
├── static/
│   ├── css/
│   │   └── style.css          # Styling
│   └── js/
│       └── main.js            # Frontend logic
├── database/                  # SQLite database location
└── uploads/                   # CSV upload directory
```

## 🔐 Security Best Practices

1. **Never commit API keys** to version control
2. **Use .env file** for sensitive configuration
3. **Rotate API keys** regularly
4. **Monitor API usage** to detect anomalies
5. **Keep dependencies updated** for security patches

## 📧 Support

For issues or questions:
1. Check troubleshooting section
2. Review TCS GenAI Lab documentation
3. Verify API key and network connectivity

## 📄 License

This project is created for TCS Hackathon purposes.

---

**Built with ❤️ for TCS Hackathon 2024**
**Powered by TCS GenAI Lab's DeepSeek-V3 Model**
