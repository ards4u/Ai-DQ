#!/usr/bin/env python3
"""
Setup and Demo Script for Data Quality Dashboard
Automates initial setup and generates demo data
"""
import sys
import subprocess
import os

def print_banner():
    """Print welcome banner"""
    banner = """
    ╔════════════════════════════════════════════════════════╗
    ║                                                        ║
    ║     🎯 AI-Powered Data Quality Dashboard              ║
    ║                                                        ║
    ║     Setup & Demo Script                               ║
    ║                                                        ║
    ╚════════════════════════════════════════════════════════╝
    """
    print(banner)

def check_python_version():
    """Check if Python version is compatible"""
    print("✓ Checking Python version...")
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        sys.exit(1)
    print(f"  Python {sys.version_info.major}.{sys.version_info.minor} detected")

def install_dependencies():
    """Install required Python packages"""
    print("\n📦 Installing dependencies...")
    try:
        subprocess.run([
            sys.executable, '-m', 'pip', 'install', 
            '-r', 'requirements.txt', 
            '--break-system-packages'
        ], check=True, capture_output=True)
        print("  ✓ Dependencies installed successfully")
    except subprocess.CalledProcessError as e:
        print(f"  ⚠ Warning: Some dependencies may not have installed properly")
        print(f"  Error: {e.stderr.decode()}")

def install_faker():
    """Install faker for sample data generation"""
    print("\n📊 Installing Faker for sample data generation...")
    try:
        subprocess.run([
            sys.executable, '-m', 'pip', 'install', 
            'faker', 
            '--break-system-packages'
        ], check=True, capture_output=True)
        print("  ✓ Faker installed successfully")
    except subprocess.CalledProcessError:
        print("  ⚠ Faker installation failed, but will continue")

def check_ollama():
    """Check if Ollama is installed and running"""
    print("\n🤖 Checking Ollama status...")
    try:
        import requests
        response = requests.get("http://localhost:11434/api/tags", timeout=2)
        if response.status_code == 200:
            print("  ✓ Ollama is running")
            return True
        else:
            print("  ⚠ Ollama is installed but not responding")
            return False
    except Exception:
        print("  ⚠ Ollama is not running or not installed")
        print("  📝 To enable AI features:")
        print("     1. Install Ollama: curl -fsSL https://ollama.com/install.sh | sh")
        print("     2. Pull model: ollama pull llama3")
        print("     3. Start server: ollama serve")
        return False

def initialize_database():
    """Initialize the database"""
    print("\n💾 Initializing database...")
    try:
        from src.models.database import init_database
        init_database()
        print("  ✓ Database initialized successfully")
    except Exception as e:
        print(f"  ❌ Database initialization failed: {str(e)}")
        sys.exit(1)

def generate_sample_data():
    """Generate sample data"""
    print("\n📊 Generating sample data...")
    print("  This may take a minute...")
    try:
        from src.utils.sample_data_generator import generate_sample_data
        generate_sample_data()
        print("  ✓ Sample data generated successfully")
    except Exception as e:
        print(f"  ❌ Sample data generation failed: {str(e)}")
        print(f"  You can generate data later from the Admin page")

def calculate_scores():
    """Calculate DQ scores"""
    print("\n📈 Calculating data quality scores...")
    try:
        from src.services.dq_calculator import calculate_dq_scores
        calculate_dq_scores()
        print("  ✓ Scores calculated successfully")
    except Exception as e:
        print(f"  ⚠ Score calculation failed: {str(e)}")
        print(f"  You can calculate scores later from the Admin page")

def print_summary(ollama_running):
    """Print setup summary"""
    summary = """
    ╔════════════════════════════════════════════════════════╗
    ║                  Setup Complete! 🎉                    ║
    ╚════════════════════════════════════════════════════════╝
    
    📌 Next Steps:
    
    1. Start the application:
       python app.py
    
    2. Open your browser:
       http://localhost:5000
    
    3. Explore the dashboard:
       - View domain-level quality scores
       - Drill down into tables and fields
       - Generate AI insights (if Ollama is running)
       - Upload your own CSV files
    
    📚 Documentation:
       See README.md for detailed information
    """
    
    if not ollama_running:
        summary += """
    ⚠️  AI Features Disabled:
       Ollama is not running. To enable AI insights:
       1. Install: curl -fsSL https://ollama.com/install.sh | sh
       2. Pull model: ollama pull llama3
       3. Start: ollama serve
    """
    
    print(summary)

def main():
    """Main setup function"""
    print_banner()
    
    # Check Python version
    check_python_version()
    
    # Install dependencies
    install_dependencies()
    install_faker()
    
    # Check Ollama
    ollama_running = check_ollama()
    
    # Initialize database
    initialize_database()
    
    # Ask user if they want to generate sample data
    print("\n" + "="*60)
    response = input("Generate sample data now? (Y/n): ").strip().lower()
    
    if response in ['', 'y', 'yes']:
        generate_sample_data()
        calculate_scores()
    else:
        print("  ℹ️  You can generate sample data later from the Admin page")
    
    # Print summary
    print_summary(ollama_running)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Setup interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Setup failed with error: {str(e)}")
        sys.exit(1)
