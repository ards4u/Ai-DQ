# Architecture Documentation - DQ Dashboard

## System Overview

The DQ Dashboard is built using a modular, layered architecture that separates concerns and promotes maintainability.

```
┌─────────────────────────────────────────────────────────┐
│                    User Interface                       │
│              (HTML/CSS/JavaScript)                      │
└───────────────────┬─────────────────────────────────────┘
                    │
┌───────────────────▼─────────────────────────────────────┐
│                  Flask API Layer                        │
│              (RESTful Endpoints)                        │
└───────────────────┬─────────────────────────────────────┘
                    │
┌───────────────────▼─────────────────────────────────────┐
│               Business Logic Layer                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │ DQ Analyzer  │  │ LLM Service  │  │ Guardrails   │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└───────────────────┬─────────────────────────────────────┘
                    │
┌───────────────────▼─────────────────────────────────────┐
│                  Data Layer                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │   SQLite     │  │   Ollama     │  │  File System │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────┘
```

## Component Details

### 1. Frontend Layer (UI)

**Technology**: HTML5, CSS3, JavaScript (Vanilla)

**Key Files**:
- `templates/dashboard.html` - Main UI structure
- `static/css/style.css` - Modern gradient styling
- `static/js/main.js` - Frontend logic and API calls

**Features**:
- Responsive design with gradient backgrounds
- Real-time data visualization
- Interactive charts and tables
- Toast notifications
- Loading overlays

**Pages**:
1. **Dashboard**: Overview with stats and quick actions
2. **Analysis**: Detailed DQ analysis and CSV upload
3. **AI Insights**: LLM recommendations with review
4. **Admin**: Database management and configuration

### 2. API Layer

**Technology**: Flask 3.0

**File**: `app.py`

**Endpoints**:
```python
GET  /                          # Main dashboard
GET  /api/domains              # List all domains
GET  /api/stats/overall        # Get statistics
POST /api/analyze/table/{name} # Analyze database table
POST /api/analyze/csv          # Analyze uploaded CSV
POST /api/analyze/field        # Get field insights
GET  /api/llm/test             # Test LLM connection
POST /api/insights/{id}/review # Review AI insight
POST /admin/init-db            # Initialize database
```

**Features**:
- RESTful API design
- JSON request/response format
- Error handling with appropriate status codes
- CORS enabled for development

### 3. Business Logic Layer

#### 3.1 Data Quality Analyzer

**File**: `src/services/dq_analyzer.py`

**Class**: `DataQualityAnalyzer`

**Responsibilities**:
- Calculate completeness scores (null detection)
- Assess correctness (default value detection)
- Measure uniqueness (duplicate analysis)
- Evaluate consistency (format validation)

**Key Methods**:
```python
analyze_dataframe(df, table_name)     # Analyze full dataset
analyze_field(df, column, total_rows) # Field-level analysis
_calculate_completeness(series)       # Completeness metric
_calculate_correctness(series)        # Correctness metric
_calculate_uniqueness(series)         # Uniqueness metric
_calculate_consistency(series)        # Consistency metric
```

**Default Value Patterns**:
```python
phone: ['9999999999', '0000000000']
email: ['test@test.com', 'example@example.com']
name: ['test', 'dummy', 'unknown']
```

#### 3.2 LLM Service

**File**: `src/services/llm_service.py`

**Class**: `LLMService`

**Responsibilities**:
- Interface with Ollama API
- Generate DQ insights using LLaMA3
- Apply guardrails to prompts and responses
- Calculate confidence scores

**Key Methods**:
```python
generate_dq_insights(context)        # Generate insights
analyze_field_quality(field_stats)   # Field analysis
analyze_table_quality(table_stats)   # Table analysis
analyze_domain_quality(domain_stats) # Domain analysis
_call_ollama(prompt)                 # API call
```

**Prompt Template**:
```
You are a Data Quality Analysis Expert...
Context: [level, entity, domain, metrics]
Data Quality Metrics: [scores]
Issues Detected: [list]
Please provide:
1. Root cause analysis
2. Recommendations
3. Priority levels
4. Impact assessment
```

#### 3.3 Guardrails System

**File**: `src/guardrails/llm_guardrails.py`

**Classes**:
- `LLMGuardrails` - Main validation
- `PromptInjectionDetector` - Security
- `OutputValidator` - Quality control

**Blocked Patterns**:
```python
SQL_INJECTION: ['DROP TABLE', 'DELETE FROM']
XSS: ['<script>', 'javascript:']
CODE_INJECTION: ['eval()', '__import__']
COMMAND_INJECTION: ['os.system', 'subprocess']
```

**Validation Pipeline**:
```
Input → Length Check → Pattern Check → Injection Detection 
  → Context Validation → Sanitization → Safe Prompt

Output → Length Check → Pattern Check → Quality Check 
  → Confidence Score → Sanitization → Safe Response
```

### 4. Data Layer

#### 4.1 Database Models

**File**: `src/models/database_models.py`

**ORM**: SQLAlchemy 2.0

**Core Models**:

1. **Domain** - Top-level categorization (HR, Finance)
2. **SubDomain** - Sub-categories (Payroll, Invoicing)
3. **DataTable** - Table/file metadata
4. **DataField** - Field-level metadata
5. **DQRule** - Quality rules definition
6. **DQScore** - Calculated quality scores
7. **DQInsight** - AI-generated insights

**Data Models**:

1. **Employee** - HR employee data
2. **Payroll** - Salary and payroll records
3. **Invoice** - Finance invoices
4. **Expense** - Expense tracking

**Relationships**:
```
Domain (1) → (N) SubDomain
SubDomain (1) → (N) DataTable
DataTable (1) → (N) DataField
Domain (1) → (N) DQScore
```

#### 4.2 Database Initialization

**File**: `src/utils/db_init.py`

**Class**: `DatabaseInitializer`

**Data Generation**:
- 100 employee records with 15% null values
- 50 payroll records with missing data
- 80 invoices with validation issues
- 60 expense records with negative amounts

**Intentional Issues**:
```python
introduce_null: 15% probability
introduce_default: 10% probability  
introduce_duplicate: 5% probability
introduce_invalid: 20% probability
```

### 5. Configuration

**File**: `config/settings.py`

**Key Settings**:
```python
DATABASE_URL: SQLite connection string
OLLAMA_MODEL: "llama3"
OLLAMA_BASE_URL: "http://localhost:11434"
DQ_THRESHOLDS: Quality grade boundaries
GUARDRAILS_CONFIG: Security parameters
DEFAULT_DQ_RULES: Pre-defined rules
```

## Data Flow

### Scenario 1: Analyze Database Table

```
1. User clicks "Employees" button
   ↓
2. Frontend → POST /api/analyze/table/employees
   ↓
3. Flask controller queries Employee table
   ↓
4. Convert to pandas DataFrame
   ↓
5. DQ Analyzer processes each field
   ↓
6. Calculate all metrics (completeness, correctness, etc.)
   ↓
7. Aggregate field scores to table level
   ↓
8. If AI insights requested:
   a. Create context from analysis results
   b. Guardrails validate context
   c. LLM Service generates insights
   d. Guardrails validate output
   e. Calculate confidence score
   ↓
9. Return JSON response with scores and insights
   ↓
10. Frontend displays results with visualizations
```

### Scenario 2: CSV Upload with AI Insights

```
1. User uploads CSV file
   ↓
2. Frontend → POST /api/analyze/csv (multipart/form-data)
   ↓
3. Flask saves file temporarily
   ↓
4. pandas reads CSV into DataFrame
   ↓
5. DQ Analyzer processes data
   ↓
6. Guardrails validates prompt template
   ↓
7. LLM generates recommendations
   ↓
8. Guardrails validates response
   ↓
9. Return comprehensive analysis
   ↓
10. Frontend displays on Analysis page
    ↓
11. User reviews AI insights
    ↓
12. User approves/rejects recommendations
    ↓
13. System records human feedback
```

## Security Architecture

### Defense Layers

1. **Input Layer**
   - File type validation
   - Size limits (16MB)
   - Extension whitelisting

2. **Prompt Layer**
   - Length validation (max 2000 chars)
   - Pattern blocking (SQL, XSS, etc.)
   - Injection detection
   - Context relevance check

3. **Processing Layer**
   - Sanitization of user input
   - Parameterized queries
   - Rate limiting ready

4. **Output Layer**
   - Response length control
   - Content filtering
   - Quality validation
   - Confidence scoring

### Threat Mitigation

| Threat | Mitigation |
|--------|-----------|
| SQL Injection | Parameterized queries, pattern blocking |
| XSS | Input sanitization, HTML escaping |
| Prompt Injection | Pattern detection, context validation |
| Code Injection | Pattern blocking, eval prevention |
| DoS | File size limits, timeout controls |

## Scalability Considerations

### Current Architecture (Demo)
- SQLite database
- Single Flask process
- Synchronous processing
- Local file storage

### Production Recommendations

1. **Database**:
   - PostgreSQL or MySQL
   - Connection pooling
   - Read replicas for analytics

2. **Application**:
   - Gunicorn/uWSGI
   - Multiple workers
   - Load balancer

3. **LLM**:
   - Dedicated GPU server
   - Response caching
   - Async processing with Celery

4. **Storage**:
   - S3 for file uploads
   - Redis for caching
   - ELK for logging

5. **Monitoring**:
   - Prometheus metrics
   - Grafana dashboards
   - Alert manager

## Extension Points

### Adding New Data Sources
1. Create model in `database_models.py`
2. Add initialization in `db_init.py`
3. Register endpoint in `app.py`
4. Add UI button in `dashboard.html`

### Custom DQ Rules
1. Add rule to database via admin
2. Implement logic in `dq_analyzer.py`
3. Update weight calculation
4. Test with sample data

### Different LLM Models
1. Update `OLLAMA_MODEL` in settings
2. Pull model: `ollama pull <model>`
3. Adjust temperature/parameters
4. Test guardrails compatibility

### Additional Metrics
1. Add calculation method in `dq_analyzer.py`
2. Update score aggregation
3. Add visualization in frontend
4. Document in README

## Testing Strategy

### Unit Tests (Future)
```python
tests/
├── test_dq_analyzer.py
├── test_llm_service.py
├── test_guardrails.py
└── test_api_endpoints.py
```

### Integration Tests
- Database operations
- API endpoints
- LLM integration
- File uploads

### Security Tests
- Injection attempts
- Malicious prompts
- File exploits
- Rate limiting

## Performance Metrics

### Target Benchmarks
- Table analysis: < 5 seconds
- AI insight generation: < 30 seconds
- CSV upload (10MB): < 10 seconds
- Page load: < 2 seconds

### Optimization Areas
- DataFrame operations (vectorization)
- Database queries (indexing)
- LLM calls (caching)
- Frontend rendering (lazy loading)

## Deployment Checklist

- [ ] Change SECRET_KEY
- [ ] Set DEBUG_MODE = False
- [ ] Configure production database
- [ ] Set up HTTPS
- [ ] Enable logging
- [ ] Configure CORS properly
- [ ] Set up monitoring
- [ ] Implement authentication
- [ ] Add rate limiting
- [ ] Document API
- [ ] Set up backups
- [ ] Load testing

---

**This architecture supports the TCS Hackathon requirements while being production-ready and extensible.**
