# Quick Start Guide - DQ Dashboard

## 5-Minute Setup

### Option 1: Automated Setup (Linux/macOS)

```bash
# Make setup script executable
chmod +x setup.sh

# Run setup
./setup.sh

# Start Ollama (in a separate terminal)
ollama serve

# Activate environment and run
source venv/bin/activate
python app.py
```

### Option 2: Automated Setup (Windows)

```cmd
# Run setup script
setup.bat

# Start Ollama (in a separate terminal)
ollama serve

# Activate environment and run
venv\Scripts\activate
python app.py
```

### Option 3: Manual Setup

```bash
# 1. Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# 2. Pull LLaMA3
ollama pull llama3

# 3. Create virtual environment
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows

# 4. Install dependencies
pip install -r requirements.txt

# 5. Initialize database
python src/utils/db_init.py

# 6. Run application
python app.py
```

## First Steps After Installation

1. **Open Dashboard**: Navigate to http://localhost:5000

2. **Verify LLM Connection**: Check the robot icon in the header
   - 🟢 Green = Connected
   - 🔴 Red = Disconnected

3. **Explore Sample Data**: Click on "Employees" or "Invoices" to analyze

4. **Try CSV Upload**: 
   - Go to "Analysis" page
   - Upload a CSV file
   - Enable "Generate AI Insights"
   - Click "Analyze"

5. **Review AI Insights**: Switch to "AI Insights" page to see recommendations

## Test Scenarios

### Scenario 1: Analyze Employee Data
```
1. Go to Dashboard
2. Click "Employees" button under HR domain
3. Wait for analysis to complete
4. Review field-level scores
5. Check detected issues
6. View AI recommendations
```

### Scenario 2: Upload Custom CSV
```
1. Prepare a CSV file with your data
2. Navigate to "Analysis" page
3. Click "Choose File" and select your CSV
4. Enable "Generate AI Insights"
5. Click "Analyze"
6. Review comprehensive results
```

### Scenario 3: Test Guardrails
```
1. Try to analyze a table with AI insights
2. System will validate prompts automatically
3. Blocked patterns will be prevented
4. Safe, validated insights will be displayed
```

### Scenario 4: Human-in-the-Loop Review
```
1. After AI generates insights
2. Navigate to "AI Insights" page
3. Review recommendations
4. Click "Approve" or "Reject"
5. System records your decision
```

## Common Commands

### Start Services
```bash
# Start Ollama (Terminal 1)
ollama serve

# Start Flask App (Terminal 2)
source venv/bin/activate
python app.py
```

### Reset Database
```bash
python src/utils/db_init.py
```

### Check Ollama Status
```bash
ollama list
```

### Test LLM
```bash
curl http://localhost:11434/api/tags
```

## Troubleshooting Quick Fixes

### Issue: "Cannot connect to Ollama"
**Fix**: Start Ollama service
```bash
ollama serve
```

### Issue: "Port 5000 already in use"
**Fix**: Change port in app.py
```python
app.run(debug=True, port=5001)
```

### Issue: "Module not found"
**Fix**: Activate virtual environment and reinstall
```bash
source venv/bin/activate
pip install -r requirements.txt
```

### Issue: "Database locked"
**Fix**: Close any other connections and restart
```bash
rm database/dq_database.db
python src/utils/db_init.py
```

## What to Expect

### Data Quality Scores
- **Excellent**: 95-100%
- **Good**: 80-94%
- **Fair**: 60-79%
- **Poor**: Below 60%

### Sample Data Issues
The generated data includes intentional problems:
- ✗ Null values in names and emails
- ✗ Default phone numbers (9999999999)
- ✗ Test emails (test@test.com)
- ✗ Duplicate records
- ✗ Negative amounts
- ✗ Missing descriptions

### AI Insights
LLM will analyze issues and provide:
- Root cause analysis
- Specific recommendations
- Priority levels
- Impact assessment

## Next Steps

1. **Customize**: Edit `config/settings.py` for your needs
2. **Add Data**: Connect to your real databases
3. **Extend**: Add custom DQ rules in database
4. **Scale**: Deploy with production-grade database
5. **Monitor**: Set up continuous DQ monitoring

## Demo Script

For presentations:

```python
# 1. Show Dashboard
"Navigate to http://localhost:5000"

# 2. Display Stats
"Show total records across domains"

# 3. Analyze Table
"Click 'Employees' - demonstrate field-level analysis"

# 4. Upload CSV
"Go to Analysis page - upload sample CSV"

# 5. AI Insights
"Show LLM-generated recommendations"

# 6. Human Review
"Demonstrate approve/reject workflow"

# 7. Admin Panel
"Show database initialization and LLM status"

# 8. Guardrails
"Explain security features and validation"
```

## Performance Tips

- Ensure 8GB+ RAM for smooth LLM operation
- Use SSD for better database performance
- Keep Ollama updated for best results
- Monitor system resources during analysis

## Resources

- **Ollama Docs**: https://github.com/ollama/ollama
- **Flask Guide**: https://flask.palletsprojects.com/
- **Project README**: See README.md for detailed documentation

---

**Ready to start? Run the setup script and begin exploring!** 🚀
