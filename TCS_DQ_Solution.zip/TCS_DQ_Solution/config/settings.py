"""
Configuration settings for DQ Dashboard
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Base directory
BASE_DIR = Path(__file__).resolve().parent.parent

# Database configuration
DATABASE_PATH = os.path.join(BASE_DIR, 'database', 'dq_database.db')
DATABASE_URL = f'sqlite:///{DATABASE_PATH}'

# TCS GenAI Lab LLM configuration
TCS_GENAI_BASE_URL = os.getenv("TCS_GENAI_BASE_URL", "https://genailab.tcs.in")
TCS_GENAI_MODEL = os.getenv("TCS_GENAI_MODEL", "azure.ai/genailab-maas-DeepSeek-V3-0324")
TCS_GENAI_API_KEY = os.getenv("TCS_GENAI_API_KEY", "XXXXXX")  # Replace XXXXXX with your actual API key or set in .env file

# Application settings
DEBUG_MODE = os.getenv("DEBUG_MODE", "True").lower() == "true"
SECRET_KEY = os.getenv("SECRET_KEY", "dq-dashboard-secret-key-change-in-production")
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
MAX_UPLOAD_SIZE = 16 * 1024 * 1024  # 16MB

# Data Quality thresholds
DQ_THRESHOLDS = {
    'excellent': 95,
    'good': 80,
    'fair': 60,
    'poor': 0
}

# Guardrails configuration
GUARDRAILS_CONFIG = {
    'max_prompt_length': 2000,
    'max_response_length': 5000,
    'temperature': 0.3,
    'top_p': 0.9
}

# Default DQ rules
DEFAULT_DQ_RULES = [
    {
        'name': 'completeness',
        'description': 'Check for null/empty values',
        'weight': 0.3
    },
    {
        'name': 'correctness',
        'description': 'Check for default/invalid values',
        'weight': 0.3
    },
    {
        'name': 'uniqueness',
        'description': 'Check for duplicate records',
        'weight': 0.2
    },
    {
        'name': 'consistency',
        'description': 'Check for data format consistency',
        'weight': 0.2
    }
]

# Logging configuration
LOG_LEVEL = 'INFO'
LOG_FILE = os.path.join(BASE_DIR, 'logs', 'app.log')
