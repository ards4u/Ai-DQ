# Quick Start Guide - Data Quality Dashboard

## Prerequisites
- Python 3.12 installed at: `C:\Program Files\Python312`
- Virtual environment at: `C:\Users\genAIINDSEZUSR47\.venv`

## Setup Steps

### 1. Activate Virtual Environment
```powershell
C:\Users\genAIINDSEZUSR47\.venv\Scripts\Activate.ps1
```

### 2. Install Dependencies
```powershell
pip install -r requirements.txt
```

Expected packages:
- flask
- pandas
- sqlalchemy
- langchain-openai
- httpx
- python-dotenv
- reportlab
- tabulate

### 3. Run the Application
```powershell
python app.py
```

The application will start on: **http://127.0.0.1:5000**

## First Time Usage

### Generate Sample Data
1. Open http://127.0.0.1:5000 in your browser
2. In the left sidebar under "Admin (Sample Data)":
   - Click **"Generate HR Sample"** button
   - Click **"Generate Finance Sample"** button
3. Wait for success messages

### Configure Domain/Subdomain
1. In the "Configuration" card:
   - Domain: Select **"Investment Banking"**
   - Subdomain: Select **"HR"** or **"Finance"**
   - Data Source: Select **"SQLite Demo DB"**
2. Click **"Apply"** button

## Feature Guide

### 1. Domain Summary Tab
- View overall DQ scores for the selected subdomain
- See colorful charts of table-level scores
- Adjust table weights (click inputs and click "Save Weights")
- Generate AI insights by clicking "💡 Generate AI Insights"

### 2. Tables & Fields Tab
- View all tables in the current subdomain
- See field-level DQ scores (completeness, correctness, uniqueness)
- View sample data previews
- Expand details sections to see data

### 3. Field Weights Tab ⭐ NEW FEATURE
- **Edit field weights** by typing in the Wc, Wr, Wu columns
- Click **"💾 Save Field Weights"** to apply changes
- Click **"🤖 Ask AI for suggestions"** to get AI recommendations
- Weights automatically normalize to sum to 1.0

### 4. Issues & Export Tab ⭐ ENHANCED
- **Filter by Table**: Select specific table or "All"
- **Filter by Issue Type**: Now includes ALL types:
  - Completeness
  - Correctness
  - Uniqueness
  - Duplicity
  - Key-ID Duplicity
- **Generate AI Summary**: Click to get:
  - Executive summary
  - Actionable recommendations
  - Example investigation queries
- **Export Options**:
  - **⬇️ Download CSV**: Get raw issues data
  - **📄 Export PDF Report**: Get comprehensive report with AI insights

### 5. DQ Rules Tab ⭐ ENHANCED
- **Draft Rules**: Edit JSON rules manually or with AI
- **AI Improvements**: Click "🤖 Ask AI to Improve Rules" 
  - AI considers current subdomain (HR or Finance)
  - Suggestions appear in right panel
- **Approve Rules**: Click "✅ Approve Draft as Active"
  - Rules immediately affect ALL calculations
  - Impact: completeness, correctness, uniqueness, issue detection
- **Active Rules**: View currently applied rules

## Common Workflows

### Workflow 1: Analyze HR Data Quality
```
1. Select "Investment Banking" > "HR" > "SQLite Demo DB"
2. Click "Apply"
3. Go to "Domain Summary" tab
4. Review DQ scores and charts
5. Go to "Issues & Export" tab
6. Click "Generate AI Summary"
7. Review recommendations
8. Click "📄 Export PDF Report"
```

### Workflow 2: Customize Field Weights
```
1. Navigate to "Field Weights" tab
2. Find field you want to adjust (e.g., "email")
3. Change weights (e.g., Wc=0.3, Wr=0.5, Wu=0.2)
4. Click "💾 Save Field Weights"
5. Go back to "Domain Summary" to see updated scores
```

### Workflow 3: Improve DQ Rules with AI
```
1. Go to "DQ Rules" tab
2. Make sure data is loaded (any subdomain)
3. Click "🤖 Ask AI to Improve Rules"
4. Review AI suggestions in right panel
5. If acceptable, click "✅ Approve Draft as Active"
6. Go to "Issues & Export" to see impact
```

### Workflow 4: Filter and Export Specific Issues
```
1. Go to "Issues & Export" tab
2. Select table from "Filter by Table" dropdown
3. Select issue type from "Filter by Issue Type" dropdown
4. Click "Apply Filters"
5. Review filtered issues
6. Click "⬇️ Download CSV" for filtered data
```

## Troubleshooting

### Issue: "No data loaded"
**Solution**: Click "Generate HR Sample" and "Generate Finance Sample" buttons

### Issue: "reportlab not installed" when exporting PDF
**Solution**: 
```powershell
pip install reportlab
```

### Issue: AI features not working
**Solution**: Check that `GENAILAB_API_KEY` is set in `config.py`

### Issue: Changes not reflected
**Solution**: 
1. Make sure you clicked the "Save" or "Apply" button
2. For DQ Rules, click "✅ Approve Draft as Active"
3. Refresh the page if needed

### Issue: Virtual environment not activating
**Solution**: 
```powershell
# Check Python path
"C:\Program Files\Python312\python.exe" --version

# Try activating again
C:\Users\genAIINDSEZUSR47\.venv\Scripts\Activate.ps1
```

## Demo Script for Hackathon

### Introduction (1 min)
"We've built an AI-powered Data Quality Dashboard for Investment Banking, covering HR and Finance subdomains with comprehensive DQ monitoring and AI-driven insights."

### Feature Demo (4 min)

**1. Domain Hierarchy** (30 sec)
- Show Investment Banking with HR/Finance subdomains
- Switch between subdomains to show different data

**2. Editable Field Weights** (45 sec)
- Navigate to Field Weights tab
- Edit some weights live
- Save and show impact on scores

**3. Complete Issue Detection** (45 sec)
- Go to Issues & Export tab
- Show all issue type filters
- Demonstrate filtering by different types

**4. AI Summary & PDF Export** (90 sec)
- Click "Generate AI Summary"
- Show executive summary, recommendations, and queries
- Click "Export PDF Report"
- Open PDF to show comprehensive report

**5. Smart DQ Rules** (60 sec)
- Go to DQ Rules tab
- Show context-aware AI (HR vs Finance)
- Request AI improvements
- Approve and show recalculation

## Quick Reference

### URLs
- Main Dashboard: http://127.0.0.1:5000
- Download Issues CSV: http://127.0.0.1:5000/download_issues
- Download PDF: http://127.0.0.1:5000/download_issues_pdf

### Key Files
- Main App: `app.py`
- Configuration: `config.py`
- DQ Rules Logic: `dq_rules.py`
- AI Integration: `llm_client.py`
- Database: `db_utils.py`
- UI Template: `templates/dashboard.html`

### Database Location
- SQLite DB: `dq_demo.db` (auto-created in project folder)

## Next Steps

After setup:
1. ✅ Generate sample data
2. ✅ Explore all 5 tabs
3. ✅ Try editing field weights
4. ✅ Generate AI summary
5. ✅ Export PDF report
6. ✅ Customize DQ rules
7. ✅ Test all filters

Good luck with your hackathon! 🚀
