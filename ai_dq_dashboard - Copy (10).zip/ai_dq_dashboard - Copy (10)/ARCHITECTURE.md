# Architecture Overview - DQ Dashboard

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INTERFACE (Browser)                  │
│  ┌──────────┬──────────┬──────────┬──────────┬──────────┐  │
│  │ Domain   │ Tables & │  Field   │ Issues & │    DQ    │  │
│  │ Summary  │  Fields  │ Weights  │  Export  │  Rules   │  │
│  └──────────┴──────────┴──────────┴──────────┴──────────┘  │
│             Bootstrap 5 + Chart.js + Custom CSS              │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    FLASK APPLICATION (app.py)                │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Routes & Controllers                                │   │
│  │  - / (dashboard)                                     │   │
│  │  - /download_issues (CSV export)                     │   │
│  │  - /download_issues_pdf (PDF export)                 │   │
│  └─────────────────────────────────────────────────────┘   │
│                            │                                 │
│  ┌────────────┬────────────┴───────────┬────────────┐      │
│  ▼            ▼                        ▼            ▼      │
│ ┌────────┐ ┌─────────┐ ┌──────────┐ ┌──────────┐         │
│ │ State  │ │  Form   │ │ Template │ │   AI     │         │
│ │ Mgmt   │ │ Handler │ │ Renderer │ │ Calls    │         │
│ └────────┘ └─────────┘ └──────────┘ └──────────┘         │
└─────────────────────────────────────────────────────────────┘
       │              │              │              │
       ▼              ▼              ▼              ▼
┌──────────┐  ┌───────────┐  ┌──────────┐  ┌──────────────┐
│ config.py│  │db_utils.py│  │dq_rules  │  │ llm_client   │
│          │  │           │  │   .py    │  │    .py       │
│ • Domain │  │ • init_db │  │ • Compute│  │ • AI Summary │
│   Map    │  │ • Generate│  │   Scores │  │ • Rule Sugg  │
│ • Rules  │  │   HR/Fin  │  │ • Detect │  │ • Weights    │
│ • Weights│  │ • Load    │  │   Issues │  │ • Insights   │
│ • API    │  │   Tables  │  │ • Profile│  │ • Guardrails │
│   Keys   │  │           │  │   Data   │  │              │
└──────────┘  └───────────┘  └──────────┘  └──────────────┘
       │              │                            │
       ▼              ▼                            ▼
┌──────────────────────────┐            ┌──────────────────┐
│     SQLite Database      │            │   GenAI Lab API  │
│      (dq_demo.db)        │            │  (LLM Service)   │
│                          │            │                  │
│ Tables:                  │            │ • DeepSeek V3    │
│ • hr_employees           │            │ • Chat Models    │
│ • hr_attendance          │            │ • JSON Response  │
│ • hr_payroll             │            │                  │
│ • hr_retention           │            └──────────────────┘
│ • fin_invoices           │
│ • fin_payments           │
│ • fin_investments        │
└──────────────────────────┘
```

## Data Flow - Computing DQ Scores

```
1. USER SELECTS DOMAIN/SUBDOMAIN
   │
   ├─→ Investment Banking > HR
   │
   └─→ Investment Banking > Finance

2. LOAD DATA FROM DATABASE
   │
   ├─→ db_utils.load_tables_from_sqlite(subdomain)
   │
   └─→ Returns: {table_name: DataFrame, ...}

3. COMPUTE DQ SCORES
   │
   ├─→ dq_rules.compute_field_scores(df, subdomain, rules)
   │   ├─→ For each field:
   │   │   ├─→ completeness_score()
   │   │   ├─→ correctness_score()
   │   │   └─→ uniqueness_score()
   │   └─→ Returns: field_scores_df
   │
   ├─→ dq_rules.aggregate_file_scores(field_scores, tables)
   │   ├─→ Average field scores per table
   │   ├─→ Add duplicity_score()
   │   └─→ Returns: file_scores_df
   │
   └─→ dq_rules.aggregate_domain_score(file_scores)
       └─→ Returns: domain_summary

4. DETECT ISSUES
   │
   └─→ dq_rules.detect_issues(df, subdomain, rules)
       ├─→ Completeness issues
       ├─→ Correctness issues
       ├─→ Uniqueness issues
       ├─→ Duplicity issues
       └─→ Returns: issues_df

5. RENDER DASHBOARD
   │
   └─→ Flask renders templates/dashboard.html
       └─→ Displays: scores, charts, tables, issues
```

## AI Integration Flow

```
USER REQUESTS AI FEATURE
   │
   ├─→ "Generate AI Summary"
   │   │
   │   └─→ llm_client.get_issues_summary_with_llm(issues_df)
   │       │
   │       ├─→ Build prompt with issue statistics
   │       ├─→ Call LLM with guardrails
   │       └─→ Returns: {summary, recommendations, queries}
   │
   ├─→ "Ask AI for Rules"
   │   │
   │   └─→ llm_client.suggest_dq_rules_with_llm(profile, context)
   │       │
   │       ├─→ Build prompt with current rules + data profile
   │       ├─→ Include subdomain context
   │       ├─→ Call LLM with guardrails
   │       └─→ Returns: {rules, explanation}
   │
   └─→ "Ask AI for Weights"
       │
       └─→ llm_client.get_field_weights_with_llm(profile)
           │
           ├─→ Build prompt with field characteristics
           ├─→ Call LLM with guardrails
           └─→ Returns: {field: {wc, wr, wu}}
```

## Issue Detection Flow

```
INPUT: DataFrame, subdomain, rules
   │
   ├─→ 1. COMPLETENESS CHECK
   │   │
   │   └─→ For each column:
   │       └─→ Find null values
   │           └─→ Create issue record
   │
   ├─→ 2. CORRECTNESS CHECK
   │   │
   │   ├─→ Phone/Contact fields:
   │   │   └─→ Check against placeholders
   │   │       └─→ Check length >= 10
   │   │
   │   ├─→ Salary fields:
   │   │   └─→ Check >= salary_min
   │   │       └─→ Check is numeric
   │   │
   │   ├─→ Amount fields:
   │   │   └─→ Check matches numeric pattern
   │   │
   │   └─→ Status fields:
   │       └─→ Check in allowed list
   │
   ├─→ 3. UNIQUENESS CHECK
   │   │
   │   └─→ For each column:
   │       └─→ Calculate unique %
   │           └─→ If < 50%, flag issue
   │
   ├─→ 4. DUPLICITY CHECK
   │   │
   │   ├─→ Full row duplicates
   │   └─→ Key ID duplicates
   │
   └─→ OUTPUT: issues_df
       │
       └─→ Columns: table, field, row_index, business_id,
                    issue_type, severity, description
```

## PDF Export Flow

```
USER CLICKS "Export PDF Report"
   │
   └─→ /download_issues_pdf route
       │
       ├─→ 1. CREATE PDF DOCUMENT
       │   │
       │   └─→ reportlab.SimpleDocTemplate(buffer)
       │
       ├─→ 2. BUILD CONTENT
       │   │
       │   ├─→ Title & Metadata
       │   │   └─→ Domain, Subdomain, Date, Count
       │   │
       │   ├─→ Issue Summary Table
       │   │   └─→ Group by: issue_type, severity
       │   │
       │   ├─→ AI Analysis (if available)
       │   │   ├─→ Executive Summary
       │   │   ├─→ Recommendations
       │   │   └─→ Example Queries
       │   │
       │   └─→ Detailed Issues Table
       │       └─→ Top 50 issues
       │
       ├─→ 3. APPLY STYLING
       │   │
       │   ├─→ TableStyle (colors, borders)
       │   ├─→ ParagraphStyle (fonts, spacing)
       │   └─→ PageBreaks
       │
       ├─→ 4. BUILD & SEND
       │   │
       │   ├─→ doc.build(elements)
       │   └─→ send_file(buffer, mimetype='application/pdf')
       │
       └─→ USER DOWNLOADS PDF
```

## Domain/Subdomain Hierarchy

```
Investment Banking (Domain)
   │
   ├─→ HR (Subdomain)
   │   │
   │   ├─→ Tables:
   │   │   ├─→ hr_employees
   │   │   ├─→ hr_attendance
   │   │   ├─→ hr_payroll
   │   │   └─→ hr_retention
   │   │
   │   ├─→ DQ Rules:
   │   │   ├─→ hr_status_allowed: ["Active", "Inactive"]
   │   │   ├─→ salary_min: 1
   │   │   └─→ phone_placeholders: [...]
   │   │
   │   └─→ DQ Scores:
   │       ├─→ Field Scores (per field)
   │       ├─→ Table Scores (per table)
   │       └─→ Subdomain Score (aggregated)
   │
   └─→ Finance (Subdomain)
       │
       ├─→ Tables:
       │   ├─→ fin_invoices
       │   ├─→ fin_payments
       │   └─→ fin_investments
       │
       ├─→ DQ Rules:
       │   ├─→ fin_status_allowed: ["PAID", "PENDING", "OVERDUE"]
       │   └─→ amount validation rules
       │
       └─→ DQ Scores:
           ├─→ Field Scores (per field)
           ├─→ Table Scores (per table)
           └─→ Subdomain Score (aggregated)
```

## State Management

```
IN-MEMORY STATE (app.py global variables)
   │
   ├─→ dq_rules_active        # Currently applied rules
   ├─→ dq_rules_draft         # Draft rules being edited
   ├─→ ai_rule_suggestions    # AI's rule suggestions
   ├─→ table_weights          # Weight per table
   ├─→ field_weights          # Weight per field
   ├─→ field_weight_sugg      # AI field weight suggestions
   ├─→ issues_ai_summary      # AI summary of issues
   ├─→ last_field_scores      # Latest field scores
   ├─→ last_file_scores       # Latest table scores
   ├─→ last_issues            # Latest detected issues
   ├─→ last_tables_data       # Latest loaded data
   ├─→ last_domain            # Current domain
   ├─→ last_subdomain         # Current subdomain
   └─→ last_source            # Data source (sqlite/csv)

NOTE: State resets on server restart
      For production, persist to database
```

## Technology Stack Layers

```
┌─────────────────────────────────────┐
│     PRESENTATION LAYER              │
│  • Bootstrap 5 (UI Framework)       │
│  • Chart.js (Visualizations)        │
│  • Jinja2 Templates (HTML)          │
│  • Custom CSS (Styling)             │
└─────────────────────────────────────┘
              ▲│▼
┌─────────────────────────────────────┐
│     APPLICATION LAYER               │
│  • Flask (Web Framework)            │
│  • Python 3.12 (Runtime)            │
│  • Type Hints (Code Quality)        │
└─────────────────────────────────────┘
              ▲│▼
┌─────────────────────────────────────┐
│     BUSINESS LOGIC LAYER            │
│  • dq_rules.py (DQ Calculations)    │
│  • llm_client.py (AI Integration)   │
│  • Custom algorithms                │
└─────────────────────────────────────┘
              ▲│▼
┌─────────────────────────────────────┐
│     DATA ACCESS LAYER               │
│  • SQLAlchemy (ORM)                 │
│  • Pandas (Data Processing)         │
│  • db_utils.py (DB Operations)      │
└─────────────────────────────────────┘
              ▲│▼
┌─────────────────────────────────────┐
│     PERSISTENCE LAYER               │
│  • SQLite (Database)                │
│  • File System (PDFs, CSVs)         │
└─────────────────────────────────────┘
              ▲│▼
┌─────────────────────────────────────┐
│     EXTERNAL SERVICES               │
│  • GenAI Lab API (LLM)              │
│  • ReportLab (PDF Generation)       │
└─────────────────────────────────────┘
```

## Security & Guardrails

```
USER INPUT
   │
   ├─→ FLASK REQUEST VALIDATION
   │   ├─→ Method check (GET/POST)
   │   ├─→ Parameter validation
   │   └─→ File upload validation
   │
   ├─→ SQL INJECTION PROTECTION
   │   └─→ SQLAlchemy ORM (parameterized queries)
   │
   ├─→ LLM GUARDRAILS
   │   ├─→ guard_prompt() - Safe prompts
   │   ├─→ guard_result() - Safe responses
   │   ├─→ BLACKLIST_SQL - No destructive ops
   │   └─→ Error handling - Graceful failures
   │
   └─→ DATA VALIDATION
       ├─→ JSON parsing with try/except
       ├─→ Type checking
       └─→ Range validation
```

## Deployment Considerations

```
DEVELOPMENT (Current)
   ├─→ Flask debug mode
   ├─→ In-memory state
   ├─→ Single user
   └─→ Local SQLite

PRODUCTION (Recommended)
   ├─→ WSGI server (Gunicorn/uWSGI)
   ├─→ Database persistence (PostgreSQL)
   ├─→ Session management (Redis)
   ├─→ Multi-user support
   ├─→ Authentication (OAuth/SAML)
   ├─→ API rate limiting
   ├─→ Horizontal scaling
   ├─→ Load balancing
   └─→ Monitoring & logging
```

---

This architecture provides:
✅ Separation of concerns
✅ Modularity and maintainability
✅ Scalability path
✅ Security layers
✅ AI integration with guardrails
✅ Clear data flow
