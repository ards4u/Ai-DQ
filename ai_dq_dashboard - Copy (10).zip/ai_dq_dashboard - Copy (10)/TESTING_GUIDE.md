# Quick Start Guide - Testing Analytics Reports

## Prerequisites
```powershell
cd c:\Users\genAIINDSEZUSR23\Documents\ai_dq_dashboard\ai_dq_dashboard
pip install -r requirements.txt
```

## Start the Application
```powershell
python app.py
```

## Testing Steps

### 1. Generate Sample Data
1. Navigate to: http://127.0.0.1:5000
2. Click "Admin Panel" or go to: http://127.0.0.1:5000/admin
3. Click "Generate HR Sample Data"
4. Click "Generate Finance Sample Data"

### 2. Run Data Quality Check
1. Go to Dashboard: http://127.0.0.1:5000/dashboard
2. Select:
   - Domain: Investment Banking
   - Subdomain: HR
   - Source: SQLite Demo DB
3. Click "Apply"
4. Wait for analysis to complete

### 3. Test Analytics Reports
1. Navigate to Analytics: http://127.0.0.1:5000/analytics
2. Review the "How Quality Trend is Calculated" section
3. Test each report:
   - **Executive Summary PDF**: Click "Generate PDF" (red button)
   - **Detailed Analysis Excel**: Click "Generate Excel" (green button)
   - **AI Insights Report**: Click "Generate Report" (blue button)

### 4. Verify Disclaimers
Check that AI disclaimers appear on:
- [ ] Analytics page (top warning)
- [ ] Dashboard page (below title)
- [ ] Issues page (before export options)
- [ ] Executive PDF report (first page)
- [ ] Detailed Excel report (Disclaimer sheet)
- [ ] AI Insights PDF report (throughout)

### 5. Verify Report Contents

#### Executive Summary PDF Should Contain:
- AI disclaimer at top
- Domain/Subdomain/Date metadata
- Key metrics table
- Table quality scores
- Professional formatting with colors

#### Detailed Analysis Excel Should Contain:
- Sheet 1: Field Scores (all field-level data)
- Sheet 2: Table Scores (aggregated table data)
- Sheet 3: Issues (detected problems)
- Sheet 4: Disclaimer (warning and metadata)

#### AI Insights PDF Should Contain:
- AI content warning
- Domain-level insights
- Field-level analysis
- Issues summary with recommendations

## Expected Behavior

✅ **Success**: Reports download automatically
✅ **No Data**: "No data available. Please run a data quality check first."
✅ **Missing Library**: "reportlab/openpyxl library not installed. Install with: pip install..."

## Troubleshooting

### Issue: "reportlab library not installed"
```powershell
pip install reportlab
```

### Issue: "openpyxl library not installed"
```powershell
pip install openpyxl
```

### Issue: "No data available"
- Run a data quality check from Dashboard first
- Generate sample data in Admin panel

### Issue: Report buttons don't work
- Check browser console for errors
- Verify Flask server is running
- Check terminal for Python errors

## Color Schemes Verification

Each page should have distinct colors:
- **Home**: Purple gradient (#667eea → #764ba2)
- **Dashboard**: Purple gradient (matching branding)
- **Analytics**: Green gradient (#11998e → #38ef7d)
- **Issues**: Pink/Yellow gradient (#fa709a → #fee140)
- **Weights**: Pink gradient (#f093fb → #f5576c)
- **Admin**: Blue gradient (#4facfe → #00f2fe)

## Navigation Test

Test all navigation links work:
- Home → Dashboard → Analytics → Issues → Weights → Admin
- Breadcrumbs on each page
- Quick navigation cards on home page
