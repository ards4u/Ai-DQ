import random
from datetime import datetime, timedelta
from typing import List

import pandas as pd
from sqlalchemy import create_engine, text
from config import DB_PATH


def get_engine():
    return create_engine(f"sqlite:///{DB_PATH}")


def init_db():
    """Initialize DB connection (creates file if not exists)."""
    engine = get_engine()
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))


def generate_sample_hr_data(records: int = 100):
    """
    HR domain: multiple tables
    - hr_employees
    - hr_attendance
    - hr_payroll
    - hr_retention
    """
    depts = ["IT", "HR", "Finance", "Admin"]
    statuses = ["Active", "Inactive"]

    rows = []
    base_date = datetime(2015, 1, 1)
    for i in range(1, records + 1):
        phone = random.choice(
            ["9999999999", "1234567890", f"98{random.randint(10000000, 99999999)}"]
        )
        if random.random() < 0.1:
            phone = None  # missing

        salary = random.choice([0, 20000, 50000, 75000, 100000])
        if random.random() < 0.1:
            salary = None

        join_date = base_date + timedelta(days=random.randint(0, 365 * 10))
        dob = base_date - timedelta(days=365 * random.randint(20, 40))

        rows.append(
            {
                "emp_id": i,
                "first_name": f"Emp{i}",
                "last_name": "Test",
                "email": f"emp{i}@example.com" if random.random() > 0.05 else None,
                "phone": phone,
                "department": random.choice(depts),
                "salary": salary,
                "join_date": join_date.date().isoformat(),
                "dob": dob.date().isoformat(),
                "status": random.choice(statuses),
            }
        )

    df_emp = pd.DataFrame(rows)

    # Intentionally duplicate some rows
    df_emp_dup = df_emp.sample(frac=0.05, replace=False, random_state=42)
    df_emp = pd.concat([df_emp, df_emp_dup], ignore_index=True)

    engine = get_engine()
    df_emp.to_sql("hr_employees", engine, if_exists="replace", index=False)

    # Attendance table
    att_rows = []
    for emp_id in df_emp["emp_id"].dropna().unique()[:50]:
        for d in range(10):
            att_rows.append(
                {
                    "emp_id": emp_id,
                    "date": (datetime.today() - timedelta(days=d))
                    .date()
                    .isoformat(),
                    "status": random.choice(["P", "A", "L"]),  # Present/Absent/Leave
                }
            )
    df_att = pd.DataFrame(att_rows)
    df_att.to_sql("hr_attendance", engine, if_exists="replace", index=False)

    # Payroll table
    payroll_rows = []
    months = ["2025-01", "2025-02", "2025-03"]
    for emp_id in df_emp["emp_id"].dropna().unique():
        for m in months:
            gross = random.choice([30000, 50000, 70000, 90000])
            bonus = random.choice([0, 1000, 2000, 5000])
            payroll_rows.append(
                {
                    "payroll_id": f"{emp_id}_{m}",
                    "emp_id": emp_id,
                    "month": m,
                    "gross_salary": gross,
                    "bonus": bonus,
                }
            )
    df_payroll = pd.DataFrame(payroll_rows)
    df_payroll.to_sql("hr_payroll", engine, if_exists="replace", index=False)

    # Employee retention table
    ret_rows = []
    for emp_id in df_emp["emp_id"].dropna().unique():
        risk = random.choice([1, 2, 3, 4, 5])  # 5 = high attrition risk
        last_promo = base_date + timedelta(days=random.randint(0, 365 * 10))
        attrition_flag = random.choice([0, 1])
        ret_rows.append(
            {
                "retention_id": emp_id,
                "emp_id": emp_id,
                "risk_score": risk,
                "last_promotion_date": last_promo.date().isoformat(),
                "attrition_flag": attrition_flag,
            }
        )
    df_ret = pd.DataFrame(ret_rows)
    df_ret.to_sql("hr_retention", engine, if_exists="replace", index=False)


def generate_sample_finance_data(records: int = 120):
    """
    Finance domain: multiple tables
    - fin_invoices
    - fin_payments
    - fin_investments
    """
    statuses = ["PAID", "PENDING", "OVERDUE"]
    customers = ["ABC Corp", "XYZ Ltd", "Internal", "Test Customer"]

    inv_rows = []
    base_date = datetime(2020, 1, 1)
    for i in range(1, records + 1):
        amount = random.choice([0, 5000, 10000, 20000, 50000])
        if random.random() < 0.05:
            amount = None

        status = random.choice(statuses)
        inv_date = base_date + timedelta(days=random.randint(0, 365 * 5))
        due_date = inv_date + timedelta(days=random.choice([15, 30, 45]))

        inv_rows.append(
            {
                "invoice_id": i,
                "customer_name": random.choice(customers),
                "amount": amount,
                "invoice_date": inv_date.date().isoformat(),
                "due_date": due_date.date().isoformat(),
                "status": status,
                "contact_number": random.choice(["9999999999", "8888888888", None]),
            }
        )

    df_inv = pd.DataFrame(inv_rows)
    engine = get_engine()
    df_inv.to_sql("fin_invoices", engine, if_exists="replace", index=False)

    # Payments
    pay_rows = []
    for i in range(1, records // 2):
        pay_rows.append(
            {
                "payment_id": i,
                "invoice_id": random.randint(1, records),
                "amount_paid": random.choice([1000, 5000, 10000, 20000]),
                "payment_date": (
                    base_date + timedelta(days=random.randint(0, 365 * 5))
                )
                .date()
                .isoformat(),
                "mode": random.choice(["NEFT", "RTGS", "CASH"]),
            }
        )
    df_pay = pd.DataFrame(pay_rows)
    df_pay.to_sql("fin_payments", engine, if_exists="replace", index=False)

    # Investments
    portfolios = ["Debt", "Equity", "Hybrid", "Liquid"]
    ratings = ["AAA", "AA", "A", "BBB"]
    inv_rows2 = []
    for i in range(1, records // 2):
        amt = random.choice([100000, 250000, 500000, 750000])
        start = base_date + timedelta(days=random.randint(0, 365 * 3))
        maturity = start + timedelta(days=random.choice([365, 730, 1095]))
        inv_rows2.append(
            {
                "investment_id": i,
                "portfolio": random.choice(portfolios),
                "amount_invested": amt,
                "start_date": start.date().isoformat(),
                "maturity_date": maturity.date().isoformat(),
                "risk_rating": random.choice(ratings),
            }
        )
    df_inv2 = pd.DataFrame(inv_rows2)
    df_inv2.to_sql("fin_investments", engine, if_exists="replace", index=False)


def list_tables() -> List[str]:
    """List all tables in SQLite DB."""
    engine = get_engine()
    with engine.connect() as conn:
        result = conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table'")
        )
        return [row[0] for row in result]


def load_table(table_name: str) -> pd.DataFrame:
    """Load a table into DataFrame."""
    engine = get_engine()
    return pd.read_sql_table(table_name, engine)
