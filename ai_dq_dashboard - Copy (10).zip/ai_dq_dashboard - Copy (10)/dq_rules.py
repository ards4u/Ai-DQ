## AI Annotation
## Modified by Human

import re
from typing import Dict, Any, Optional, List

import pandas as pd

from config import DEFAULT_WEIGHTS
from llm_client import get_field_weights_with_llm

# ---------- Default, safe DQ rules ----------

DEFAULT_DQ_RULES: Dict[str, Any] = {
    # Phone validation
    "phone_placeholders": ["9999999999", "1234567890", "8888888888", "0000000000"],
    "phone_min_length": 10,
    "phone_max_length": 15,
    "phone_pattern": r"^\+?[0-9]{10,15}$",
    
    # Email validation
    "email_pattern": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
    "email_domain_blacklist": ["test.com", "example.com", "temp.com"],
    
    # ID validation
    "id_must_be_unique": True,
    "id_must_not_be_null": True,
    "id_pattern": r"^[A-Za-z0-9_-]+$",  # Alphanumeric with underscores/hyphens
    
    # Amount/Numeric validation
    "amount_min": 0,
    "amount_max": 999999999,
    "amount_pattern": r"^-?\d+(\.\d{1,2})?$",  # Up to 2 decimal places
    
    # Status validation
    "hr_status_allowed": ["Active", "Inactive", "On Leave", "Terminated"],
    "fin_status_allowed": ["PAID", "PENDING", "OVERDUE", "CANCELLED"],
    
    # Business rules
    "salary_min": 1000,
    "salary_max": 10000000,
    "age_min": 18,
    "age_max": 100,
    
    # Severity levels
    "duplicate_severity": "Medium",
    "completeness_severity": "High",
    "correctness_severity": "High",
    "uniqueness_severity": "Low",
    "id_duplicate_severity": "Critical",
}


def _merge_rules(rules: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Merge user/AI rules with defaults so required keys are always present."""
    merged = DEFAULT_DQ_RULES.copy()
    if rules:
        merged.update(rules)
    return merged


# ---------- KPI calculations ----------

def completeness_score(series: pd.Series) -> float:
    total = len(series)
    if total == 0:
        return 0.0
    nulls = series.isna().sum()
    return round(100 * (total - nulls) / total, 2)


def uniqueness_score(series: pd.Series) -> float:
    total = len(series)
    if total == 0:
        return 0.0
    dupes = series.duplicated().sum()
    return round(100 * (total - dupes) / total, 2)


def correctness_score(
    series: pd.Series,
    col_name: str,
    domain: str,
    rules: Optional[Dict[str, Any]] = None,
) -> float:
    """
    Correctness based on comprehensive rules:
    - ID: must be unique, not null, valid pattern
    - Phone/contact: placeholder numbers, length, pattern
    - Email: valid pattern, not in blacklist domains
    - Salary/Amount: within range, valid numeric format
    - Status: must be within allowed list
    - Age: within reasonable range
    """
    rules = _merge_rules(rules)
    total = len(series)
    if total == 0:
        return 0.0

    invalid = 0
    lower_name = col_name.lower()

    # ID correctness
    if "id" in lower_name or col_name.lower().endswith("_id"):
        pattern = re.compile(rules.get("id_pattern", r"^[A-Za-z0-9_-]+$"))
        for v in series:
            if pd.isna(v):
                if rules.get("id_must_not_be_null", True):
                    invalid += 1
                continue
            if not pattern.match(str(v)):
                invalid += 1

    # Phone correctness
    elif "phone" in lower_name or "contact" in lower_name or "mobile" in lower_name:
        placeholders = set(rules.get("phone_placeholders", []))
        min_len = rules.get("phone_min_length", 10)
        max_len = rules.get("phone_max_length", 15)
        phone_pattern = re.compile(rules.get("phone_pattern", r"^\+?[0-9]{10,15}$"))
        
        for v in series:
            if pd.isna(v):
                continue
            s = str(v).strip()
            if s in placeholders or len(s) < min_len or len(s) > max_len:
                invalid += 1
            elif not phone_pattern.match(s):
                invalid += 1

    # Email correctness
    elif "email" in lower_name or "mail" in lower_name:
        email_pattern = re.compile(rules.get("email_pattern", r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"))
        blacklist = set(rules.get("email_domain_blacklist", []))
        
        for v in series:
            if pd.isna(v):
                continue
            email_str = str(v).strip().lower()
            if not email_pattern.match(email_str):
                invalid += 1
            else:
                # Check domain blacklist
                domain_part = email_str.split("@")[-1] if "@" in email_str else ""
                if domain_part in blacklist:
                    invalid += 1

    # Salary correctness
    elif "salary" in lower_name or "wage" in lower_name or "compensation" in lower_name:
        salary_min = float(rules.get("salary_min", 1000))
        salary_max = float(rules.get("salary_max", 10000000))
        for v in series:
            if pd.isna(v):
                continue
            try:
                val = float(v)
                if val < salary_min or val > salary_max:
                    invalid += 1
            except Exception:
                invalid += 1

    # Amount correctness
    elif "amount" in lower_name or "price" in lower_name or "cost" in lower_name:
        amount_min = float(rules.get("amount_min", 0))
        amount_max = float(rules.get("amount_max", 999999999))
        amount_pattern = re.compile(rules.get("amount_pattern", r"^-?\d+(\.\d{1,2})?$"))
        
        for v in series:
            if pd.isna(v):
                continue
            s = str(v).strip()
            if not amount_pattern.match(s):
                invalid += 1
            else:
                try:
                    val = float(s)
                    if val < amount_min or val > amount_max:
                        invalid += 1
                except Exception:
                    invalid += 1

    # Age correctness
    elif "age" in lower_name:
        age_min = int(rules.get("age_min", 18))
        age_max = int(rules.get("age_max", 100))
        for v in series:
            if pd.isna(v):
                continue
            try:
                age = int(v)
                if age < age_min or age > age_max:
                    invalid += 1
            except Exception:
                invalid += 1

    # Status correctness
    elif "status" in lower_name:
        valid = (
            rules.get("hr_status_allowed")
            if domain == "HR"
            else rules.get("fin_status_allowed")
        )
        valid_set = set(valid or [])
        for v in series:
            if pd.isna(v):
                continue
            if v not in valid_set:
                invalid += 1

    if invalid == 0:
        return 100.0

    return round(100 * (total - invalid) / total, 2)


def build_profile_summary(df: pd.DataFrame) -> str:
    """Short textual profile of each field to feed LLM."""
    lines = []
    for col in df.columns:
        s = df[col]
        line = (
            f"{col}: non_null={s.notna().sum()}, "
            f"nulls={s.isna().sum()}, "
            f"distinct={s.nunique(dropna=True)}"
        )
        lines.append(line)
    return "\n".join(lines)


def compute_field_scores(
    df: pd.DataFrame,
    domain: str,
    table_name: str,
    rules: Optional[Dict[str, Any]] = None,
):
    """
    Compute field-level scores and get weights from LLM (with fallback + heuristics).
    """
    rules = _merge_rules(rules)
    profile = build_profile_summary(df)

    try:
        weights_by_field = get_field_weights_with_llm(profile, domain=domain)
    except Exception:
        # Fallback: same default weights for all fields
        weights_by_field = {col: DEFAULT_WEIGHTS.copy() for col in df.columns}

    records = []
    for col in df.columns:
        s = df[col]
        comp = completeness_score(s)
        uniq = uniqueness_score(s)
        corr = correctness_score(s, col_name=col, domain=domain, rules=rules)

        w = weights_by_field.get(col, DEFAULT_WEIGHTS)
        lname = col.lower()

        # Extra heuristic layer (ID & Email emphasis)
        if "id" in lname:
            w = {"completeness": 0.45, "correctness": 0.10, "uniqueness": 0.45}
        elif "email" in lname:
            w = {"completeness": 0.40, "correctness": 0.45, "uniqueness": 0.15}

        field_score = round(
            comp * w["completeness"]
            + corr * w["correctness"]
            + uniq * w["uniqueness"],
            2,
        )

        records.append(
            {
                "table": table_name,
                "field": col,
                "completeness": comp,
                "correctness": corr,
                "uniqueness": uniq,
                "weight_completeness": w["completeness"],
                "weight_correctness": w["correctness"],
                "weight_uniqueness": w["uniqueness"],
                "field_score": field_score,
            }
        )

    return pd.DataFrame(records), weights_by_field


# ---------- Table & Domain level DQ (including duplicity) ----------

def _get_id_column(df: pd.DataFrame) -> Optional[str]:
    for c in df.columns:
        cl = c.lower()
        if cl == "id" or cl.endswith("_id"):
            return c
    return None


def duplicity_score(df: pd.DataFrame, id_col: Optional[str]) -> float:
    """
    Score based on full-row duplicity and key-id duplicity.
    100 = no duplicates, lower = more duplicates.
    """
    total = len(df)
    if total == 0:
        return 100.0
    dup_all = df.duplicated().sum()
    dup_key = 0
    if id_col and id_col in df.columns:
        dup_key = df[id_col].duplicated().sum()
    dup_total = dup_all + dup_key
    dup_score = max(0, 100 * (1 - dup_total / total))
    return round(dup_score, 2)


def aggregate_file_scores(
    field_df: pd.DataFrame, tables_data: Dict[str, pd.DataFrame]
) -> pd.DataFrame:
    """
    Aggregate field scores to table level.
    Table/file DQ = 90% average field_score + 10% duplicity_score.
    """
    rows = []
    for table_name, group in field_df.groupby("table"):
        df = tables_data[table_name]
        id_col = _get_id_column(df)
        dup = duplicity_score(df, id_col)

        avg_field_score = group["field_score"].mean()
        file_score = round(avg_field_score * 0.9 + dup * 0.1, 2)

        rows.append(
            {
                "table": table_name,
                "file_score": file_score,
                "dup_score": dup,
                "fields": len(group),
                "avg_completeness": round(group["completeness"].mean(), 2),
                "avg_correctness": round(group["correctness"].mean(), 2),
                "avg_uniqueness": round(group["uniqueness"].mean(), 2),
            }
        )

    return pd.DataFrame(rows)


def aggregate_domain_score(file_df: pd.DataFrame, domain: str) -> Dict[str, Any]:
    """
    Aggregate domain score with dimension breakdowns.
    Returns domain score plus average completeness, correctness, uniqueness, and duplicity.
    """
    if file_df.empty:
        return {
            "domain": domain,
            "domain_score": 0,
            "files": 0,
            "completeness": 0,
            "correctness": 0,
            "uniqueness": 0,
            "duplicity": 0
        }
    
    domain_score = round(file_df["file_score"].mean(), 2)
    
    # Calculate average dimensions across all tables
    completeness = round(file_df["avg_completeness"].mean(), 2) if "avg_completeness" in file_df.columns else 0
    correctness = round(file_df["avg_correctness"].mean(), 2) if "avg_correctness" in file_df.columns else 0
    uniqueness = round(file_df["avg_uniqueness"].mean(), 2) if "avg_uniqueness" in file_df.columns else 0
    duplicity = round(100 - file_df["dup_score"].mean(), 2) if "dup_score" in file_df.columns else 0
    
    return {
        "domain": domain,
        "domain_score": domain_score,
        "files": len(file_df),
        "completeness": completeness,
        "correctness": correctness,
        "uniqueness": uniqueness,
        "duplicity": duplicity
    }


# ---------- Row-level issue detection ----------

def detect_issues(
    df: pd.DataFrame,
    domain: str,
    table_name: str,
    rules: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:
    """
    Row-level issues for completeness, correctness, and duplicity.
    Enhanced to detect all types: Completeness, Correctness (ID, phone, email, salary, amount, status, age),
    Uniqueness, Duplicity, and Key-ID duplicity.
    """
    rules = _merge_rules(rules)
    issues: List[Dict[str, Any]] = []

    id_col = _get_id_column(df)
    completeness_sev = rules.get("completeness_severity", "High")
    correctness_sev = rules.get("correctness_severity", "High")
    duplicate_sev = rules.get("duplicate_severity", "Medium")
    id_duplicate_sev = rules.get("id_duplicate_severity", "Critical")

    # Completeness: null values
    for col in df.columns:
        null_idx = df[df[col].isna()].index
        for idx in null_idx:
            # Critical severity for ID nulls
            severity = id_duplicate_sev if (col == id_col and rules.get("id_must_not_be_null", True)) else completeness_sev
            issues.append(
                {
                    "table": table_name,
                    "field": col,
                    "row_index": int(idx),
                    "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                    "issue_type": "Completeness",
                    "severity": severity,
                    "description": f"Null / missing value in field '{col}'.",
                }
            )

    # Correctness - ID Fields
    for col in df.columns:
        lname = col.lower()
        s = df[col]
        if "id" in lname or col.lower().endswith("_id"):
            pattern = re.compile(rules.get("id_pattern", r"^[A-Za-z0-9_-]+$"))
            for idx, v in s.items():
                if pd.isna(v):
                    continue
                if not pattern.match(str(v)):
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": int(idx),
                            "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                            "issue_type": "Correctness",
                            "severity": correctness_sev,
                            "description": f"ID '{v}' does not match valid pattern.",
                        }
                    )

    # Correctness - Phone/Contact
    for col in df.columns:
        lname = col.lower()
        s = df[col]
        if "phone" in lname or "contact" in lname or "mobile" in lname:
            placeholders = set(rules.get("phone_placeholders", []))
            min_len = rules.get("phone_min_length", 10)
            max_len = rules.get("phone_max_length", 15)
            phone_pattern = re.compile(rules.get("phone_pattern", r"^\+?[0-9]{10,15}$"))
            
            for idx, v in s.items():
                if pd.isna(v):
                    continue
                sv = str(v).strip()
                if sv in placeholders:
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": int(idx),
                            "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                            "issue_type": "Correctness",
                            "severity": correctness_sev,
                            "description": f"Phone '{sv}' is a placeholder value.",
                        }
                    )
                elif len(sv) < min_len or len(sv) > max_len:
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": int(idx),
                            "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                            "issue_type": "Correctness",
                            "severity": correctness_sev,
                            "description": f"Phone '{sv}' length invalid (min: {min_len}, max: {max_len}).",
                        }
                    )
                elif not phone_pattern.match(sv):
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": int(idx),
                            "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                            "issue_type": "Correctness",
                            "severity": correctness_sev,
                            "description": f"Phone '{sv}' does not match valid pattern.",
                        }
                    )

    # Correctness - Email
    for col in df.columns:
        lname = col.lower()
        s = df[col]
        if "email" in lname or "mail" in lname:
            email_pattern = re.compile(rules.get("email_pattern", r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"))
            blacklist = set(rules.get("email_domain_blacklist", []))
            
            for idx, v in s.items():
                if pd.isna(v):
                    continue
                email_str = str(v).strip().lower()
                if not email_pattern.match(email_str):
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": int(idx),
                            "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                            "issue_type": "Correctness",
                            "severity": correctness_sev,
                            "description": f"Email '{v}' is not in valid format.",
                        }
                    )
                else:
                    domain_part = email_str.split("@")[-1] if "@" in email_str else ""
                    if domain_part in blacklist:
                        issues.append(
                            {
                                "table": table_name,
                                "field": col,
                                "row_index": int(idx),
                                "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                                "issue_type": "Correctness",
                                "severity": correctness_sev,
                                "description": f"Email domain '{domain_part}' is blacklisted.",
                            }
                        )

    # Correctness - Salary
    for col in df.columns:
        lname = col.lower()
        s = df[col]
        if "salary" in lname or "wage" in lname or "compensation" in lname:
            salary_min = float(rules.get("salary_min", 1000))
            salary_max = float(rules.get("salary_max", 10000000))
            for idx, v in s.items():
                if pd.isna(v):
                    continue
                try:
                    val = float(v)
                    if val < salary_min:
                        issues.append(
                            {
                                "table": table_name,
                                "field": col,
                                "row_index": int(idx),
                                "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                                "issue_type": "Correctness",
                                "severity": correctness_sev,
                                "description": f"Salary '{v}' below minimum threshold {salary_min}.",
                            }
                        )
                    elif val > salary_max:
                        issues.append(
                            {
                                "table": table_name,
                                "field": col,
                                "row_index": int(idx),
                                "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                                "issue_type": "Correctness",
                                "severity": correctness_sev,
                                "description": f"Salary '{v}' exceeds maximum threshold {salary_max}.",
                            }
                        )
                except Exception:
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": int(idx),
                            "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                            "issue_type": "Correctness",
                            "severity": correctness_sev,
                            "description": f"Salary '{v}' is not numeric.",
                        }
                    )

    # Correctness - Amount
    for col in df.columns:
        lname = col.lower()
        s = df[col]
        if "amount" in lname or "price" in lname or "cost" in lname:
            amount_min = float(rules.get("amount_min", 0))
            amount_max = float(rules.get("amount_max", 999999999))
            amount_pattern = re.compile(rules.get("amount_pattern", r"^-?\d+(\.\d{1,2})?$"))
            
            for idx, v in s.items():
                if pd.isna(v):
                    continue
                sv = str(v).strip()
                if not amount_pattern.match(sv):
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": int(idx),
                            "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                            "issue_type": "Correctness",
                            "severity": correctness_sev,
                            "description": f"Amount '{sv}' contains invalid characters or format.",
                        }
                    )
                else:
                    try:
                        val = float(sv)
                        if val < amount_min or val > amount_max:
                            issues.append(
                                {
                                    "table": table_name,
                                    "field": col,
                                    "row_index": int(idx),
                                    "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                                    "issue_type": "Correctness",
                                    "severity": correctness_sev,
                                    "description": f"Amount '{v}' outside valid range ({amount_min} - {amount_max}).",
                                }
                            )
                    except Exception:
                        pass

    # Correctness - Age
    for col in df.columns:
        lname = col.lower()
        s = df[col]
        if "age" in lname:
            age_min = int(rules.get("age_min", 18))
            age_max = int(rules.get("age_max", 100))
            for idx, v in s.items():
                if pd.isna(v):
                    continue
                try:
                    age = int(v)
                    if age < age_min or age > age_max:
                        issues.append(
                            {
                                "table": table_name,
                                "field": col,
                                "row_index": int(idx),
                                "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                                "issue_type": "Correctness",
                                "severity": correctness_sev,
                                "description": f"Age '{age}' outside valid range ({age_min} - {age_max}).",
                            }
                        )
                except Exception:
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": int(idx),
                            "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                            "issue_type": "Correctness",
                            "severity": correctness_sev,
                            "description": f"Age '{v}' is not a valid number.",
                        }
                    )

    # Correctness - Status
    for col in df.columns:
        lname = col.lower()
        s = df[col]
        if "status" in lname:
            valid = (
                rules.get("hr_status_allowed")
                if domain == "HR"
                else rules.get("fin_status_allowed")
            )
            valid_set = set(valid or [])
            for idx, v in s.items():
                if pd.isna(v):
                    continue
                if v not in valid_set:
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": int(idx),
                            "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                            "issue_type": "Correctness",
                            "severity": correctness_sev,
                            "description": f"Status '{v}' not in allowed list {list(valid_set)}.",
                        }
                    )

    # Uniqueness issues - detect low uniqueness fields
    for col in df.columns:
        s = df[col]
        if len(s) > 0:
            unique_pct = (s.nunique() / len(s)) * 100
            # Flag fields with less than 50% uniqueness (excluding IDs which should be handled separately)
            if unique_pct < 50 and "id" not in col.lower():
                duplicate_count = s.duplicated().sum()
                if duplicate_count > 0:
                    issues.append(
                        {
                            "table": table_name,
                            "field": col,
                            "row_index": -1,  # Aggregate issue
                            "business_id": None,
                            "issue_type": "Uniqueness",
                            "severity": rules.get("uniqueness_severity", "Low"),
                            "description": f"Field has low uniqueness: {unique_pct:.1f}% ({duplicate_count} duplicates).",
                        }
                    )

    # Full-row duplicates
    dup_idx = df[df.duplicated()].index
    for idx in dup_idx:
        issues.append(
            {
                "table": table_name,
                "field": "(all fields)",
                "row_index": int(idx),
                "business_id": df.loc[idx, id_col] if id_col and idx in df.index else None,
                "issue_type": "Duplicity",
                "severity": duplicate_sev,
                "description": "Entire row duplicated in table.",
            }
        )

    # Key ID duplicates
    if id_col and id_col in df.columns:
        dup_key_idx = df[df[id_col].duplicated(keep=False)].index
        for idx in dup_key_idx:
            issues.append(
                {
                    "table": table_name,
                    "field": id_col,
                    "row_index": int(idx),
                    "business_id": df.loc[idx, id_col],
                    "issue_type": "Key-ID Duplicity",
                    "severity": id_duplicate_sev,
                    "description": f"Duplicate key ID value '{df.loc[idx, id_col]}'.",
                }
            )

    return pd.DataFrame(issues)
