## AI Annotation
## Modified by Human

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# SQLite DB
DB_PATH = BASE_DIR / "dq_demo.db"

# LLM config – DO NOT hardcode secrets, use env var
GENAILAB_BASE_URL = "https://genailab.tcs.in"  # your endpoint
GENAILAB_MODEL = "azure_ai/genailab-maas-DeepSeek-V3-0324"
# GENAILAB_API_KEY = "sk-oSjfXrMd6fAVjFUG7c89TQ"  # export this in your env
GENAILAB_API_KEY = "sk-tPuWwnub-xfzBHyoMlrfJg"

# Default weights (if LLM fails)
DEFAULT_WEIGHTS = {
    "completeness": 0.4,
    "correctness": 0.4,
    "uniqueness": 0.2,
}

# Guardrails
BLACKLIST_SQL = ["drop table", "truncate", "delete from", "alter table"]
ALLOWED_DOMAINS = ["Investment Banking"]
ALLOWED_SUBDOMAINS = {
    "Investment Banking": ["HR", "Finance"]
}

# Domain/Subdomain mapping
DOMAIN_SUBDOMAIN_MAP = {
    "Investment Banking": ["HR", "Finance"]
}
