# Issues & Export Tab - Data Refresh Fix

## Problem
The "Issues & Export" tab was displaying cached data from global variables and not reflecting changes made to the database. When the SQLite database was updated (e.g., through the admin panel or direct modifications), the Issues tab would continue showing old data until the user manually reloaded by changing subdomain or clicking "Load Data".

## Root Cause
The dashboard was using global variables (`last_issues`, `last_field_scores`, `last_file_scores`, etc.) to cache data. These variables were only updated when:
1. User changed subdomain/domain
2. User clicked "Load Data" button
3. User uploaded CSV files

This meant that database changes were not automatically reflected in the UI.

## Solution Implemented
Modified the `dashboard()` route in `app.py` to:

1. **Always reload from SQLite**: When source is "sqlite", the data is now reloaded from the database on every page access, ensuring fresh data is always displayed.

2. **Always recompute DQ metrics**: Field scores, file scores, domain summary, and issues are recomputed on every dashboard access when using SQLite data source.

3. **Update global cache**: The global variables are updated with fresh data after each computation.

## Code Changes

### File: `app.py`

**Change 1**: Added clarifying comment for SQLite data loading
```python
# --- Load data based on current domain/source ---
# Always reload from SQLite to reflect DB changes
if source == "sqlite":
    try:
        tables_data = load_tables_from_sqlite(subdomain)
    except Exception as e:
        flash(f"Error loading SQLite DB: {e}", "danger")
        tables_data = {}
```

**Change 2**: Added comments for DQ computation
```python
# --- Compute DQ using ACTIVE rules ---
# Always recompute to ensure fresh data (especially for SQLite DB changes)
field_scores_all, file_scores_df, domain_summary, issues_all = compute_dq(
    subdomain, tables_data, dq_rules_active
)

# Update global cache with fresh data
last_field_scores = field_scores_all
last_file_scores = file_scores_df
last_issues = issues_all
last_tables_data = tables_data
last_domain = domain
last_subdomain = subdomain
last_source = source
last_domain_summary = domain_summary
```

## Impact
- **Positive**: Issues & Export tab now always shows current database state
- **Positive**: No manual refresh needed after DB changes
- **Positive**: Data quality metrics always reflect the latest data
- **Neutral**: Slight performance impact from reloading/recomputing on each page access (acceptable for demo/hackathon use case)
- **No Breaking Changes**: All other functionality remains unchanged

## Testing
To verify the fix:
1. Access the dashboard with SQLite source (default)
2. Go to Admin panel and regenerate sample data
3. Return to dashboard - Issues & Export tab should show updated data
4. No manual refresh or subdomain change required

## Notes
- This fix specifically addresses SQLite data source
- CSV upload functionality maintains its existing behavior (cached until new upload)
- Global variables are still used for session management, but now updated more frequently
- For production use, consider implementing proper session management or database-backed caching

---
**Date**: December 6, 2025
**Issue**: "Issues & Export" tab not reflecting DB changes
**Status**: ✅ FIXED
