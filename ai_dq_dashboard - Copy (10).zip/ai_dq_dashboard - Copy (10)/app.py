## AI Annotation
## Modified by Human

import io
import json
from typing import Dict, Any

import pandas as pd
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    send_file,
)

from config import DB_PATH, DOMAIN_SUBDOMAIN_MAP
from db_utils import (
    init_db,
    generate_sample_hr_data,
    generate_sample_finance_data,
    list_tables,
    load_table,
)
from dq_rules import (
    compute_field_scores,
    aggregate_file_scores,
    aggregate_domain_score,
    detect_issues,
    DEFAULT_DQ_RULES,
    build_profile_summary,
)
from llm_client import (
    get_dq_insights_with_llm,
    suggest_dq_rules_with_llm,
    get_table_weights_with_llm,
    get_field_weights_with_llm,
    get_issues_summary_with_llm,
    get_subdomain_weights_with_llm,
    generate_email_body,
)

app = Flask(__name__)
app.secret_key = "replace-with-secure-key"

# ---- In-memory state (ok for hackathon / dev) ----
dq_rules_active = DEFAULT_DQ_RULES.copy()
dq_rules_draft = dq_rules_active.copy()
ai_rule_suggestions_text = ""
table_weights: Dict[str, float] = {}
subdomain_weights: Dict[str, float] = {}  # Weights for subdomains
field_weights: Dict[str, Dict[str, float]] = {}  # Store field weights for editing
field_weight_suggestions_text = ""  # for Field Weights tab
issues_ai_summary: Dict[str, Any] | None = None  # AI summary for issues
ai_insights: str | None = None  # Auto-generated AI insights
field_level_summary: str | None = None  # AI field-level summary

last_field_scores: pd.DataFrame | None = None
last_file_scores: pd.DataFrame | None = None
last_issues: pd.DataFrame | None = None
last_tables_data: Dict[str, pd.DataFrame] | None = None
last_domain: str | None = None
last_subdomain: str | None = None
last_source: str | None = None
last_domain_summary: Dict[str, Any] | None = None


def load_tables_from_sqlite(subdomain: str) -> dict:
    """Load HR or Finance tables from SQLite into {table_name: DataFrame}."""
    init_db()
    all_tables = list_tables()
    if subdomain == "HR":
        domain_tables = [t for t in all_tables if t.startswith("hr_")]
    else:
        domain_tables = [t for t in all_tables if t.startswith("fin_")]

    tables_data = {}
    for t in domain_tables:
        tables_data[t] = load_table(t)
    return tables_data


def load_tables_from_csv(files) -> dict:
    """Load multiple uploaded CSVs into {table_name: DataFrame}."""
    tables_data = {}
    for i, file in enumerate(files, start=1):
        if not file.filename:
            continue
        name = file.filename.rsplit(".", 1)[0]
        table_name = f"csv_{i}_{name}"
        df = pd.read_csv(file)
        tables_data[table_name] = df
    return tables_data


def load_tables_from_csv_with_names(files, table_names) -> dict:
    """Load multiple uploaded CSVs with custom table names into {table_name: DataFrame}."""
    tables_data = {}
    for file, table_name in zip(files, table_names):
        if not file.filename or not table_name:
            continue
        # Clean table name
        clean_name = table_name.strip().replace(" ", "_")
        df = pd.read_csv(file)
        tables_data[clean_name] = df
    return tables_data


def compute_dq(subdomain: str, tables_data: dict, rules: dict):
    """Compute field, file, domain scores and issues."""
    field_scores_list = []
    issues_list = []

    for t_name, t_df in tables_data.items():
        fs_df, _ = compute_field_scores(t_df, domain=subdomain, table_name=t_name, rules=rules)
        field_scores_list.append(fs_df)

        issues_df = detect_issues(t_df, domain=subdomain, table_name=t_name, rules=rules)
        if not issues_df.empty:
            issues_list.append(issues_df)

    field_scores_all = pd.concat(field_scores_list, ignore_index=True)
    issues_all = pd.concat(issues_list, ignore_index=True) if issues_list else pd.DataFrame()

    file_scores_df = aggregate_file_scores(field_scores_all, tables_data)
    domain_summary = aggregate_domain_score(file_scores_df, domain=subdomain)

    return field_scores_all, file_scores_df, domain_summary, issues_all


@app.route("/")
def home():
    """Homepage with Domain and Sub-domain information."""
    return render_template(
        "home.html",
        domain_map=DOMAIN_SUBDOMAIN_MAP,
    )


@app.route("/admin", methods=["GET", "POST"])
def admin():
    """Admin page for sample data generation and AI guardrails configuration."""
    if request.method == "POST":
        action = request.form.get("action")
        
        if action == "generate_hr":
            generate_sample_hr_data()
            flash("HR sample data generated successfully in SQLite database.", "success")
        
        elif action == "generate_fin":
            generate_sample_finance_data()
            flash("Finance sample data generated successfully in SQLite database.", "success")
        
        return redirect(url_for("admin"))
    
    # Get guardrails configuration status
    from llm_client import guardrails_enabled
    
    return render_template(
        "admin.html",
        guardrails_enabled=guardrails_enabled,
    )


@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    global dq_rules_active, dq_rules_draft, ai_rule_suggestions_text
    global table_weights, field_weights, field_weight_suggestions_text
    global last_field_scores, last_file_scores, last_issues
    global last_tables_data, last_domain, last_subdomain, last_source
    global issues_ai_summary, ai_insights, field_level_summary, last_domain_summary

    # --- Defaults from query params ---
    domain = request.args.get("domain", "Investment Banking")
    subdomain = request.args.get("subdomain", "HR")
    source = request.args.get("source", "sqlite")    # Filters for issues (query params)
    filter_table = request.args.get("ft", "ALL")
    filter_issue = request.args.get("fi", "ALL")
    
    tables_data: Dict[str, pd.DataFrame] = {}
    uploaded_files = None
    
    if request.method == "POST":
        action = request.form.get("action")

        # --- Upload CSV with table names ---
        if action == "upload_csv":
            domain = request.form.get("domain", domain)
            subdomain = request.form.get("subdomain", subdomain)
            source = "csv"
            
            csv_files = request.files.getlist("csv_files[]")
            table_names = request.form.getlist("table_names[]")
            
            if csv_files and table_names and len(csv_files) == len(table_names):
                try:
                    tables_data = load_tables_from_csv_with_names(csv_files, table_names)
                    if tables_data:
                        flash(f"Successfully uploaded {len(tables_data)} CSV files.", "success")
                        # Store for later use
                        last_tables_data = tables_data
                        last_source = "csv"
                    else:
                        flash("No valid CSV files uploaded.", "warning")
                except Exception as e:
                    flash(f"Error uploading CSV files: {e}", "danger")
            else:
                flash("Please provide matching CSV files and table names.", "warning")
          # --- Change main config (domain/subdomain/source / csv upload) ---
        elif action == "change_main":
            domain = request.form.get("domain", domain)
            subdomain = request.form.get("subdomain", subdomain)
            source = request.form.get("source", source)
            if source == "csv":
                uploaded_files = request.files.getlist("csv_files")
        
        # --- DQ Rules actions ---
        elif action == "save_rules":
            try:
                # Parse form data into rules dictionary
                new_rules = dq_rules_draft.copy()
                
                # Phone rules
                new_rules["phone_min_length"] = int(request.form.get("phone_min_length", 10))
                new_rules["phone_max_length"] = int(request.form.get("phone_max_length", 15))
                new_rules["phone_pattern"] = request.form.get("phone_pattern", r"^\+?[0-9]{10,15}$")
                phone_placeholders = request.form.get("phone_placeholders", "")
                new_rules["phone_placeholders"] = [p.strip() for p in phone_placeholders.split(",") if p.strip()]
                
                # Email rules
                new_rules["email_pattern"] = request.form.get("email_pattern", r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
                email_blacklist = request.form.get("email_domain_blacklist", "")
                new_rules["email_domain_blacklist"] = [d.strip() for d in email_blacklist.split(",") if d.strip()]
                
                # ID rules
                new_rules["id_must_be_unique"] = request.form.get("id_must_be_unique") == "true"
                new_rules["id_must_not_be_null"] = request.form.get("id_must_not_be_null") == "true"
                new_rules["id_pattern"] = request.form.get("id_pattern", r"^[A-Za-z0-9_-]+$")
                
                # Amount rules
                new_rules["amount_min"] = float(request.form.get("amount_min", 0))
                new_rules["amount_max"] = float(request.form.get("amount_max", 999999999))
                new_rules["amount_pattern"] = request.form.get("amount_pattern", r"^-?\d+(\.\d{1,2})?$")
                
                # Status rules
                hr_status = request.form.get("hr_status_allowed", "")
                new_rules["hr_status_allowed"] = [s.strip() for s in hr_status.split(",") if s.strip()]
                fin_status = request.form.get("fin_status_allowed", "")
                new_rules["fin_status_allowed"] = [s.strip() for s in fin_status.split(",") if s.strip()]
                  # Business rules
                new_rules["salary_min"] = float(request.form.get("salary_min", 1000))
                new_rules["salary_max"] = float(request.form.get("salary_max", 10000000))
                new_rules["age_min"] = int(request.form.get("age_min", 18))
                new_rules["age_max"] = int(request.form.get("age_max", 100))
                
                dq_rules_draft = new_rules
                flash("Draft DQ rules updated successfully.", "success")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
            except Exception as e:
                flash(f"Error updating rules: {e}", "danger")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))

        elif action == "ask_ai_rules":
            # Build combined profile from last_tables_data
            if last_tables_data:
                combined_profile = ""
                for t_name, t_df in last_tables_data.items():
                    combined_profile += f"\n[Table: {t_name}]\n"
                    combined_profile += build_profile_summary(t_df) + "\n"
                try:
                    suggested = suggest_dq_rules_with_llm(
                        combined_profile,
                        domain=f"{domain}/{subdomain}",                        current_rules=dq_rules_draft,
                    )
                    rules_part = suggested.get("rules", {})
                    explanation = suggested.get(
                        "explanation", "No explanation provided by AI."
                    )
                    dq_rules_draft = {**dq_rules_draft, **rules_part}
                    ai_rule_suggestions_text = explanation
                    flash("AI-suggested changes loaded into Draft rules. Review & approve.", "success")
                    return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
                except Exception as e:
                    flash(f"Error getting AI rules suggestion: {e}", "danger")
                    return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
            else:
                flash("No data loaded yet to profile for AI rules.", "warning")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))

        elif action == "approve_rules":
            dq_rules_active = dq_rules_draft.copy()
            flash("Draft rules approved and now ACTIVE for DQ checks. Recomputing...", "success")
            # Force recomputation with new rules by continuing to load data section
            uploaded_files = None
        
        # --- Table weights actions ---
        elif action == "save_table_weights":
            try:
                new_weights: Dict[str, float] = {}
                for key, val in request.form.items():
                    if key.startswith("tw_"):
                        table_name = key.replace("tw_", "", 1)
                        if val.strip() == "":
                            continue
                        new_weights[table_name] = float(val)
                total = sum(new_weights.values()) or 1.0
                for k in list(new_weights.keys()):
                    new_weights[k] = round(new_weights[k] / total, 3)
                table_weights = new_weights
                flash("Table weights updated.", "success")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
            except Exception as e:
                flash(f"Error updating table weights: {e}", "danger")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))

        elif action == "ask_ai_table_weights":
            if last_file_scores is not None and not last_file_scores.empty:
                try:
                    ai_weights = get_table_weights_with_llm(last_file_scores, domain, subdomain)
                    table_weights = ai_weights
                    flash("AI-based table weights applied.", "success")
                    return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
                except Exception as e:
                    flash(f"Error getting AI table weights: {e}", "danger")
                    return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
            else:
                flash("No file scores available yet to weight.", "warning")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))        # --- Field weights actions ---
        elif action == "save_field_weights":
            try:
                new_field_weights: Dict[str, Dict[str, float]] = {}
                for key, val in request.form.items():
                    if key.startswith("fw_"):
                        # Format: fw_tablename_fieldname_dimension
                        parts = key.replace("fw_", "", 1).rsplit("_", 1)
                        if len(parts) == 2:
                            field_key, dimension = parts
                            if val.strip() == "":
                                continue
                            if field_key not in new_field_weights:
                                new_field_weights[field_key] = {}
                            new_field_weights[field_key][dimension] = float(val)
                  # Normalize each field's weights to sum to 1
                for field_key in new_field_weights:
                    total = sum(new_field_weights[field_key].values()) or 1.0
                    for dim in new_field_weights[field_key]:
                        new_field_weights[field_key][dim] = round(new_field_weights[field_key][dim] / total, 3)
                field_weights = new_field_weights
                flash("Field weights updated.", "success")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
            except Exception as e:
                flash(f"Error updating field weights: {e}", "danger")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))

        elif action == "ask_ai_field_weights":
            if last_tables_data:
                combined_profile = ""
                for t_name, t_df in last_tables_data.items():
                    combined_profile += f"\n[Table: {t_name}]\n"
                    combined_profile += build_profile_summary(t_df) + "\n"
                try:
                    weights_suggestion = get_field_weights_with_llm(combined_profile, subdomain)
                    field_weight_suggestions_text = json.dumps(
                        weights_suggestion, indent=2                    )
                    flash("AI field-weight suggestions generated.", "success")
                    return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
                except Exception as e:
                    flash(f"Error getting AI field weight suggestions: {e}", "danger")
                    return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
            else:
                flash("No data loaded yet to profile for field weights.", "warning")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))

        # --- Generate AI Issues Summary ---
        elif action == "generate_issues_summary":
            if last_issues is not None and not last_issues.empty:
                try:
                    issues_ai_summary = get_issues_summary_with_llm(last_issues, domain, subdomain)
                    flash("AI issues summary generated.", "success")
                    return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
                except Exception as e:
                    flash(f"Error generating AI summary: {e}", "danger")
                    return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))
            else:
                flash("No issues to summarize.", "warning")
                return redirect(url_for("dashboard", domain=domain, subdomain=subdomain, source=source))    # --- Load data based on current domain/source ---
    # Always reload from SQLite to reflect DB changes
    if source == "sqlite":
        try:
            tables_data = load_tables_from_sqlite(subdomain)
        except Exception as e:
            flash(f"Error loading SQLite DB: {e}", "danger")
            tables_data = {}
    else:
        # CSV mode
        if uploaded_files:
            tables_data = load_tables_from_csv(uploaded_files)
        elif last_source == "csv" and last_tables_data:
            tables_data = last_tables_data

    # If no tables, render minimal dashboard
    if not tables_data:
        last_field_scores = None
        last_file_scores = None
        last_issues = None
        last_tables_data = None
        return render_template(
            "dashboard.html",
            domain=domain,
            subdomain=subdomain,
            subdomains=DOMAIN_SUBDOMAIN_MAP.get(domain, []),
            source=source,
            tables_data={},
            field_scores=None,
            file_scores=None,
            domain_summary=None,
            issues=None,
            issues_tables=[],
            issues_types=[],
            filter_table=filter_table,
            filter_issue=filter_issue,
            table_weights={},
            field_weights={},
            weighted_domain_score=0.0,
            dq_rules_active=dq_rules_active,
            dq_rules_draft=dq_rules_draft,
            ai_rule_suggestions_text=ai_rule_suggestions_text,
            field_weight_suggestions_text=field_weight_suggestions_text,
            issues_ai_summary=None,
            ai_insights=None,
            chart_labels=[],
            chart_scores=[],
        )
      # --- Compute DQ using ACTIVE rules ---
    # Always recompute to ensure fresh data (especially for SQLite DB changes)
    field_scores_all, file_scores_df, domain_summary, issues_all = compute_dq(
        subdomain, tables_data, dq_rules_active
    )
    
    # Update global cache with fresh data
    last_field_scores = field_scores_all
    last_file_scores = file_scores_df
    last_issues = issues_all
    last_tables_data = tables_data
    last_domain = domain
    last_subdomain = subdomain
    last_source = source
    last_domain_summary = domain_summary

    # --- Table-level weights for domain score ---
    if file_scores_df is not None and not file_scores_df.empty:
        if not table_weights:
            n = len(file_scores_df)
            table_weights = {
                row["table"]: round(1 / n, 3) for _, row in file_scores_df.iterrows()
            }
        weighted_domain_score = 0.0
        for t, w in table_weights.items():
            fs_val = file_scores_df.loc[file_scores_df["table"] == t, "file_score"]
            if not fs_val.empty:
                weighted_domain_score += fs_val.iloc[0] * w
        weighted_domain_score = round(weighted_domain_score, 2)
    else:
        weighted_domain_score = 0.0

    # --- Issues filters (table + issue type) ---
    if issues_all is not None and not issues_all.empty:
        issues_tables = sorted(issues_all["table"].unique().tolist())
        issues_types = sorted(issues_all["issue_type"].unique().tolist())
        issues_filtered = issues_all.copy()
        if filter_table and filter_table != "ALL":
            issues_filtered = issues_filtered[issues_filtered["table"] == filter_table]
        if filter_issue and filter_issue != "ALL":
            issues_filtered = issues_filtered[issues_filtered["issue_type"] == filter_issue]
    else:
        issues_tables = []
        issues_types = []
        issues_filtered = issues_all

    # --- Chart data (for colorful graph) ---
    if file_scores_df is not None and not file_scores_df.empty:
        chart_labels = file_scores_df["table"].tolist()
        chart_scores = file_scores_df["file_score"].tolist()
    else:
        chart_labels = []
        chart_scores = []    # --- Auto-generate AI summaries ---
    
    # Initialize variables with defaults
    ai_insights = None
    field_level_summary = None
    subdomain_weights = {}
    
    # Generate AI Insights for domain summary
    if file_scores_df is not None and not file_scores_df.empty:
        try:
            payload = {
                "domain": f"{domain}/{subdomain}",
                "domain_summary": domain_summary,
                "file_scores": file_scores_df.to_dict(orient="records"),
                "field_scores": field_scores_all.to_dict(orient="records"),
                "weighted_domain_score": weighted_domain_score,
                "table_weights": table_weights,
            }
            ai_insights = get_dq_insights_with_llm(payload, domain=f"{domain}/{subdomain}")
        except Exception as e:
            ai_insights = f"Note: AI insights unavailable ({str(e)[:100]})"
    
    # Generate field-level AI summary
    if field_scores_all is not None and not field_scores_all.empty:
        try:
            # Get top 10 fields by importance (low scores or ID/email fields)
            critical_fields = field_scores_all.nsmallest(10, 'field_score')[['table', 'field', 'field_score', 'completeness', 'correctness', 'uniqueness']]
            field_summary_prompt = f"Summarize key findings for these critical fields:\n{critical_fields.to_string(index=False)}"
            field_level_summary = field_summary_prompt  # Placeholder for now
        except Exception:
            field_level_summary = None
    
    # Generate issues AI summary if issues exist
    if issues_all is not None and not issues_all.empty:
        try:
            issues_ai_summary = get_issues_summary_with_llm(issues_all, domain, subdomain)
        except Exception as e:
            issues_ai_summary = None
    
    # Initialize subdomain weights for multi-subdomain view
    subdomains = DOMAIN_SUBDOMAIN_MAP.get(domain, [])
    if len(subdomains) > 1:
        subdomain_weights = {sd: round(1.0 / len(subdomains), 3) for sd in subdomains}

    return render_template(
        "dashboard.html",
        domain=domain,
        subdomain=subdomain,
        subdomains=DOMAIN_SUBDOMAIN_MAP.get(domain, []),
        source=source,
        tables_data=tables_data,
        field_scores=field_scores_all,
        file_scores=file_scores_df,
        domain_summary=domain_summary,
        issues=issues_filtered,
        issues_tables=issues_tables,
        issues_types=issues_types,
        filter_table=filter_table,
        filter_issue=filter_issue,
        table_weights=table_weights,
        field_weights=field_weights,
        weighted_domain_score=weighted_domain_score,
        dq_rules_active=dq_rules_active,
        dq_rules_draft=dq_rules_draft,
        ai_rule_suggestions_text=ai_rule_suggestions_text,
        field_weight_suggestions_text=field_weight_suggestions_text,
        issues_ai_summary=issues_ai_summary,
        ai_insights=ai_insights,
        field_level_summary=field_level_summary,
        subdomain_weights=subdomain_weights,
        chart_labels=chart_labels,
        chart_scores=chart_scores,
    )


@app.route("/analytics")
def analytics():
    """Analytics and reports page with comprehensive metrics."""
    global last_field_scores, last_file_scores, last_issues, last_domain, last_subdomain
    
    # Calculate metrics from available data
    overall_score = 0
    tables_analyzed = 0
    issues_found = 0
    fields_checked = 0
    
    if last_file_scores is not None and not last_file_scores.empty:
        overall_score = int(last_file_scores['file_score'].mean())
        tables_analyzed = len(last_file_scores)
    
    if last_issues is not None and not last_issues.empty:
        issues_found = len(last_issues)
    
    if last_field_scores is not None and not last_field_scores.empty:
        fields_checked = len(last_field_scores)
    
    return render_template(
        "analytics.html",
        overall_score=overall_score,
        tables_analyzed=tables_analyzed,
        issues_found=issues_found,
        fields_checked=fields_checked,
        domain=last_domain,
        subdomain=last_subdomain,
    )


@app.route("/issues", methods=["GET"])
def issues():
    """Dedicated issues page with filtering and export options."""
    global last_issues, last_domain, last_subdomain
    
    if last_issues is None or last_issues.empty:
        flash("No issues found. Please run a data quality check first.", "warning")
        return redirect(url_for("dashboard"))
    
    # Calculate issue statistics
    total_issues = len(last_issues)
    critical_issues = len(last_issues[last_issues['severity'] == 'critical']) if 'severity' in last_issues.columns else 0
    high_issues = len(last_issues[last_issues['severity'] == 'high']) if 'severity' in last_issues.columns else 0
    medium_issues = len(last_issues[last_issues['severity'] == 'medium']) if 'severity' in last_issues.columns else 0
    
    # Apply filters if provided
    filter_table = request.args.get("table", "ALL")
    filter_severity = request.args.get("severity", "ALL")
    
    filtered_issues = last_issues.copy()
    if filter_table != "ALL":
        filtered_issues = filtered_issues[filtered_issues["table"] == filter_table]
    if filter_severity != "ALL":
        filtered_issues = filtered_issues[filtered_issues["severity"] == filter_severity]
    
    return render_template(
        "issues.html",
        issues=filtered_issues,
        total_issues=total_issues,
        critical_issues=critical_issues,
        high_issues=high_issues,
        medium_issues=medium_issues,
        domain=last_domain,
        subdomain=last_subdomain,
        filter_table=filter_table,
        filter_severity=filter_severity,
    )


@app.route("/weights_management", methods=["GET", "POST"])
def weights_management():
    """
    New page for managing weights at subdomain and table levels.
    Shows AI-suggested weights first, then allows human editing.
    """
    global subdomain_weights, table_weights, last_domain, last_subdomain
    
    domain = request.args.get("domain", "Investment Banking")
    
    # Pre-set subdomain weights if not already set
    if not subdomain_weights:
        subdomains = DOMAIN_SUBDOMAIN_MAP.get(domain, [])
        # Create default scores for AI to evaluate
        subdomain_scores = {sd: 85.0 for sd in subdomains}  # Default score
        try:
            subdomain_weights = get_subdomain_weights_with_llm(subdomain_scores, domain)
        except Exception:
            # Fallback to equal weights
            subdomain_weights = {sd: round(1.0 / len(subdomains), 3) for sd in subdomains}
    
    if request.method == "POST":
        action = request.form.get("action")
        
        if action == "ask_ai_subdomain_weights":
            # Generate AI suggestions for subdomain weights
            try:
                subdomains = DOMAIN_SUBDOMAIN_MAP.get(domain, [])
                # Create default scores for AI to evaluate
                subdomain_scores = {sd: 85.0 for sd in subdomains}
                subdomain_weights = get_subdomain_weights_with_llm(subdomain_scores, domain)
                flash(f"AI suggested subdomain weights applied successfully!", "success")
            except Exception as e:
                flash(f"Error getting AI subdomain weights: {e}", "danger")
        
        elif action == "save_subdomain_weights":
            # Save user-edited subdomain weights
            for subdomain in DOMAIN_SUBDOMAIN_MAP.get(domain, []):
                weight_key = f"subdomain_weight_{subdomain}"
                if weight_key in request.form:
                    try:
                        subdomain_weights[subdomain] = float(request.form[weight_key])
                    except ValueError:
                        pass
            flash("Subdomain weights saved successfully!", "success")
        
        elif action == "ask_ai_table_weights":
            # Generate AI suggestions for table weights within selected subdomain
            selected_subdomain = request.form.get("subdomain")
            if selected_subdomain:
                try:
                    # Load tables for this subdomain
                    tables_data = load_tables_from_sqlite(selected_subdomain)
                    
                    # Create a DataFrame with table names and dummy scores for AI
                    table_names = list(tables_data.keys())
                    dummy_scores = [85.0] * len(table_names)
                    file_scores_df = pd.DataFrame({
                        'table': table_names,
                        'file_score': dummy_scores
                    })
                    
                    weights = get_table_weights_with_llm(file_scores_df, domain, selected_subdomain)
                    for tbl, wt in weights.items():
                        table_weights[tbl] = wt
                    flash(f"AI suggested table weights for {selected_subdomain} applied successfully!", "success")
                except Exception as e:
                    flash(f"Error getting AI table weights: {e}", "danger")
        
        elif action == "save_table_weights":
            # Save user-edited table weights
            for key in request.form:
                if key.startswith("table_weight_"):
                    table_name = key.replace("table_weight_", "")
                    try:
                        table_weights[table_name] = float(request.form[key])
                    except ValueError:
                        pass
            flash("Table weights saved successfully!", "success")
        
        return redirect(url_for("weights_management", domain=domain))
    
    # GET request - display current weights
    return render_template(
        "weights_management.html",
        domain=domain,
        subdomains=DOMAIN_SUBDOMAIN_MAP.get(domain, []),
        subdomain_weights=subdomain_weights,
        table_weights=table_weights,
    )


@app.route("/download_issues")
def download_issues():
    global last_issues, last_domain, last_subdomain
    if last_issues is None or last_issues.empty:
        flash("No issues to download.", "warning")
        return redirect(url_for("dashboard"))

    csv_bytes = last_issues.to_csv(index=False).encode("utf-8")
    return send_file(
        io.BytesIO(csv_bytes),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"dq_issues_{last_subdomain or 'subdomain'}.csv",
    )


@app.route("/download_issues_pdf")
def download_issues_pdf():
    """Export issues summary and AI recommendations as PDF"""
    global last_issues, last_domain, last_subdomain, issues_ai_summary
    
    if last_issues is None or last_issues.empty:
        flash("No issues to export.", "warning")
        return redirect(url_for("dashboard"))
    
    try:
        from reportlab.lib.pagesizes import letter, A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
        from reportlab.lib import colors
        from datetime import datetime
        
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72,
                                topMargin=72, bottomMargin=18)
        
        # Container for the 'Flowable' objects
        elements = []
        
        # Define styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1f4788'),
            spaceAfter=30,
        )
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=16,
            textColor=colors.HexColor('#2c5aa0'),
            spaceAfter=12,
        )
        
        # Title
        title = Paragraph(f"Data Quality Issues Report", title_style)
        elements.append(title)
        
        # AI Generated Disclaimer
        disclaimer_style = ParagraphStyle(
            'Disclaimer',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#888888'),
            alignment=0,  # Left align
            spaceAfter=12,
        )
        disclaimer = Paragraph(
            "<i>⚠️ This report contains AI-generated insights and recommendations. "
            "Please review and validate all suggestions before implementation.</i>",
            disclaimer_style
        )
        elements.append(disclaimer)
        elements.append(Spacer(1, 12))
        
        # Metadata
        meta_text = f"""
        <b>Domain:</b> {last_domain}<br/>
        <b>Subdomain:</b> {last_subdomain}<br/>
        <b>Generated:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}<br/>
        <b>Total Issues:</b> {len(last_issues)}
        """
        elements.append(Paragraph(meta_text, styles['Normal']))
        elements.append(Spacer(1, 20))
        
        # Issue Summary by Type
        elements.append(Paragraph("Issue Summary by Type", heading_style))
        issue_summary = last_issues.groupby(['issue_type', 'severity']).size().reset_index(name='count')
        summary_data = [['Issue Type', 'Severity', 'Count']]
        for _, row in issue_summary.iterrows():
            summary_data.append([row['issue_type'], row['severity'], str(row['count'])])
        
        summary_table = Table(summary_data, colWidths=[2.5*inch, 1.5*inch, 1*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        elements.append(summary_table)
        elements.append(Spacer(1, 20))
        
        # AI Summary and Recommendations
        if issues_ai_summary:
            elements.append(Paragraph("AI-Generated Analysis", heading_style))
            
            # Summary
            elements.append(Paragraph("<b>Executive Summary:</b>", styles['Heading3']))
            summary_text = issues_ai_summary.get('summary', 'No summary available')
            elements.append(Paragraph(summary_text, styles['Normal']))
            elements.append(Spacer(1, 12))
            
            # Recommendations
            elements.append(Paragraph("<b>Recommendations:</b>", styles['Heading3']))
            recommendations = issues_ai_summary.get('recommendations', [])
            for i, rec in enumerate(recommendations, 1):
                elements.append(Paragraph(f"{i}. {rec}", styles['Normal']))
            elements.append(Spacer(1, 12))
            
            # Example Queries
            elements.append(Paragraph("<b>Example Investigation Queries:</b>", styles['Heading3']))
            queries = issues_ai_summary.get('example_queries', [])
            for i, query in enumerate(queries, 1):
                elements.append(Paragraph(f"<font name='Courier' size=9>{query}</font>", styles['Code']))
                elements.append(Spacer(1, 6))
            
            elements.append(PageBreak())
        
        # Detailed Issues (first 50)
        elements.append(Paragraph("Detailed Issues (Top 50)", heading_style))
        issue_data = [['Table', 'Field', 'Row', 'Issue Type', 'Severity']]
        for _, row in last_issues.head(50).iterrows():
            issue_data.append([
                str(row['table'])[:20],
                str(row['field'])[:15],
                str(row['row_index']),
                str(row['issue_type']),
                str(row['severity'])
            ])
        
        issue_table = Table(issue_data, colWidths=[1.3*inch, 1.2*inch, 0.7*inch, 1.3*inch, 0.9*inch])
        issue_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        elements.append(issue_table)
        
        # Build PDF
        doc.build(elements)
        buffer.seek(0)
        
        return send_file(
            buffer,
            mimetype="application/pdf",
            as_attachment=True,
            download_name=f"dq_issues_report_{last_subdomain}_{datetime.now().strftime('%Y%m%d')}.pdf",
        )
    except ImportError:
        flash("reportlab library not installed. Install it with: pip install reportlab", "danger")
        return redirect(url_for("dashboard"))
    except Exception as e:
        flash(f"Error generating PDF: {e}", "danger")
        return redirect(url_for("dashboard"))


@app.route("/export_ai_insights")
def export_ai_insights():
    """
    Export all AI-generated insights, analysis, and suggestions as a PDF report.
    Includes disclaimer about AI-generated content.
    """
    global ai_insights, field_level_summary, issues_ai_summary, last_domain, last_subdomain
    
    if not ai_insights and not field_level_summary:
        flash("No AI insights available to export.", "warning")
        return redirect(url_for("dashboard"))
    
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib import colors
        from datetime import datetime
        import io
        
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        elements = []
        styles = getSampleStyleSheet()
        
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1a237e'),
            spaceAfter=30,
            alignment=1,  # Center
        )
        
        disclaimer_style = ParagraphStyle(
            'Disclaimer',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#d32f2f'),
            backgroundColor=colors.HexColor('#ffebee'),
            borderColor=colors.HexColor('#d32f2f'),
            borderWidth=1,
            borderPadding=10,
            alignment=0,
            spaceAfter=20,
        )
        
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=16,
            textColor=colors.HexColor('#1976d2'),
            spaceAfter=12,
        )
        
        # Title
        title = Paragraph("TCS Data Quality - AI Insights Report", title_style)
        elements.append(title)
        
        # Disclaimer
        disclaimer_text = (
            "<b>⚠️ AI-GENERATED CONTENT DISCLAIMER</b><br/>"
            "This report contains insights, analysis, and recommendations generated by artificial intelligence. "
            "All content should be reviewed and validated by qualified personnel before implementation. "
            "TCS does not guarantee the accuracy or completeness of AI-generated suggestions."
        )
        disclaimer = Paragraph(disclaimer_text, disclaimer_style)
        elements.append(disclaimer)
        elements.append(Spacer(1, 20))
        
        # Metadata
        meta_text = f"""
        <b>Domain:</b> {last_domain or 'N/A'}<br/>
        <b>Subdomain:</b> {last_subdomain or 'N/A'}<br/>
        <b>Generated:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}<br/>
        <b>Report Type:</b> AI Insights and Analysis
        """
        elements.append(Paragraph(meta_text, styles['Normal']))
        elements.append(Spacer(1, 30))
        
        # Domain-Level Insights
        if ai_insights:
            elements.append(Paragraph("Domain-Level Insights", heading_style))
            insight_text = ai_insights.replace('\n', '<br/>')
            elements.append(Paragraph(insight_text, styles['Normal']))
            elements.append(Spacer(1, 20))
        
        # Field-Level Analysis
        if field_level_summary:
            elements.append(Paragraph("Critical Fields Analysis", heading_style))
            field_text = field_level_summary.replace('\n', '<br/>')
            elements.append(Paragraph(field_text, styles['Normal']))
            elements.append(Spacer(1, 20))
        
        # Issues Summary
        if issues_ai_summary:
            elements.append(PageBreak())
            elements.append(Paragraph("Issues Analysis & Recommendations", heading_style))
            
            if isinstance(issues_ai_summary, dict):
                # Summary
                if 'summary' in issues_ai_summary:
                    elements.append(Paragraph("<b>Executive Summary:</b>", styles['Heading3']))
                    elements.append(Paragraph(issues_ai_summary['summary'], styles['Normal']))
                    elements.append(Spacer(1, 12))
                
                # Recommendations
                if 'recommendations' in issues_ai_summary:
                    elements.append(Paragraph("<b>Recommendations:</b>", styles['Heading3']))
                    for i, rec in enumerate(issues_ai_summary['recommendations'], 1):
                        elements.append(Paragraph(f"{i}. {rec}", styles['Normal']))
                    elements.append(Spacer(1, 12))
                
                # Example Queries
                if 'example_queries' in issues_ai_summary:
                    elements.append(Paragraph("<b>Example Investigation Queries:</b>", styles['Heading3']))
                    for query in issues_ai_summary['example_queries']:
                        elements.append(Paragraph(f"• <font name='Courier'>{query}</font>", styles['Normal']))
        
        # Footer disclaimer
        elements.append(Spacer(1, 30))
        footer_disclaimer = Paragraph(
            "<i>This report was generated by TCS Data Quality Dashboard with AI assistance. "
            "Review all recommendations before implementation.</i>",
            ParagraphStyle('Footer', parent=styles['Normal'], fontSize=8, textColor=colors.grey)
        )
        elements.append(footer_disclaimer)
        
        # Build PDF
        doc.build(elements)
        buffer.seek(0)
        
        return send_file(
            buffer,
            mimetype="application/pdf",
            as_attachment=True,
            download_name=f"TCS_DQ_AI_Insights_{last_subdomain}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
        )
        
    except ImportError:
        flash("reportlab library not installed. Install it with: pip install reportlab", "danger")
        return redirect(url_for("dashboard"))
    except Exception as e:
        flash(f"Error generating AI insights PDF: {e}", "danger")
        return redirect(url_for("dashboard"))


@app.route("/send_domain_summary_email")
def send_domain_summary_email():
    """
    Generate an email summary of domain analysis with AI insights.
    Includes disclaimer about AI-generated content.
    """
    global ai_insights, field_level_summary, last_domain, last_subdomain, last_domain_summary, last_file_scores
    
    if not ai_insights and not field_level_summary:
        flash("No AI insights available to email.", "warning")
        return redirect(url_for("dashboard"))
    
    try:
        from datetime import datetime
        
        # Calculate overall score from file scores if domain summary not available
        overall_score = 'N/A'
        if last_domain_summary:
            overall_score = f"{last_domain_summary.get('domain_score', 'N/A')}"
        elif last_file_scores is not None and not last_file_scores.empty:
            overall_score = f"{int(last_file_scores['file_score'].mean())}"
        
        # Generate email body
        email_body = f"""
Subject: Data Quality Summary - {last_domain or 'N/A'} / {last_subdomain or 'N/A'}

⚠️ AI-GENERATED EMAIL - Please review before sending ⚠️

Dear Team,

This is an automated summary of the Data Quality analysis for {last_domain or 'N/A'} / {last_subdomain or 'N/A'}.

OVERVIEW:
---------
Domain: {last_domain or 'N/A'}
Subdomain: {last_subdomain or 'N/A'}
Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Domain Score: {overall_score}%

DQ DIMENSIONS:
-------------
Completeness: {last_domain_summary.get('completeness', 'N/A') if last_domain_summary else 'N/A'}%
Correctness: {last_domain_summary.get('correctness', 'N/A') if last_domain_summary else 'N/A'}%
Uniqueness: {last_domain_summary.get('uniqueness', 'N/A') if last_domain_summary else 'N/A'}%

AI-GENERATED DOMAIN INSIGHTS:
-----------------------------
{ai_insights if ai_insights else 'No domain insights available.'}

CRITICAL FIELDS ANALYSIS:
------------------------
{field_level_summary if field_level_summary else 'No field-level analysis available.'}

NEXT STEPS:
----------
1. Review the detailed dashboard at: {request.host_url}dashboard
2. Validate AI recommendations before implementation
3. Address critical data quality issues identified
4. Schedule follow-up analysis as needed

---
⚠️ AI CONTENT DISCLAIMER:
This email contains insights and recommendations generated by artificial intelligence. 
All content should be reviewed and validated by qualified personnel before implementation. 
TCS does not guarantee the accuracy or completeness of AI-generated suggestions.

Generated by: TCS Data Quality Dashboard
Report Type: Domain Summary with AI Insights
---

Best regards,
Data Quality Team
"""
        
        # For demo purposes, display the email preview
        flash("Email preview generated! In production, this would be sent via SMTP.", "info")
        
        return render_template(
            "email_preview.html",
            email_body=email_body,
            domain=last_domain,
            subdomain=last_subdomain,
            email_type="Domain Summary"
        )
        
    except Exception as e:
        flash(f"Error generating email: {e}", "danger")
        return redirect(url_for("dashboard"))


@app.route("/email_issues")
def email_issues():
    """
    Generate email body and provide both email text and PDF attachment.
    In production, this would integrate with SMTP to send emails.
    """
    global last_issues, last_domain, last_subdomain, issues_ai_summary, ai_insights
    
    if last_issues is None or last_issues.empty:
        flash("No issues to email.", "warning")
        return redirect(url_for("dashboard"))
    
    try:
        # Generate AI email body
        summary_data = {
            "domain": last_domain,
            "subdomain": last_subdomain,
            "total_issues": len(last_issues),
            "critical_count": len(last_issues[last_issues['severity'] == 'critical']) if 'severity' in last_issues.columns else 0,
            "high_count": len(last_issues[last_issues['severity'] == 'high']) if 'severity' in last_issues.columns else 0,
        }
        
        email_body = generate_email_body(summary_data, last_domain, last_subdomain)
        
        # Add disclaimer
        email_with_disclaimer = f"""
⚠️ AI-GENERATED EMAIL - Please review before sending ⚠️

{email_body}

---
This report and analysis were generated using AI assistance. 
Please validate all findings and recommendations before taking action.
"""
        
        # For hackathon demo, display the email text
        flash("Email preview generated! In production, this would be sent via SMTP.", "info")
        
        return render_template(
            "email_preview.html",
            email_body=email_with_disclaimer,
            domain=last_domain,
            subdomain=last_subdomain,
            total_issues=len(last_issues),
        )
        
    except Exception as e:
        flash(f"Error generating email: {e}", "danger")
        return redirect(url_for("dashboard"))


@app.route("/generate_executive_report")
def generate_executive_report():
    """Generate Executive Summary PDF Report"""
    global last_file_scores, last_field_scores, last_issues, last_domain, last_subdomain, weighted_domain_score
    
    if last_file_scores is None or last_file_scores.empty:
        flash("No data available. Please run a data quality check first.", "warning")
        return redirect(url_for("analytics"))
    
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib import colors
        from reportlab.lib.units import inch
        from datetime import datetime
        
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        elements = []
        styles = getSampleStyleSheet()
        
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1a237e'),
            spaceAfter=20,
            alignment=1,
        )
        
        disclaimer_style = ParagraphStyle(
            'Disclaimer',
            parent=styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#d32f2f'),
            backgroundColor=colors.HexColor('#ffebee'),
            borderColor=colors.HexColor('#d32f2f'),
            borderWidth=1,
            borderPadding=8,
            alignment=0,
            spaceAfter=20,
        )
        
        # Title
        title = Paragraph("Executive Summary - Data Quality Report", title_style)
        elements.append(title)
        
        # AI Disclaimer
        disclaimer_text = (
            "<b>⚠️ AI-GENERATED CONTENT DISCLAIMER</b><br/>"
            "This report contains AI-generated insights and recommendations. "
            "All content should be reviewed and validated by qualified personnel before implementation."
        )
        disclaimer = Paragraph(disclaimer_text, disclaimer_style)
        elements.append(disclaimer)
        elements.append(Spacer(1, 20))
        
        # Metadata
        meta_text = f"""
        <b>Domain:</b> {last_domain or 'N/A'}<br/>
        <b>Subdomain:</b> {last_subdomain or 'N/A'}<br/>
        <b>Generated:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}<br/>
        <b>Report Type:</b> Executive Summary
        """
        elements.append(Paragraph(meta_text, styles['Normal']))
        elements.append(Spacer(1, 20))
        
        # Key Metrics
        elements.append(Paragraph("Key Metrics", styles['Heading2']))
        overall_score = int(last_file_scores['file_score'].mean()) if not last_file_scores.empty else 0
        total_issues = len(last_issues) if last_issues is not None and not last_issues.empty else 0
        
        metrics_data = [
            ['Metric', 'Value'],
            ['Overall DQ Score', f"{overall_score}%"],
            ['Tables Analyzed', str(len(last_file_scores))],
            ['Total Issues Found', str(total_issues)],
            ['Fields Checked', str(len(last_field_scores)) if last_field_scores is not None else '0'],
        ]
        
        metrics_table = Table(metrics_data, colWidths=[3*inch, 2*inch])
        metrics_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        elements.append(metrics_table)
        elements.append(Spacer(1, 20))
        
        # Table Scores
        elements.append(Paragraph("Table Quality Scores", styles['Heading2']))
        table_data = [['Table Name', 'Quality Score', 'Status']]
        for _, row in last_file_scores.iterrows():
            score = row['file_score']
            status = 'Excellent' if score >= 90 else 'Good' if score >= 75 else 'Fair' if score >= 60 else 'Poor'
            table_data.append([row['table'], f"{score}%", status])
        
        scores_table = Table(table_data, colWidths=[2.5*inch, 1.5*inch, 1.5*inch])
        scores_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        elements.append(scores_table)
        
        # Build PDF
        doc.build(elements)
        buffer.seek(0)
        
        return send_file(
            buffer,
            mimetype="application/pdf",
            as_attachment=True,
            download_name=f"Executive_Summary_{last_subdomain}_{datetime.now().strftime('%Y%m%d')}.pdf",
        )
        
    except ImportError:
        flash("reportlab library not installed. Install with: pip install reportlab", "danger")
        return redirect(url_for("analytics"))
    except Exception as e:
        flash(f"Error generating PDF: {e}", "danger")
        return redirect(url_for("analytics"))


@app.route("/generate_detailed_report")
def generate_detailed_report():
    """Generate Detailed Analysis Excel Report"""
    global last_field_scores, last_file_scores, last_issues, last_domain, last_subdomain
    
    if last_field_scores is None or last_field_scores.empty:
        flash("No data available. Please run a data quality check first.", "warning")
        return redirect(url_for("analytics"))
    
    try:
        from datetime import datetime
        
        # Create Excel file in memory
        output = io.BytesIO()
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            # Sheet 1: Field Scores
            field_df = last_field_scores.copy()
            field_df.to_excel(writer, sheet_name='Field Scores', index=False)
            
            # Sheet 2: Table Scores
            if last_file_scores is not None and not last_file_scores.empty:
                table_df = last_file_scores.copy()
                table_df.to_excel(writer, sheet_name='Table Scores', index=False)
            
            # Sheet 3: Issues
            if last_issues is not None and not last_issues.empty:
                issues_df = last_issues.copy()
                issues_df.to_excel(writer, sheet_name='Issues', index=False)
            
            # Sheet 4: AI Disclaimer
            disclaimer_data = {
                'DISCLAIMER': [
                    '⚠️ AI-GENERATED CONTENT DISCLAIMER',
                    '',
                    'This report contains AI-generated insights and recommendations.',
                    'All content should be reviewed and validated by qualified personnel before implementation.',
                    'TCS does not guarantee the accuracy or completeness of AI-generated suggestions.',
                    '',
                    f'Report Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}',
                    f'Domain: {last_domain or "N/A"}',
                    f'Subdomain: {last_subdomain or "N/A"}',
                ]
            }
            disclaimer_df = pd.DataFrame(disclaimer_data)
            disclaimer_df.to_excel(writer, sheet_name='Disclaimer', index=False)
        
        output.seek(0)
        
        return send_file(
            output,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name=f"Detailed_Analysis_{last_subdomain}_{datetime.now().strftime('%Y%m%d')}.xlsx",
        )
        
    except ImportError:
        flash("openpyxl library not installed. Install with: pip install openpyxl", "danger")
        return redirect(url_for("analytics"))
    except Exception as e:
        flash(f"Error generating Excel: {e}", "danger")
        return redirect(url_for("analytics"))


@app.route("/generate_ai_insights_report")
def generate_ai_insights_report():
    """Generate AI Insights Report (reusing existing functionality)"""
    return export_ai_insights()


if __name__ == "__main__":
    app.run(debug=True)
