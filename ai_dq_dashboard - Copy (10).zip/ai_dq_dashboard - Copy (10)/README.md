# AI Data Quality Dashboard - Hackathon Edition

![Python](https://img.shields.io/badge/python-3.12-blue.svg)
![Flask](https://img.shields.io/badge/flask-latest-green.svg)
![Status](https://img.shields.io/badge/status-ready-success.svg)

An AI-powered Data Quality monitoring dashboard for Investment Banking, featuring HR and Finance subdomains with comprehensive DQ analysis, AI-driven insights, and automated reporting.

## 🎯 Key Features

### ✨ New in Hackathon Edition

1. **Domain/Subdomain Hierarchy**
   - Investment Banking as primary domain
   - HR and Finance as subdomains
   - Hierarchical data organization and scoring

2. **Editable Field Weights** 
   - Human-editable weight customization
   - AI-powered weight suggestions
   - Real-time score recalculation

3. **Complete Issue Detection**
   - Completeness issues
   - Correctness issues (phone, salary, amount, status)
   - Uniqueness issues
   - Duplicity detection
   - Key-ID duplicity detection

4. **AI-Powered Analysis**
   - Executive summaries
   - Actionable recommendations
   - Example investigation queries
   - Context-aware rule suggestions

5. **PDF Export**
   - Comprehensive issue reports
   - AI insights included
   - Professional formatting

6. **Smart DQ Rules**
   - Dynamic impact on all calculations
   - AI-assisted rule improvements
   - Subdomain-specific suggestions

## 🚀 Quick Start

### Prerequisites
- Python 3.12 at `C:\Program Files\Python312`
- Virtual environment at `C:\Users\genAIINDSEZUSR47\.venv`

### Installation

```powershell
# Activate virtual environment
C:\Users\genAIINDSEZUSR47\.venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

Visit: **http://127.0.0.1:5000**

### First Time Setup

1. Click **"Generate HR Sample"** button
2. Click **"Generate Finance Sample"** button
3. Select **"Investment Banking"** > **"HR"**
4. Click **"Apply"**
5. Explore the dashboard!

## 📊 Dashboard Tabs

### 1. Domain Summary
- Overall DQ scores
- Colorful visualization charts
- Table-level weights configuration
- AI insights generation

### 2. Tables & Fields
- Field-level DQ metrics
- Completeness, correctness, uniqueness scores
- Data preview and profiling

### 3. Field Weights ⭐
- **Editable weights** (NEW!)
- Save custom configurations
- AI-powered suggestions

### 4. Issues & Export ⭐
- **All issue types** (ENHANCED!)
- Advanced filtering
- **AI summary generation** (NEW!)
- **PDF export** (NEW!)

### 5. DQ Rules ⭐
- Draft and active rules management
- **Context-aware AI suggestions** (ENHANCED!)
- Real-time impact on calculations

## 🎓 Usage Examples

### Analyze HR Data Quality
```
1. Select: Investment Banking > HR > SQLite Demo DB
2. Navigate to: Issues & Export tab
3. Click: "Generate AI Summary"
4. Click: "📄 Export PDF Report"
```

### Customize Field Weights
```
1. Navigate to: Field Weights tab
2. Edit: Wc, Wr, Wu values for desired fields
3. Click: "💾 Save Field Weights"
4. View: Updated scores in Domain Summary
```

### Improve DQ Rules with AI
```
1. Navigate to: DQ Rules tab
2. Click: "🤖 Ask AI to Improve Rules"
3. Review: AI suggestions
4. Click: "✅ Approve Draft as Active"
```

## 🏗️ Architecture

```
ai_dq_dashboard/
├── app.py                  # Flask application & routes
├── config.py              # Configuration & domain structure
├── db_utils.py            # Database operations
├── dq_rules.py            # DQ calculation logic
├── llm_client.py          # AI/LLM integration
├── requirements.txt       # Python dependencies
├── templates/
│   ├── base.html         # Base template
│   └── dashboard.html    # Main dashboard UI
├── static/
│   └── custom.css        # Custom styling
├── CHANGES.md            # Detailed change log
├── QUICKSTART.md         # Quick start guide
└── README.md             # This file
```

## 🔧 Technology Stack

- **Backend**: Flask (Python 3.12)
- **Database**: SQLite with SQLAlchemy
- **AI/LLM**: LangChain + OpenAI-compatible API
- **Frontend**: Bootstrap 5 + Chart.js
- **PDF Generation**: ReportLab
- **Data Processing**: Pandas

## 📝 What Changed

See [CHANGES.md](CHANGES.md) for comprehensive list of all modifications.

### Summary of Changes:
1. ✅ Domain/Subdomain hierarchy (Investment Banking > HR/Finance)
2. ✅ Editable field weights with save functionality
3. ✅ Complete issue type detection (all 5 types)
4. ✅ AI-powered issue summaries and recommendations
5. ✅ PDF export with AI insights
6. ✅ Context-aware DQ rule suggestions
7. ✅ Enhanced filtering and UI improvements

## 🎯 Hackathon Demo Flow

1. **Show Hierarchy**: Investment Banking > HR/Finance subdomains
2. **Generate Data**: Click sample data buttons
3. **Edit Weights**: Demonstrate real-time editing
4. **Show Issues**: All types + filtering
5. **AI Summary**: Generate and show insights
6. **Export PDF**: Download and display report
7. **Smart Rules**: AI improvements with context

## 📚 Documentation

- **Quick Start**: See [QUICKSTART.md](QUICKSTART.md)
- **Detailed Changes**: See [CHANGES.md](CHANGES.md)
- **API Docs**: See inline code comments

## 🐛 Troubleshooting

### No data showing?
→ Click "Generate HR Sample" and "Generate Finance Sample"

### AI not working?
→ Check `GENAILAB_API_KEY` in `config.py`

### PDF export failing?
→ Run: `pip install reportlab`

### Weights not saving?
→ Ensure you clicked "💾 Save Field Weights" button

## 🔒 Security Notes

- API key currently hardcoded (move to environment variables for production)
- In-memory state (use database for production)
- No authentication (add for production use)
- SQL injection protection via SQLAlchemy

## 🚧 Known Limitations

1. In-memory state (resets on restart)
2. Single-user session design
3. Basic PDF styling
4. No rate limiting on AI calls
5. Limited to top 50 issues in PDF

## 📈 Future Enhancements

- Database persistence for rules/weights
- User authentication & multi-tenancy
- Scheduled email reports
- Interactive PDF charts
- Real-time updates via WebSockets
- Excel export with formatting
- Custom rule builder UI

## 👥 Team

Developed for the Data Quality Hackathon

## 📄 License

Internal use for hackathon demonstration

## 🙏 Acknowledgments

- TCS GenAI Lab for LLM API access
- Flask and SQLAlchemy communities
- ReportLab for PDF generation
- Bootstrap for responsive UI

---

**Version**: 2.0 (Hackathon Edition)  
**Last Updated**: December 6, 2025  
**Status**: Ready for Demo ✅

For questions or support, refer to the documentation or code comments.
