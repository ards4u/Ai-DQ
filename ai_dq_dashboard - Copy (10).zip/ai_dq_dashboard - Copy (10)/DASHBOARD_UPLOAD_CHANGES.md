# Dashboard CSV Upload & Configuration Changes

## Date: December 6, 2025

## Overview
Modified the Dashboard page to improve CSV upload functionality and add dynamic subdomain-based data loading.

---

## Changes Implemented

### 1. **Separated Domain/Subdomain Configuration Section**

**Location:** `templates/dashboard.html`

**Changes:**
- Created a dedicated **Configuration Card** with:
  - Domain dropdown (Investment Banking)
  - Subdomain dropdown (HR, Finance, Operations, Compliance)
  - Data Source selector (SQLite or CSV)
  - "Load Data" button

**Features:**
- Clean, professional card design with gradient header
- Auto-submit on subdomain change for SQLite data source
- Shows/hides CSV upload section based on source selection

**Benefits:**
- Clear separation of concerns
- Better UX with auto-refresh for pre-loaded data
- No page refresh when changing subdomain (for SQLite)

---

### 2. **Enhanced CSV Upload Section with Table Names**

**Location:** `templates/dashboard.html`

**New Features:**
- **Multiple File Upload with Custom Names**: Users can now:
  - Assign custom table names to each CSV file
  - Upload multiple CSV files in one go
  - Add/remove file input rows dynamically
  
**UI Components:**
- Table Name input field (text)
- CSV File input field (file upload)
- Remove button for each row (except first)
- "Add Another File" button
- "Analyze All Files" button

**JavaScript Functionality:**
```javascript
- addFileRow(): Dynamically adds new file input rows
- removeFileRow(button): Removes a specific file input row
- Auto show/hide based on source selection
- Auto-submit on subdomain change (for SQLite)
```

---

### 3. **Backend Changes**

**Location:** `app.py`

#### A. New Function: `load_tables_from_csv_with_names()`
```python
def load_tables_from_csv_with_names(files, table_names) -> dict:
    """Load multiple uploaded CSVs with custom table names."""
    tables_data = {}
    for file, table_name in zip(files, table_names):
        if not file.filename or not table_name:
            continue
        clean_name = table_name.strip().replace(" ", "_")
        df = pd.read_csv(file)
        tables_data[clean_name] = df
    return tables_data
```

#### B. New Action Handler: `upload_csv`
```python
if action == "upload_csv":
    domain = request.form.get("domain", domain)
    subdomain = request.form.get("subdomain", subdomain)
    source = "csv"
    
    csv_files = request.files.getlist("csv_files[]")
    table_names = request.form.getlist("table_names[]")
    
    if csv_files and table_names and len(csv_files) == len(table_names):
        tables_data = load_tables_from_csv_with_names(csv_files, table_names)
        flash(f"Successfully uploaded {len(tables_data)} CSV files.", "success")
        last_tables_data = tables_data
        last_source = "csv"
```

#### C. Fixed Action Handler Chain
Changed all `if action ==` to `elif action ==` (except the first one) to ensure proper handling:
- `if action == "upload_csv"`
- `elif action == "change_main"`
- `elif action == "save_rules"`
- `elif action == "ask_ai_rules"`
- `elif action == "approve_rules"`
- `elif action == "save_table_weights"`
- `elif action == "ask_ai_table_weights"`
- `elif action == "save_field_weights"`
- `elif action == "ask_ai_field_weights"`
- `elif action == "generate_issues_summary"`

**Why:** Using `elif` ensures only one action is processed per request, preventing conflicts and unexpected behavior.

---

### 4. **Dynamic Subdomain Change for Pre-loaded Data**

**Feature:** When user changes subdomain dropdown (with SQLite source selected):
- JavaScript automatically submits the form
- Page reloads with new subdomain data
- DQ scores and analysis update automatically
- User stays on the same page (no redirect to home)

**Implementation:**
```javascript
document.getElementById('subdomainSelect').addEventListener('change', function() {
    const source = document.getElementById('sourceSelect').value;
    if (source === 'sqlite') {
        document.getElementById('configForm').submit();
    }
});
```

---

## User Workflow

### **Workflow 1: Using Pre-loaded Data (SQLite)**
1. Select Domain: "Investment Banking"
2. Select Subdomain: "HR" or "Finance"
3. Select Source: "Pre-loaded Data (SQLite)"
4. Click "Load Data" OR just change subdomain (auto-loads)
5. View DQ scores and analysis immediately

### **Workflow 2: Uploading CSV Files**
1. Select Domain: "Investment Banking"
2. Select Subdomain: "HR" (or any)
3. Select Source: "Upload CSV Files"
4. CSV Upload section appears
5. Enter table name (e.g., "employees")
6. Select CSV file
7. Click "Add Another File" for more files
8. Enter table names and select files for each
9. Click "Analyze All Files"
10. View DQ scores and analysis

---

## Benefits

### 1. **Better User Experience**
- Clear, intuitive interface
- Logical flow: Configure → Upload → Analyze
- Visual feedback with flash messages
- No confusion between configuration and upload

### 2. **Flexibility**
- Support for both pre-loaded and custom data
- Multiple file upload in one submission
- Custom table naming for better organization

### 3. **Dynamic Updates**
- Auto-refresh on subdomain change (SQLite)
- No need to navigate away from dashboard
- All scores update automatically

### 4. **Maintainability**
- Clean separation of concerns
- Proper action handling with `elif`
- Reusable JavaScript functions
- Well-commented code

---

## Testing Checklist

- [ ] Configuration section displays correctly
- [ ] Domain dropdown shows "Investment Banking"
- [ ] Subdomain dropdown shows all 4 subdomains
- [ ] Source dropdown toggles CSV section visibility
- [ ] Subdomain change auto-loads SQLite data
- [ ] CSV upload section appears when source is "CSV"
- [ ] Can add multiple file input rows
- [ ] Can remove file input rows (except first)
- [ ] Table name validation works
- [ ] File upload accepts only .csv files
- [ ] Multiple files upload successfully
- [ ] Custom table names are applied
- [ ] DQ scores update after upload
- [ ] All flash messages display correctly
- [ ] No redirect to home page after actions
- [ ] All tabs (Summary, Tables & Fields, etc.) work
- [ ] Charts display correctly

---

## Files Modified

1. **`templates/dashboard.html`**
   - Added Configuration card
   - Enhanced CSV upload section
   - Added JavaScript for dynamic behavior

2. **`app.py`**
   - Added `load_tables_from_csv_with_names()` function
   - Added `upload_csv` action handler
   - Fixed action handler chain with `elif`
   - Improved redirect logic to stay on dashboard

---

## Known Issues & Limitations

1. **File Size**: No file size validation (relies on Flask defaults)
2. **File Type**: Basic validation (only .csv accepted in HTML)
3. **Error Handling**: Basic error messages (could be more specific)
4. **Duplicate Names**: No validation for duplicate table names

---

## Future Enhancements

1. **File Validation:**
   - Check CSV format before upload
   - Validate file size
   - Check for duplicate table names
   - Preview CSV headers before analysis

2. **Progress Indication:**
   - Upload progress bar
   - Processing spinner
   - Real-time status updates

3. **Batch Operations:**
   - Download multiple tables as ZIP
   - Export all analyses to single PDF
   - Bulk delete uploaded files

4. **File Management:**
   - List previously uploaded files
   - Delete uploaded files
   - Re-analyze existing files

5. **Advanced Features:**
   - Drag-and-drop file upload
   - Excel file support (.xlsx)
   - Auto-detect table names from filenames
   - Schema validation

---

## Technical Notes

### Form Data Structure

**Configuration Form:**
```
GET /dashboard?domain=Investment%20Banking&subdomain=HR&source=sqlite
```

**CSV Upload Form:**
```
POST /dashboard
Content-Type: multipart/form-data

action: upload_csv
domain: Investment Banking
subdomain: HR
table_names[]: employees
table_names[]: departments
csv_files[]: <file1.csv>
csv_files[]: <file2.csv>
```

### JavaScript Event Handlers

1. **Source Change**: Show/hide CSV section
2. **Subdomain Change**: Auto-submit for SQLite
3. **Add File Row**: Clone first row
4. **Remove File Row**: Remove specific row

### Backend Flow

```
1. User submits form
   ↓
2. Check action type (if/elif chain)
   ↓
3. Process specific action
   ↓
4. Validate inputs
   ↓
5. Load/process data
   ↓
6. Compute DQ scores
   ↓
7. Generate AI insights
   ↓
8. Render dashboard with results
   ↓
9. Stay on same page (no redirect)
```

---

## Summary

Successfully implemented a modern, user-friendly CSV upload system with:
- ✅ Separate configuration section
- ✅ Custom table naming
- ✅ Multiple file support
- ✅ Dynamic subdomain loading
- ✅ Proper action handling
- ✅ No unwanted redirects
- ✅ Auto-refresh for pre-loaded data

The dashboard now provides a professional, intuitive interface for both pre-loaded and custom data analysis!
