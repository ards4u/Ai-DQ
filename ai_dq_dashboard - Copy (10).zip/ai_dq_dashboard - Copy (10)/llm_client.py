## Human Change
import json
from typing import Dict, Any

import httpx
import pandas as pd
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

from config import GENAILAB_BASE_URL, GENAILAB_MODEL, GENAILAB_API_KEY, BLACKLIST_SQL


client = httpx.Client(verify=False)

# Guardrails configuration
guardrails_enabled = True
max_tokens_per_request = 2000
rate_limit_calls_per_minute = 10
input_max_length = 10000

# Rate limiting state
_call_timestamps = []


def get_llm():
    # If key missing, we will fail fast in safe_llm_call and caller will fallback.
    if not GENAILAB_API_KEY:
        raise RuntimeError("GENAILAB_API_KEY is not set in environment.")
    return ChatOpenAI(
        base_url=GENAILAB_BASE_URL,
        model=GENAILAB_MODEL,
        api_key=GENAILAB_API_KEY,
        http_client=client,
        temperature=0.3,
    )


def guard_prompt(user_prompt: str, domain: str | None = None) -> str:
    """
    Input guardrails: validate and sanitize user prompts.
    """
    if not guardrails_enabled:
        return user_prompt
    
    # Length check
    if len(user_prompt) > input_max_length:
        user_prompt = user_prompt[:input_max_length] + "... (truncated)"
    
    # Content filtering - remove potentially malicious patterns
    dangerous_patterns = ["<script", "javascript:", "eval(", "exec("]
    for pattern in dangerous_patterns:
        if pattern.lower() in user_prompt.lower():
            raise ValueError(f"Input contains potentially dangerous pattern: {pattern}")
    
    domain = domain or "HR and Finance"
    return (
        "You are a Data Quality assistant for an IT company.\n"
        f"Focus ONLY on data quality for {domain} data (HR/Finance).\n"
        "Never propose destructive SQL like DROP/TRUNCATE/DELETE/ALTER.\n"
        "Never include code execution commands or system operations.\n"
        "Only provide data quality insights, recommendations, and analysis.\n"
        "\nUser Request:\n"
        f"{user_prompt}"
    )


def guard_result(text: str) -> tuple[str, bool]:
    """
    Output guardrails: validate AI responses.
    """
    if not guardrails_enabled:
        return text, True
    
    lower = text.lower()
    
    # SQL injection detection
    for bad in BLACKLIST_SQL:
        if bad in lower:
            return (
                "⚠️ GUARDRAIL BLOCKED: The AI attempted to suggest unsafe or destructive operations. "
                "These have been blocked by TCS security guardrails.",
                False,
            )
    
    # Additional safety checks
    dangerous_outputs = ["rm -rf", "del /f", "format c:", "sudo", "chmod 777"]
    for danger in dangerous_outputs:
        if danger in lower:
            return (
                "⚠️ GUARDRAIL BLOCKED: Potentially harmful system command detected and blocked.",
                False,
            )
    
    return text, True


def check_rate_limit() -> bool:
    """Check if we're within rate limits."""
    import time
    
    if not guardrails_enabled:
        return True
    
    global _call_timestamps
    now = time.time()
    
    # Remove timestamps older than 1 minute
    _call_timestamps = [ts for ts in _call_timestamps if now - ts < 60]
    
    if len(_call_timestamps) >= rate_limit_calls_per_minute:
        return False
    
    _call_timestamps.append(now)
    return True


def safe_llm_call(prompt: str, domain: str | None = None) -> str | Dict[str, Any]:
    """
    Wrapper around LLM with guardrails and hard fallback.
    If anything fails, returns {"error": "..."} that caller can catch.
    """
    # Rate limiting check
    if not check_rate_limit():
        return {"error": "⚠️ Rate limit exceeded. Please wait before making more AI requests."}
    
    try:
        llm = get_llm()
    except Exception as e:
        return {"error": f"LLM not available: {e}"}

    messages = [
        SystemMessage(content=guard_prompt(prompt, domain)),
        HumanMessage(content="Respond as requested above."),
    ]
    try:
        resp = llm.invoke(messages)
    except Exception as e:
        return {"error": f"LLM call failed: {e}"}

    text, safe = guard_result(resp.content)
    if not safe:
        return {"error": text}
    return text


# ---------- Field weights ----------

def get_field_weights_with_llm(profile_summary: str, domain: str) -> Dict[str, Dict[str, float]]:
    """
    Ask LLM to suggest field-level weights.
    Returns dict[field_name] = {completeness, correctness, uniqueness}
    """
    prompt = f"""
You assign weights for 3 data-quality dimensions:
- completeness
- correctness
- uniqueness

Special rules:
- ID fields (name contains 'id' or ends with '_id'):
  - high completeness & uniqueness, lower correctness.
- Email fields (name contains 'email'):
  - high completeness & correctness, lower uniqueness.
- Phone/contact:
  - high correctness & completeness.
- Amount/money:
  - balanced but correctness slightly higher.
- Others:
  - balanced.

For each field in this profile:
{profile_summary}

Return STRICT JSON ONLY, of the form:
{{
  "field_name": {{
    "completeness": 0.4,
    "correctness": 0.4,
    "uniqueness": 0.2
  }},
  ...
}}
Each set of 3 weights per field MUST sum to 1.
"""
    raw = safe_llm_call(prompt, domain)
    if isinstance(raw, dict):  # error
        raise RuntimeError(raw["error"])

    text = raw.strip()
    try:
        return json.loads(text)
    except Exception:
        # Try to extract JSON substring if there is extra text
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            return json.loads(text[start : end + 1])
        raise RuntimeError(f"LLM did not return valid JSON for field weights. Raw: {text[:200]}")


# ---------- DQ Insights ----------

def get_dq_insights_with_llm(summary_json: dict, domain: str) -> str:
    """
    Get human-readable insights and fix suggestions for domain/file/field level.
    """
    prompt = f"""
You are a Data Quality expert.

Given this JSON summarising data quality:
{json.dumps(summary_json, indent=2)}

Task:
- Identify key data quality problems.
- Suggest non-destructive corrective actions and additional checks.
- Cover domain, table, and field levels.
- Limit to about 300 words.

Return plain text only (no JSON).
"""
    raw = safe_llm_call(prompt, domain)
    return raw if isinstance(raw, str) else raw["error"]


# ---------- DQ Rules suggestion (for Draft, using existing rules) ----------

def suggest_dq_rules_with_llm(
    field_profile: str,
    domain: str,
    current_rules: dict | None = None,
) -> Dict[str, Any]:
    """
    Ask LLM to PROPOSE IMPROVEMENTS over CURRENT rules.
    Returns dict with keys:
      - "rules": {...updated rules JSON...}
      - "explanation": "text..."
    """
    current_rules = current_rules or {}
    prompt = f"""
You are a Data Quality expert for '{domain}' data.

Below are the CURRENT data quality rules in JSON:
{json.dumps(current_rules, indent=2)}

Below is a profile of the actual data:
{field_profile}

Task:
- Review the existing rules.
- Suggest improvements ONLY by:
  - Adjusting thresholds (e.g. salary_min),
  - Adding/removing placeholder or allowed values,
  - Tweaking severities (Low/Medium/High),
  - Adding a FEW new rule entries if clearly needed.
- Do NOT completely change the structure. Reuse the same keys where possible.

Return STRICT JSON ONLY of the form:
{{
  "rules": {{ ...updated rules JSON... }},
  "explanation": "Short plain-text explanation of the main changes."
}}
"""
    raw = safe_llm_call(prompt, domain)
    if isinstance(raw, dict):
        raise RuntimeError(raw["error"])

    text = raw.strip()
    if not text:
        raise RuntimeError("LLM returned empty response for DQ rules.")

    try:
        return json.loads(text)
    except Exception:
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            return json.loads(text[start : end + 1])
        raise RuntimeError(f"LLM did not return valid JSON for rules. Raw: {text[:200]}")


# ---------- Table weights for Domain DQ ----------

def get_table_weights_with_llm(file_scores_df: pd.DataFrame, domain: str, subdomain: str = None) -> Dict[str, float]:
    """
    Ask LLM to assign relative importance weights per table for computing
    domain-level DQ. Considers business context, table criticality, and subdomain.
    Returns dict[table_name] = weight, normalized to sum ≈ 1.
    """
    table_score_str = file_scores_df[["table", "file_score"]].to_string(index=False)
    context = f"{domain}/{subdomain}" if subdomain else domain

    prompt = f"""
You are a Data Quality expert for {context} data.

Tables and their current DQ scores (higher is better):
{table_score_str}

Context and Business Importance:
- For HR subdomain: employees table is most critical (master data), followed by payroll (financial), attendance, then retention
- For Finance subdomain: invoices and payments are most critical (revenue/cash flow), followed by investments
- Master data tables (containing core entities) should have higher weights
- Transaction tables should have medium-high weights
- Reference/lookup tables should have lower weights

Assign a relative importance weight (0-1) to each table considering:
1. Business criticality and impact
2. Data dependencies (master data vs transactional)
3. Compliance and regulatory requirements
4. Current DQ scores (lower scores need more attention)
5. Subdomain context ({subdomain if subdomain else domain})

Weights for all tables must sum to approximately 1.

Return STRICT JSON ONLY like:
{{
  "table_name_1": 0.35,
  "table_name_2": 0.30,
  "table_name_3": 0.20,
  "table_name_4": 0.15
}}
"""
    raw = safe_llm_call(prompt, context)
    if isinstance(raw, dict):
        raise RuntimeError(raw["error"])

    text = raw.strip()
    try:
        weights = json.loads(text)
    except Exception:
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            weights = json.loads(text[start : end + 1])
        else:
            raise RuntimeError(f"LLM did not return valid JSON for table weights. Raw: {text[:200]}")

    # Normalize weights
    total = sum(weights.values()) or 1.0
    for k in list(weights.keys()):
        weights[k] = round(weights[k] / total, 3)

    return weights


# ---------- Subdomain Weights ----------

def get_subdomain_weights_with_llm(subdomain_scores: Dict[str, float], domain: str) -> Dict[str, float]:
    """
    Get AI-suggested weights for subdomains within a domain.
    Considers business importance and current DQ scores.
    """
    scores_str = "\n".join([f"- {sd}: {score:.2f}" for sd, score in subdomain_scores.items()])
    
    prompt = f"""
You are a Data Quality expert for {domain} domain.

Subdomain DQ Scores:
{scores_str}

For Investment Banking:
- HR subdomain manages human capital (critical for operations)
- Finance subdomain manages financial transactions (critical for compliance and revenue)

Assign relative importance weights (0-1) to each subdomain considering:
1. Business criticality and regulatory requirements
2. Impact on overall business operations  
3. Current DQ scores (lower scores need more focus)
4. Dependencies and downstream effects

Weights must sum to approximately 1.

Return STRICT JSON ONLY like:
{{
  "HR": 0.45,
  "Finance": 0.55
}}
"""
    raw = safe_llm_call(prompt, domain)
    if isinstance(raw, dict):
        raise RuntimeError(raw["error"])

    text = raw.strip()
    try:
        weights = json.loads(text)
    except Exception:
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            weights = json.loads(text[start : end + 1])
        else:
            # Default to equal weights
            weights = {sd: 1.0 / len(subdomain_scores) for sd in subdomain_scores.keys()}

    # Normalize weights
    total = sum(weights.values()) or 1.0
    for k in list(weights.keys()):
        weights[k] = round(weights[k] / total, 3)

    return weights


# ---------- Email Body Generation ----------

def generate_email_body(summary_data: Dict[str, Any], domain: str, subdomain: str = None) -> str:
    """
    Generate professional email body for DQ report.
    """
    context = f"{domain}/{subdomain}" if subdomain else domain
    
    prompt = f"""
Generate a professional email body for a Data Quality Report.

Context: {context}
Report Date: {summary_data.get('date', 'Today')}
Total Issues: {summary_data.get('total_issues', 'N/A')}
DQ Score: {summary_data.get('dq_score', 'N/A')}

The email should:
1. Start with a professional greeting
2. Brief executive summary (2-3 sentences)
3. Key highlights or concerns
4. Call to action (review attached PDF)
5. Professional closing

Tone: Professional, concise, actionable
Length: 150-200 words

Return plain text only (no JSON, no HTML).
"""
    raw = safe_llm_call(prompt, context)
    return raw if isinstance(raw, str) else "Please find attached the Data Quality Report for your review."


# ---------- Issues Summary & Recommendations ----------

def get_issues_summary_with_llm(issues_df: pd.DataFrame, domain: str, subdomain: str = None) -> Dict[str, Any]:
    """
    Generate AI-powered summary and recommendations for detected issues.
    Returns dict with keys:
      - "summary": Executive summary of issues
      - "recommendations": List of actionable recommendations
      - "example_queries": SQL-like example queries to investigate issues
    """
    context = subdomain if subdomain else domain
    issues_summary = issues_df.groupby(['issue_type', 'severity']).size().reset_index(name='count').to_string(index=False)
    
    prompt = f"""
You are a Data Quality expert analyzing issues for {context} data.

Issue Statistics:
{issues_summary}

Total Issues: {len(issues_df)}

Sample Issues (top 10):
{issues_df.head(10).to_string(index=False)}

Task:
1. Provide an executive summary (2-3 paragraphs) highlighting the most critical issues
2. List 5-7 specific, actionable recommendations to fix these issues
3. Provide 3-5 example SQL-like queries that would help investigate these issues

Return STRICT JSON ONLY in this format:
{{
  "summary": "Executive summary text here...",
  "recommendations": [
    "Recommendation 1...",
    "Recommendation 2...",
    ...
  ],
  "example_queries": [
    "SELECT * FROM table WHERE field IS NULL LIMIT 10;",
    ...
  ]
}}
"""
    raw = safe_llm_call(prompt, context)
    if isinstance(raw, dict):  # error
        return {
            "summary": "Error generating summary",
            "recommendations": [],
            "example_queries": []
        }

    text = raw.strip()
    try:
        return json.loads(text)
    except Exception:
        # Try to extract JSON substring
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            return json.loads(text[start : end + 1])
        return {
            "summary": text[:500],
            "recommendations": [],
            "example_queries": []
        }
